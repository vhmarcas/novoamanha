using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;

namespace NovoAmanha
{
    // Som por programa (Windows Core Audio): deixa mudo o navegador que NÃO está passando a tela
    // e devolve o som quando a troca é desligada. Só mexe no que ele mesmo silenciou.
    internal static class BrowserAudio
    {
        private static readonly Dictionary<int, bool> Muted = new Dictionary<int, bool>();
        private static readonly Guid IidSessionMgr = new Guid("77AA99A0-1BD6-484F-8BC7-2C654C9A9B6F");

        // Silencia os navegadores diferentes do ativo (e libera o ativo se foi silenciado por aqui).
        public static void Enforce(string active, string[] browsers)
        {
            Dictionary<int, string> names = new Dictionary<int, string>();
            bool changed = false;
            ForEachSession(delegate(int pid, ISimpleAudioVolume vol)
            {
                string name = NameOf(pid, names);
                if (Array.IndexOf(browsers, name) < 0) return;
                Guid ctx = Guid.Empty;
                if (!string.Equals(name, active, StringComparison.OrdinalIgnoreCase))
                {
                    bool cur;
                    if (vol.GetMute(out cur) == 0 && !cur)
                    {
                        if (vol.SetMute(true, ref ctx) == 0)
                        {
                            if (!Muted.ContainsKey(pid)) changed = true;
                            Muted[pid] = true;
                        }
                    }
                }
                else if (Muted.ContainsKey(pid))
                {
                    vol.SetMute(false, ref ctx);
                    Muted.Remove(pid);
                    changed = true;
                }
            });
            if (changed) SaveState();
        }

        // Devolve o som de tudo que foi silenciado por aqui.
        public static void Restore()
        {
            if (Muted.Count == 0) return;
            ForEachSession(delegate(int pid, ISimpleAudioVolume vol)
            {
                if (!Muted.ContainsKey(pid)) return;
                Guid ctx = Guid.Empty;
                vol.SetMute(false, ref ctx);
            });
            Muted.Clear();
            SaveState();
        }

        // Quem foi silenciado fica anotado em disco: se o painel for encerrado à força, o vigia (ou a próxima
        // abertura do programa) usa esta anotação para devolver o som, que senão ficaria mudo para sempre.
        private static string StatePath()
        {
            return Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "NovoAmanhaHelper", "mudos.txt");
        }

        private static void SaveState()
        {
            try
            {
                string p = StatePath();
                if (Muted.Count == 0)
                {
                    if (File.Exists(p)) File.Delete(p);
                    return;
                }
                List<string> l = new List<string>();
                foreach (int pid in Muted.Keys) l.Add(pid.ToString());
                Directory.CreateDirectory(Path.GetDirectoryName(p));
                File.WriteAllText(p, string.Join(",", l.ToArray()));
            }
            catch { }
        }

        private static List<int> LoadState()
        {
            List<int> r = new List<int>();
            try
            {
                string p = StatePath();
                if (!File.Exists(p)) return r;
                foreach (string part in File.ReadAllText(p).Split(','))
                {
                    int v;
                    if (int.TryParse(part.Trim(), out v)) r.Add(v);
                }
            }
            catch { }
            return r;
        }

        // Devolve o som dos navegadores que uma execução anterior deixou silenciados.
        public static void RestoreSaved(string[] browsers)
        {
            List<int> pids = LoadState();
            if (pids.Count == 0) return;
            Dictionary<int, string> names = new Dictionary<int, string>();
            ForEachSession(delegate(int pid, ISimpleAudioVolume vol)
            {
                if (!pids.Contains(pid)) return;
                if (Array.IndexOf(browsers, NameOf(pid, names)) < 0) return;   // PID reaproveitado por outro programa
                Guid ctx = Guid.Empty;
                vol.SetMute(false, ref ctx);
            });
            Muted.Clear();
            SaveState();
        }

        private static string NameOf(int pid, Dictionary<int, string> cache)
        {
            string n;
            if (cache.TryGetValue(pid, out n)) return n;
            n = "";
            try { using (Process p = Process.GetProcessById(pid)) n = p.ProcessName.ToLowerInvariant(); }
            catch { }
            cache[pid] = n;
            return n;
        }

        private delegate void SessionAction(int pid, ISimpleAudioVolume vol);

        // Percorre as sessões de áudio de todas as saídas de som ativas.
        private static void ForEachSession(SessionAction action)
        {
            IMMDeviceEnumerator en = null;
            IMMDeviceCollection devs = null;
            try
            {
                en = (IMMDeviceEnumerator)new MMDeviceEnumeratorComObject();
                if (en.EnumAudioEndpoints(0, 1, out devs) != 0 || devs == null) return;   // saídas (render) ativas
                uint count;
                if (devs.GetCount(out count) != 0) return;
                for (uint d = 0; d < count; d++)
                {
                    IMMDevice dev = null;
                    try
                    {
                        if (devs.Item(d, out dev) != 0 || dev == null) continue;
                        Guid iid = IidSessionMgr;
                        object o;
                        if (dev.Activate(ref iid, 23, IntPtr.Zero, out o) != 0 || o == null) continue;
                        IAudioSessionManager2 mgr = (IAudioSessionManager2)o;
                        try { WalkSessions(mgr, action); }
                        finally { Marshal.ReleaseComObject(mgr); }
                    }
                    catch { }
                    finally { if (dev != null) Marshal.ReleaseComObject(dev); }
                }
            }
            catch { }
            finally
            {
                if (devs != null) Marshal.ReleaseComObject(devs);
                if (en != null) Marshal.ReleaseComObject(en);
            }
        }

        private static void WalkSessions(IAudioSessionManager2 mgr, SessionAction action)
        {
            IAudioSessionEnumerator se;
            if (mgr.GetSessionEnumerator(out se) != 0 || se == null) return;
            try
            {
                int n;
                if (se.GetCount(out n) != 0) return;
                for (int i = 0; i < n; i++)
                {
                    IAudioSessionControl ctl = null;
                    try
                    {
                        if (se.GetSession(i, out ctl) != 0 || ctl == null) continue;
                        IAudioSessionControl2 c2 = ctl as IAudioSessionControl2;
                        ISimpleAudioVolume vol = ctl as ISimpleAudioVolume;
                        if (c2 == null || vol == null) continue;
                        uint pid;
                        if (c2.GetProcessId(out pid) != 0 || pid == 0) continue;
                        action((int)pid, vol);
                    }
                    catch { }
                    finally { if (ctl != null) Marshal.ReleaseComObject(ctl); }
                }
            }
            finally { Marshal.ReleaseComObject(se); }
        }
    }

    // ---- COM do Windows (a ordem dos métodos precisa ser exatamente esta) ----

    [ComImport, Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")]
    internal class MMDeviceEnumeratorComObject { }

    [ComImport, Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    internal interface IMMDeviceEnumerator
    {
        [PreserveSig] int EnumAudioEndpoints(int dataFlow, int stateMask, out IMMDeviceCollection devices);
        [PreserveSig] int GetDefaultAudioEndpoint(int dataFlow, int role, out IMMDevice device);
        [PreserveSig] int GetDevice([MarshalAs(UnmanagedType.LPWStr)] string id, out IMMDevice device);
        [PreserveSig] int RegisterEndpointNotificationCallback(IntPtr client);
        [PreserveSig] int UnregisterEndpointNotificationCallback(IntPtr client);
    }

    [ComImport, Guid("0BD7A1BE-7A1A-44DB-8397-CC5392387B5E"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    internal interface IMMDeviceCollection
    {
        [PreserveSig] int GetCount(out uint count);
        [PreserveSig] int Item(uint index, out IMMDevice device);
    }

    [ComImport, Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    internal interface IMMDevice
    {
        [PreserveSig] int Activate(ref Guid iid, int clsCtx, IntPtr activationParams,
            [MarshalAs(UnmanagedType.IUnknown)] out object iface);
        [PreserveSig] int OpenPropertyStore(int access, out IntPtr properties);
        [PreserveSig] int GetId([MarshalAs(UnmanagedType.LPWStr)] out string id);
        [PreserveSig] int GetState(out int state);
    }

    [ComImport, Guid("77AA99A0-1BD6-484F-8BC7-2C654C9A9B6F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    internal interface IAudioSessionManager2
    {
        [PreserveSig] int GetAudioSessionControl(IntPtr sessionGuid, int streamFlags, out IntPtr control);
        [PreserveSig] int GetSimpleAudioVolume(IntPtr sessionGuid, int streamFlags, out IntPtr volume);
        [PreserveSig] int GetSessionEnumerator(out IAudioSessionEnumerator sessionEnum);
    }

    [ComImport, Guid("E2F5BB11-0570-40CA-ACDD-3AA01277DEE8"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    internal interface IAudioSessionEnumerator
    {
        [PreserveSig] int GetCount(out int count);
        [PreserveSig] int GetSession(int index, out IAudioSessionControl session);
    }

    [ComImport, Guid("F4B1A599-7266-4319-A8CA-E70ACB11E8CD"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    internal interface IAudioSessionControl
    {
        [PreserveSig] int GetState(out int state);
        [PreserveSig] int GetDisplayName([MarshalAs(UnmanagedType.LPWStr)] out string name);
        [PreserveSig] int SetDisplayName([MarshalAs(UnmanagedType.LPWStr)] string name, ref Guid ctx);
        [PreserveSig] int GetIconPath([MarshalAs(UnmanagedType.LPWStr)] out string path);
        [PreserveSig] int SetIconPath([MarshalAs(UnmanagedType.LPWStr)] string path, ref Guid ctx);
        [PreserveSig] int GetGroupingParam(out Guid param);
        [PreserveSig] int SetGroupingParam(ref Guid param, ref Guid ctx);
        [PreserveSig] int RegisterAudioSessionNotification(IntPtr client);
        [PreserveSig] int UnregisterAudioSessionNotification(IntPtr client);
    }

    [ComImport, Guid("BFB7FF88-7239-4FC9-8FA2-07C950BE9C6D"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    internal interface IAudioSessionControl2
    {
        // herdados de IAudioSessionControl
        [PreserveSig] int GetState(out int state);
        [PreserveSig] int GetDisplayName([MarshalAs(UnmanagedType.LPWStr)] out string name);
        [PreserveSig] int SetDisplayName([MarshalAs(UnmanagedType.LPWStr)] string name, ref Guid ctx);
        [PreserveSig] int GetIconPath([MarshalAs(UnmanagedType.LPWStr)] out string path);
        [PreserveSig] int SetIconPath([MarshalAs(UnmanagedType.LPWStr)] string path, ref Guid ctx);
        [PreserveSig] int GetGroupingParam(out Guid param);
        [PreserveSig] int SetGroupingParam(ref Guid param, ref Guid ctx);
        [PreserveSig] int RegisterAudioSessionNotification(IntPtr client);
        [PreserveSig] int UnregisterAudioSessionNotification(IntPtr client);
        // próprios
        [PreserveSig] int GetSessionIdentifier([MarshalAs(UnmanagedType.LPWStr)] out string id);
        [PreserveSig] int GetSessionInstanceIdentifier([MarshalAs(UnmanagedType.LPWStr)] out string id);
        [PreserveSig] int GetProcessId(out uint pid);
        [PreserveSig] int IsSystemSoundsSession();
        [PreserveSig] int SetDuckingPreference([MarshalAs(UnmanagedType.Bool)] bool optOut);
    }

    [ComImport, Guid("87CE5498-68D6-44E5-9215-6DA47EF883D8"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    internal interface ISimpleAudioVolume
    {
        [PreserveSig] int SetMasterVolume(float level, ref Guid ctx);
        [PreserveSig] int GetMasterVolume(out float level);
        [PreserveSig] int SetMute([MarshalAs(UnmanagedType.Bool)] bool mute, ref Guid ctx);
        [PreserveSig] int GetMute([MarshalAs(UnmanagedType.Bool)] out bool mute);
    }
}
