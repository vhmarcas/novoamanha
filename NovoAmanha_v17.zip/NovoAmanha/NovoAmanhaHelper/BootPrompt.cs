using System;
using System.Drawing;
using System.Windows.Forms;

namespace NovoAmanha
{
    // Pergunta que aparece ao ligar o notebook: "Você está na igreja? Abrir o painel?"
    internal class BootPrompt : Form
    {
        private readonly Label _lbl = new Label();
        private readonly Label _count = new Label();
        private readonly Timer _t = new Timer();
        private int _left = 90;

        // true = abrir o painel
        public static bool Ask()
        {
            try
            {
                using (BootPrompt f = new BootPrompt())
                    return f.ShowDialog() == DialogResult.Yes;
            }
            catch (Exception ex)
            {
                ErrorLog.Write(ex);
                return false;
            }
        }

        private BootPrompt()
        {
            Text = "Novo Amanhã Helper";
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            StartPosition = FormStartPosition.CenterScreen;
            TopMost = true;
            ShowInTaskbar = true;
            BackColor = Theme.Bg;
            AutoScaleMode = AutoScaleMode.None;
            ClientSize = new Size(560, 330);

            BannerPanel head = new BannerPanel();
            head.Dock = DockStyle.Top;
            head.Height = 130;
            head.BadgeText = "NOVO AMANHÃ";
            head.BadgeColor = Theme.Accent;
            head.RightText = "";
            Controls.Add(head);

            _lbl.AutoSize = false;
            _lbl.Text = "Você está na igreja?\r\nQuer abrir o painel agora?";
            _lbl.Font = new Font(Fx.TechName(), 15f);
            _lbl.ForeColor = Theme.Text;
            _lbl.BackColor = Theme.Bg;
            _lbl.TextAlign = ContentAlignment.MiddleCenter;
            _lbl.SetBounds(20, 138, 520, 70);
            Controls.Add(_lbl);

            FxButton yes = new FxButton();
            yes.Text = "SIM, ESTOU NA IGREJA";
            yes.Font = new Font(Fx.TechName(), 12f);
            yes.Base = Color.FromArgb(0, 120, 150);
            yes.Hot = Theme.Good;
            yes.ForeColor = Color.White;
            yes.Backdrop = Theme.Bg;
            yes.SetBounds(30, 220, 330, 56);
            yes.Click += delegate { DialogResult = DialogResult.Yes; };
            Controls.Add(yes);

            FxButton no = new FxButton();
            no.Text = "Agora não";
            no.Font = new Font(Fx.TechName(), 11f);
            no.Backdrop = Theme.Bg;
            no.ForeColor = Theme.Text;
            no.SetBounds(375, 220, 155, 56);
            no.Click += delegate { DialogResult = DialogResult.No; };
            Controls.Add(no);

            _count.AutoSize = false;
            _count.Font = new Font("Segoe UI", 9f);
            _count.ForeColor = Theme.Muted;
            _count.BackColor = Theme.Bg;
            _count.TextAlign = ContentAlignment.MiddleCenter;
            _count.SetBounds(20, 288, 520, 24);
            Controls.Add(_count);

            AcceptButton = yes;
            _t.Interval = 1000;
            _t.Tick += delegate
            {
                _left--;
                if (_left <= 0) { _t.Stop(); DialogResult = DialogResult.No; return; }
                UpdateCount();
            };
            UpdateCount();
        }

        private void UpdateCount()
        {
            _count.Text = "Se ninguém responder, fecha sozinho em " + _left + " s (o painel não abre).";
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            _t.Start();
            try { Activate(); }
            catch { }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) _t.Dispose();
            base.Dispose(disposing);
        }
    }
}
