using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using Microsoft.Win32;

namespace NovoAmanha
{
    internal class BrowserInfo
    {
        public string Proc = "";     // nome do processo, minúsculo (chrome, msedge, firefox...)
        public string Name = "";     // nome completo
        public string Short = "";    // nome curto
        public string Exe = "";
        public Color Tint = Color.Gray;

        public override string ToString()
        {
            return Name;
        }
    }

    // Descobre quais navegadores existem neste notebook.
    internal static class BrowserCatalog
    {
        private class Def
        {
            public string Proc, Name, Short, ExeName;
            public Color Tint;
            public string[] Rel;

            public Def(string proc, string name, string shortName, string exeName, Color tint, params string[] rel)
            {
                Proc = proc;
                Name = name;
                Short = shortName;
                ExeName = exeName;
                Tint = tint;
                Rel = rel;
            }
        }

        private static readonly Def[] Defs = new Def[]
        {
            new Def("chrome", "Google Chrome", "Chrome", "chrome.exe", Color.FromArgb(66, 133, 244),
                @"Google\Chrome\Application\chrome.exe"),
            new Def("msedge", "Microsoft Edge", "Edge", "msedge.exe", Color.FromArgb(0, 150, 170),
                @"Microsoft\Edge\Application\msedge.exe"),
            new Def("firefox", "Mozilla Firefox", "Firefox", "firefox.exe", Color.FromArgb(255, 113, 57),
                @"Mozilla Firefox\firefox.exe"),
            new Def("brave", "Brave", "Brave", "brave.exe", Color.FromArgb(251, 84, 43),
                @"BraveSoftware\Brave-Browser\Application\brave.exe"),
            new Def("opera", "Opera", "Opera", "opera.exe", Color.FromArgb(235, 30, 50),
                @"Opera\opera.exe", @"Opera\launcher.exe"),
            new Def("vivaldi", "Vivaldi", "Vivaldi", "vivaldi.exe", Color.FromArgb(220, 60, 60),
                @"Vivaldi\Application\vivaldi.exe")
        };

        // Nomes de processo de todos os navegadores conhecidos.
        public static string[] AllProcs()
        {
            string[] list = new string[Defs.Length];
            for (int i = 0; i < Defs.Length; i++) list[i] = Defs[i].Proc;
            return list;
        }

        public static string ShortName(string proc)
        {
            if (string.IsNullOrEmpty(proc)) return "";
            foreach (Def d in Defs)
                if (string.Equals(d.Proc, proc, StringComparison.OrdinalIgnoreCase)) return d.Short;
            return proc;
        }

        public static Color TintOf(string proc)
        {
            foreach (Def d in Defs)
                if (string.Equals(d.Proc, proc, StringComparison.OrdinalIgnoreCase)) return d.Tint;
            return Color.Gray;
        }

        public static List<BrowserInfo> Detect()
        {
            List<BrowserInfo> list = new List<BrowserInfo>();
            List<string> roots = new List<string>();
            AddRoot(roots, Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles));
            AddRoot(roots, Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86));
            string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            AddRoot(roots, local);
            if (local.Length > 0) AddRoot(roots, Path.Combine(local, "Programs"));

            foreach (Def d in Defs)
            {
                string exe = FindExe(d, roots);
                bool running = false;
                if (exe.Length == 0)
                {
                    try
                    {
                        Process[] ps = Process.GetProcessesByName(d.Proc);
                        running = ps.Length > 0;
                        foreach (Process p in ps) p.Dispose();
                    }
                    catch { }
                }
                if (exe.Length == 0 && !running) continue;

                BrowserInfo bi = new BrowserInfo();
                bi.Proc = d.Proc;
                bi.Name = d.Name;
                bi.Short = d.Short;
                bi.Exe = exe;
                bi.Tint = d.Tint;
                list.Add(bi);
            }
            return list;
        }

        private static void AddRoot(List<string> roots, string path)
        {
            if (!string.IsNullOrEmpty(path) && !roots.Contains(path)) roots.Add(path);
        }

        private static string FindExe(Def d, List<string> roots)
        {
            try
            {
                foreach (string root in roots)
                    foreach (string rel in d.Rel)
                    {
                        string full = Path.Combine(root, rel);
                        if (File.Exists(full)) return full;
                    }

                string[] keys = new string[]
                {
                    @"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\",
                    @"HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\"
                };
                foreach (string key in keys)
                {
                    string v = Registry.GetValue(key + d.ExeName, "", null) as string;
                    if (!string.IsNullOrEmpty(v))
                    {
                        v = v.Trim('"');
                        if (File.Exists(v)) return v;
                    }
                }
            }
            catch { }
            return "";
        }
    }
}
