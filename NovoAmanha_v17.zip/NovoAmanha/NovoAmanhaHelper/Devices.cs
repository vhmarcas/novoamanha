using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Management;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace NovoAmanha
{
    // Um aparelho mostrado na lista. Source = de onde vem (HDMI, USB, Bluetooth...).
    internal class DeviceInfo
    {
        public string Name = "";
        public string Source = "";
        public string Group = "";
        public string Key = "";       // nome da tela no Windows (só para telas selecionáveis)
        public string Note = "";
        public bool Selectable;       // só telas extras podem ser marcadas

        public string Text
        {
            get { return Name + " (" + Source + ")" + (Note.Length > 0 ? " — " + Note : ""); }
        }
    }

    internal static class Devices
    {
        public const string GroupScreens = "Telas";
        public const string GroupSharing = "Compartilhamento";
        public const string GroupUsb = "USB";
        public const string GroupBluetooth = "Bluetooth";

        // Procura tudo de novo. Pode demorar alguns segundos: chame fora da thread da interface.
        public static List<DeviceInfo> Scan()
        {
            List<DeviceInfo> list = new List<DeviceInfo>();
            try { ScanDisplays(list); } catch { }
            try { list.AddRange(ScanSharing()); } catch { }
            try { ScanUsb(list); } catch { }
            try { ScanBluetooth(list); } catch { }
            return list;
        }

        // ---------- telas ----------

        private static string Z(string s)
        {
            int z = s.IndexOf('\0');
            return (z >= 0 ? s.Substring(0, z) : s).Trim();
        }

        private static string S(object o)
        {
            return o == null ? "" : o.ToString();
        }

        private static string SourceName(byte[] adapter, uint id)
        {
            byte[] pk = new byte[84];
            BitConverter.GetBytes((uint)1).CopyTo(pk, 0);     // GET_SOURCE_NAME
            BitConverter.GetBytes((uint)84).CopyTo(pk, 4);
            Array.Copy(adapter, 0, pk, 8, 8);
            BitConverter.GetBytes(id).CopyTo(pk, 16);
            if (Native.DisplayConfigGetDeviceInfo(pk) != 0) return "";
            return Z(Encoding.Unicode.GetString(pk, 20, 64));
        }

        private static string TargetName(byte[] adapter, uint id, ref uint tech)
        {
            byte[] pk = new byte[420];
            BitConverter.GetBytes((uint)2).CopyTo(pk, 0);     // GET_TARGET_NAME
            BitConverter.GetBytes((uint)420).CopyTo(pk, 4);
            Array.Copy(adapter, 0, pk, 8, 8);
            BitConverter.GetBytes(id).CopyTo(pk, 16);
            if (Native.DisplayConfigGetDeviceInfo(pk) != 0) return "";
            tech = BitConverter.ToUInt32(pk, 24);
            return Z(Encoding.Unicode.GetString(pk, 36, 128));
        }

        private static string TechName(uint t)
        {
            switch (t)
            {
                case 0: return "VGA";
                case 1: return "S-Video";
                case 2: return "vídeo composto";
                case 3: return "componente";
                case 4: return "DVI";
                case 5: return "HDMI";
                case 6: return "interna";
                case 8: return "D-Terminal";
                case 9: return "SDI";
                case 10: return "DisplayPort";
                case 11: return "interna";
                case 12: return "UDI";
                case 13: return "UDI";
                case 14: return "dongle SDTV";
                case 15: return "sem fio (Miracast)";
                case 16: return "USB/dock";
                case 17: return "virtual";
                case 0x80000000: return "interna";
                default: return "outra conexão";
            }
        }

        private static bool IsInternal(uint t)
        {
            return t == 0x80000000 || t == 6 || t == 11;
        }

        private static void ScanDisplays(List<DeviceInfo> list)
        {
            Screen[] screens = Screen.AllScreens;
            uint np, nm;
            bool ok = false;

            if (Native.GetDisplayConfigBufferSizes(Native.QDC_ONLY_ACTIVE_PATHS, out np, out nm) == 0 && np > 0)
            {
                byte[] paths = new byte[np * 72];
                byte[] modes = new byte[(nm > 0 ? nm : 1u) * 64];
                if (Native.QueryDisplayConfig(Native.QDC_ONLY_ACTIVE_PATHS, ref np, paths, ref nm, modes, IntPtr.Zero) == 0)
                {
                    ok = true;
                    int count = (int)np;
                    string[] gdi = new string[count];
                    string[] friendly = new string[count];
                    uint[] tech = new uint[count];

                    for (int i = 0; i < count; i++)
                    {
                        int o = i * 72;
                        byte[] srcAd = new byte[8];
                        Array.Copy(paths, o, srcAd, 0, 8);
                        uint srcId = BitConverter.ToUInt32(paths, o + 8);
                        byte[] tgtAd = new byte[8];
                        Array.Copy(paths, o + 20, tgtAd, 0, 8);
                        uint tgtId = BitConverter.ToUInt32(paths, o + 28);
                        tech[i] = BitConverter.ToUInt32(paths, o + 36);
                        gdi[i] = SourceName(srcAd, srcId);
                        friendly[i] = TargetName(tgtAd, tgtId, ref tech[i]);
                    }

                    // quantas saídas dividem a mesma tela (modo Duplicar)
                    Dictionary<string, int> perSource = new Dictionary<string, int>();
                    for (int i = 0; i < count; i++)
                    {
                        int n;
                        perSource.TryGetValue(gdi[i], out n);
                        perSource[gdi[i]] = n + 1;
                    }

                    Dictionary<string, bool> activeTargets = new Dictionary<string, bool>();
                    for (int i = 0; i < count; i++)
                    {
                        byte[] ta = new byte[8];
                        Array.Copy(paths, i * 72 + 20, ta, 0, 8);
                        activeTargets[BitConverter.ToString(ta) + "-" + BitConverter.ToUInt32(paths, i * 72 + 28)] = true;
                    }

                    Dictionary<string, bool> listed = new Dictionary<string, bool>();
                    for (int i = 0; i < count; i++)
                    {
                        Screen sc = null;
                        foreach (Screen s in screens)
                            if (gdi[i].Length > 0 && s.DeviceName == gdi[i]) { sc = s; break; }

                        DeviceInfo d = new DeviceInfo();
                        d.Group = GroupScreens;
                        d.Source = TechName(tech[i]);
                        d.Name = friendly[i].Length > 0 ? friendly[i] : (IsInternal(tech[i]) ? "Tela do notebook" : "Monitor/projetor");

                        if (sc == null)
                        {
                            d.Note = "sem imagem";
                        }
                        else
                        {
                            string res = sc.Bounds.Width + "x" + sc.Bounds.Height;
                            bool shared = perSource[gdi[i]] > 1;
                            bool first = !listed.ContainsKey(gdi[i]);
                            listed[gdi[i]] = true;

                            if (sc.Primary)
                                d.Note = "tela principal, " + res + (shared ? ", espelhada" : "");
                            else
                            {
                                // TODOS os aparelhos de uma tela extra podem ser marcados. Em "Duplicar" (TV + projetor
                                // mostrando a mesma imagem) o Windows enxerga UMA tela só: marcar um marca os dois.
                                d.Note = res + (shared ? ", espelhada: TV e projetor são a mesma tela, marcar um marca todos" : "");
                                d.Key = gdi[i];
                                d.Selectable = true;
                            }
                        }
                        list.Add(d);
                    }

                    try { AddInactiveOutputs(list, activeTargets); }
                    catch { }
                }
            }

            if (!ok)
            {
                for (int i = 0; i < screens.Length; i++)
                {
                    DeviceInfo d = new DeviceInfo();
                    d.Group = GroupScreens;
                    d.Name = "Tela " + (i + 1);
                    d.Source = "conexão desconhecida";
                    d.Note = screens[i].Bounds.Width + "x" + screens[i].Bounds.Height +
                             (screens[i].Primary ? ", tela principal" : "");
                    if (!screens[i].Primary)
                    {
                        d.Key = screens[i].DeviceName;
                        d.Selectable = true;
                    }
                    list.Add(d);
                }
            }
        }

        // Aparelhos conectados que o Windows ainda não está usando (ex.: projetor ligado mas desativado).
        private static void AddInactiveOutputs(List<DeviceInfo> list, Dictionary<string, bool> activeTargets)
        {
            uint np, nm;
            if (Native.GetDisplayConfigBufferSizes(Native.QDC_ALL_PATHS, out np, out nm) != 0 || np == 0) return;
            byte[] paths = new byte[np * 72];
            byte[] modes = new byte[(nm > 0 ? nm : 1u) * 64];
            if (Native.QueryDisplayConfig(Native.QDC_ALL_PATHS, ref np, paths, ref nm, modes, IntPtr.Zero) != 0) return;

            Dictionary<string, bool> seen = new Dictionary<string, bool>();
            for (int i = 0; i < (int)np; i++)
            {
                int o = i * 72;
                if (BitConverter.ToUInt32(paths, o + 60) == 0) continue;     // targetAvailable
                byte[] ta = new byte[8];
                Array.Copy(paths, o + 20, ta, 0, 8);
                uint tid = BitConverter.ToUInt32(paths, o + 28);
                string key = BitConverter.ToString(ta) + "-" + tid;
                if (activeTargets.ContainsKey(key) || seen.ContainsKey(key)) continue;
                seen[key] = true;

                uint tech = BitConverter.ToUInt32(paths, o + 36);
                string name = TargetName(ta, tid, ref tech);
                if (name.Length == 0) continue;

                DeviceInfo d = new DeviceInfo();
                d.Group = GroupScreens;
                d.Name = name;
                d.Source = TechName(tech);
                d.Note = "conectado, mas sem imagem (Win+P → Estender)";
                list.Add(d);
            }
        }

        // ---------- apps de compartilhamento de tela (Meet, Zoom, Teams...) ----------

        private static readonly Regex MeetCode = new Regex(
            @"^(meet|reuni[aã]o)\s*[-\u2013\u2014]\s*[a-z]{3}-[a-z]{4}-[a-z]{3}",
            RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);

        private static bool IsMeetTitle(string title)
        {
            string s = title.ToLowerInvariant();
            if (s.Contains("meet.google.com") || s.Contains("google meet")) return true;
            return MeetCode.IsMatch(s);
        }

        private static string BrowserName(string proc)
        {
            if (proc == "chrome") return "Chrome";
            if (proc == "msedge") return "Edge";
            if (proc == "firefox") return "Firefox";
            return "";
        }

        // Rápido (só olha as janelas abertas): pode ser chamado a cada poucos segundos.
        public static List<DeviceInfo> ScanSharing()
        {
            List<DeviceInfo> list = new List<DeviceInfo>();
            try
            {
                Dictionary<string, bool> seen = new Dictionary<string, bool>();
                Dictionary<uint, string> procs = new Dictionary<uint, string>();

                Native.EnumWindows(delegate(IntPtr h, IntPtr lp)
                {
                    if (!Native.IsWindowVisible(h)) return true;
                    string title = Native.TitleOf(h);
                    if (title.Length == 0) return true;

                    uint pid;
                    Native.GetWindowThreadProcessId(h, out pid);
                    string proc;
                    if (!procs.TryGetValue(pid, out proc))
                    {
                        proc = "";
                        try { using (Process pr = Process.GetProcessById((int)pid)) proc = pr.ProcessName.ToLowerInvariant(); }
                        catch { }
                        procs[pid] = proc;
                    }

                    string app = "";
                    string via = "";
                    if (proc == "zoom") { app = "Zoom"; via = "aplicativo"; }
                    else if (proc == "ms-teams" || proc == "teams") { app = "Microsoft Teams"; via = "aplicativo"; }
                    else if (proc == "discord") { app = "Discord"; via = "aplicativo"; }
                    else if (proc == "obs64" || proc == "obs32") { app = "OBS Studio"; via = "aplicativo"; }

                    if (app.Length == 0) return true;
                    string key = app + "|" + via;
                    if (seen.ContainsKey(key)) return true;
                    seen[key] = true;

                    string place = "";
                    RECT r;
                    if (Native.GetWindowRect(h, out r))
                    {
                        Point c = new Point(r.Left + r.Width / 2, r.Top + r.Height / 2);
                        place = Screen.FromPoint(c).Primary ? "janela no notebook" : "janela na tela compartilhada";
                    }

                    DeviceInfo d = new DeviceInfo();
                    d.Group = GroupSharing;
                    d.Name = app;
                    d.Source = via;
                    d.Note = place;
                    list.Add(d);
                    return true;
                }, IntPtr.Zero);

                // Google Meet (todas as abas) + uso de microfone/câmera/captura de tela
                list.AddRange(MeetDetector.Detect());
            }
            catch { }
            return list;
        }

        // ---------- USB (entradas do notebook) ----------

        private static void ScanUsb(List<DeviceInfo> list)
        {
            Dictionary<string, bool> seen = new Dictionary<string, bool>();
            using (ManagementObjectSearcher q = new ManagementObjectSearcher(
                "SELECT Name, PNPClass, DeviceID, Service FROM Win32_PnPEntity WHERE Present = TRUE AND DeviceID LIKE 'USB%'"))
            using (ManagementObjectCollection col = q.Get())
            {
                foreach (ManagementBaseObject mo in col)
                {
                    string id = S(mo["DeviceID"]).ToUpperInvariant();
                    string name = S(mo["Name"]).Trim();
                    string cls = S(mo["PNPClass"]);
                    string svc = S(mo["Service"]).ToLowerInvariant();
                    mo.Dispose();

                    if (name.Length == 0) continue;
                    if (id.StartsWith("USB\\ROOT_HUB", StringComparison.Ordinal)) continue;
                    if (svc == "usbhub" || svc == "usbhub3" || svc == "usbccgp" || svc == "usbxhci" || svc == "usbehci") continue;
                    if (cls == "USB" || cls == "Bluetooth") continue;   // hubs, controladoras e o rádio Bluetooth
                    if (seen.ContainsKey(name)) continue;
                    seen[name] = true;

                    DeviceInfo d = new DeviceInfo();
                    d.Group = GroupUsb;
                    d.Name = name;
                    d.Source = "USB";
                    list.Add(d);
                }
            }
        }

        // ---------- Bluetooth ----------

        [StructLayout(LayoutKind.Sequential)]
        private struct SYSTEMTIME
        {
            public ushort a, b, c, d, e, f, g, h;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        private struct BLUETOOTH_DEVICE_INFO
        {
            public uint dwSize;
            public ulong Address;
            public uint ulClassofDevice;
            public int fConnected;
            public int fRemembered;
            public int fAuthenticated;
            public SYSTEMTIME stLastSeen;
            public SYSTEMTIME stLastUsed;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 248)]
            public string szName;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct BLUETOOTH_DEVICE_SEARCH_PARAMS
        {
            public uint dwSize;
            public int fReturnAuthenticated;
            public int fReturnRemembered;
            public int fReturnUnknown;
            public int fReturnConnected;
            public int fIssueInquiry;
            public byte cTimeoutMultiplier;
            public IntPtr hRadio;
        }

        [DllImport("bthprops.cpl", SetLastError = true)]
        private static extern IntPtr BluetoothFindFirstDevice(ref BLUETOOTH_DEVICE_SEARCH_PARAMS p, ref BLUETOOTH_DEVICE_INFO d);

        [DllImport("bthprops.cpl", SetLastError = true)]
        private static extern bool BluetoothFindNextDevice(IntPtr h, ref BLUETOOTH_DEVICE_INFO d);

        [DllImport("bthprops.cpl", SetLastError = true)]
        private static extern bool BluetoothFindDeviceClose(IntPtr h);

        private static void ScanBluetooth(List<DeviceInfo> list)
        {
            BLUETOOTH_DEVICE_SEARCH_PARAMS sp = new BLUETOOTH_DEVICE_SEARCH_PARAMS();
            sp.dwSize = (uint)Marshal.SizeOf(typeof(BLUETOOTH_DEVICE_SEARCH_PARAMS));
            sp.fReturnAuthenticated = 1;
            sp.fReturnRemembered = 1;
            sp.fReturnUnknown = 0;
            sp.fReturnConnected = 1;
            sp.fIssueInquiry = 0;
            sp.cTimeoutMultiplier = 0;
            sp.hRadio = IntPtr.Zero;

            BLUETOOTH_DEVICE_INFO info = new BLUETOOTH_DEVICE_INFO();
            info.dwSize = (uint)Marshal.SizeOf(typeof(BLUETOOTH_DEVICE_INFO));

            IntPtr h = BluetoothFindFirstDevice(ref sp, ref info);
            if (h == IntPtr.Zero) return;

            Dictionary<string, bool> seen = new Dictionary<string, bool>();
            try
            {
                do
                {
                    string name = info.szName == null ? "" : Z(info.szName);
                    if (info.fConnected != 0 && name.Length > 0 && !seen.ContainsKey(name))
                    {
                        seen[name] = true;
                        DeviceInfo d = new DeviceInfo();
                        d.Group = GroupBluetooth;
                        d.Name = name;
                        d.Source = "Bluetooth";
                        list.Add(d);
                    }
                }
                while (BluetoothFindNextDevice(h, ref info));
            }
            finally
            {
                BluetoothFindDeviceClose(h);
            }
        }
    }
}
