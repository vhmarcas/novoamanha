using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Microsoft.Win32;

namespace NovoAmanha
{
    // Janela preta que cobre uma tela compartilhada.
    internal class CoverForm : Form
    {
        private bool _bd;
        private int _bdStamp = -1;
        private Size _bdSize;

        public CoverForm()
        {
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.Manual;
            ShowInTaskbar = false;
            BackColor = Color.Black;
            Text = "NovoAmanha.Cover";
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.ResizeRedraw, true);
        }

        // Liga/desliga o fundo personalizado (imagem/cor) em vez do preto liso.
        public void UpdateBackdrop(bool on)
        {
            if (on != _bd || (on && (_bdStamp != BackdropStore.Stamp || _bdSize != ClientSize)))
            {
                _bd = on;
                _bdStamp = BackdropStore.Stamp;
                _bdSize = ClientSize;
                Invalidate();
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            if (_bd) BackdropStore.Draw(e.Graphics, ClientRectangle);
            else e.Graphics.Clear(Color.Black);
        }

        protected override bool ShowWithoutActivation { get { return true; } }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= Native.WS_EX_NOACTIVATE | Native.WS_EX_TOOLWINDOW;
                return cp;
            }
        }
    }

    internal partial class Engine : IDisposable
    {
        internal static readonly string[] BrowserProcs = new string[] { "firefox", "msedge", "chrome", "brave", "opera", "vivaldi" };
        private static readonly string[] SkipClasses = new string[]
        {
            "Progman", "WorkerW", "Shell_TrayWnd", "Shell_SecondaryTrayWnd",
            "SysShadow", "NotifyIconOverflowWindow", "TopLevelWindowForOverflowXamlIsland"
        };

        private bool _browsersOnly;
        private bool _black;
        private bool _fullscreen;
        private bool _youtube;
        private bool _swap;                              // troca de navegador ligada
        private string _activeBrowser = "";              // navegador que pode aparecer na compartilhada (nome do processo)
        private string _pendingBring = "";               // navegador a trazer para a compartilhada no próximo ciclo
        private volatile bool _swapDirty;
        private string _swapNote = "";
        private DateTime _audioAt = DateTime.MinValue;
        private bool _audioMuting;
        private readonly Timer _timer = new Timer();       // verificação de segurança (a cada 250 ms)
        private readonly Timer _kickTimer = new Timer();   // reação imediata a eventos do Windows
        private readonly Dictionary<string, CoverForm> _covers = new Dictionary<string, CoverForm>();
        private readonly Dictionary<IntPtr, RECT> _moved = new Dictionary<IntPtr, RECT>();
        private readonly List<IntPtr> _hiddenTaskbars = new List<IntPtr>();
        private readonly List<IntPtr> _hooks = new List<IntPtr>();
        private Native.WinEventProc _winProc;
        private readonly uint _ownPid;
        private volatile bool _displayDirty;
        private bool _inTick;
        private bool _disposed;
        private string _lastError = "";
        private DateTime _lastLog = DateTime.MinValue;

        private void LogOnce(Exception ex)
        {
            _lastError = ex.Message;
            if ((DateTime.UtcNow - _lastLog).TotalSeconds < 30.0) return;
            _lastLog = DateTime.UtcNow;
            ErrorLog.Write(ex);
        }
        private List<Screen> _sharedNow = new List<Screen>();
        private DateTime _lastExtend = DateTime.MinValue;
        private int _extendTries;
        private string _extendMsg = "";

        public event EventHandler Changed;

        public Engine()
        {
            _ownPid = (uint)Process.GetCurrentProcess().Id;
            _timer.Interval = 250;
            _timer.Tick += delegate { Tick(); };
            _kickTimer.Interval = 60;
            _kickTimer.Tick += delegate { _kickTimer.Stop(); Tick(); };
            // Estes eventos chegam em outra thread: só marcam; o Tick (thread da interface) reconstrói.
            SystemEvents.DisplaySettingsChanged += OnDisplaySettings;
            SystemEvents.PowerModeChanged += OnPowerMode;
            SystemEvents.SessionSwitch += OnSessionSwitch;
        }

        private void OnDisplaySettings(object sender, EventArgs e) { _displayDirty = true; }
        private void OnPowerMode(object sender, PowerModeChangedEventArgs e) { _displayDirty = true; }
        private void OnSessionSwitch(object sender, SessionSwitchEventArgs e) { _displayDirty = true; }

        public string LastError { get { return _lastError; } }

        // Há capas do painel na tela (elas mesmas mostram o fundo personalizado).
        public bool HasCovers { get { return _covers.Count > 0; } }

        // Algum recurso está empurrando janelas para fora da tela compartilhada.
        private bool Pushing { get { return _browsersOnly || _youtube || _swap; } }

        // Janelas do relógio: ficam acima de tudo, inclusive da tela preta.
        public static volatile IntPtr[] OverlayHandles = new IntPtr[0];

        public bool BrowsersOnly
        {
            get { return _browsersOnly; }
            set
            {
                _browsersOnly = value;
                if (!Pushing) RestorePositions();   // só devolve as janelas se nenhum recurso continua empurrando
                Apply();
            }
        }

        public bool Black
        {
            get { return _black; }
            set { _black = value; Apply(); }
        }

        public bool Fullscreen
        {
            get { return _fullscreen; }
            set
            {
                _fullscreen = value;
                if (!value) RestoreFullscreen();
                Apply();
            }
        }

        public bool YouTube
        {
            get { return _youtube; }
            set
            {
                _youtube = value;
                RestoreYoutube();
                if (!Pushing) RestorePositions();
                Apply();
            }
        }

        public bool Swap
        {
            get { return _swap; }
            set
            {
                _swap = value;
                if (!Pushing) RestorePositions();
                if (value && _activeBrowser.Length > 0)
                {
                    _pendingBring = _activeBrowser;
                    _swapDirty = true;
                }
                Apply();
            }
        }

        public bool SwapOn { get { return _swap; } }
        public string SwapNote { get { return _swapNote; } }
        public string SwapActive { get { return _activeBrowser; } }

        // Define qual navegador é o "ativo". Se a troca está ligada, ele passa a aparecer na compartilhada.
        public void SwapTo(string proc)
        {
            proc = (proc ?? "").ToLowerInvariant();
            bool changed = _activeBrowser != proc;
            _activeBrowser = proc;
            if (changed && _swap && Active)
            {
                _pendingBring = proc;
                _swapDirty = true;
                if (!_kickTimer.Enabled) _kickTimer.Start();
            }
        }

        // Algum dos 4 botões do início está ligado (apenas telas/navegadores/tela cheia/YouTube; sem a troca de navegador).
        public bool AnyFeature { get { return _browsersOnly || _black || _fullscreen || _youtube; } }

        private bool Active { get { return _browsersOnly || _black || _fullscreen || _youtube || _swap; } }
        private bool NeedCover { get { return _browsersOnly || _black || _youtube || _swap; } }

        // Telas marcadas pelo usuário na lista de dispositivos (nomes tipo \\.\DISPLAY2). Vazio = automático.
        public static volatile string[] SelectedScreens = new string[0];

        // Programas liberados (ex.: Holyrics): nunca são tirados da compartilhada e ficam acima da tela preta.
        public static volatile string[] FreeApps = new string[] { "holyrics", "novoamanhaversiculos" };

        public static void SetFreeApps(string csv)
        {
            List<string> l = new List<string>();
            if (csv != null)
                foreach (string p in csv.Split(new char[] { ',', ';' }))
                {
                    string t = p.Trim().ToLowerInvariant();
                    if (t.Length > 0) l.Add(t);
                }
            // o projetor de versículos do Novo Amanhã é sempre liberado
            if (!l.Contains("novoamanhaversiculos")) l.Add("novoamanhaversiculos");
            FreeApps = l.ToArray();
        }

        // Telas do compartilhamento: as marcadas na lista; se nenhuma estiver marcada, todas as extras.
        // A tela principal (notebook) nunca entra.
        public static List<Screen> SharedScreens()
        {
            List<Screen> list = new List<Screen>();
            Screen[] all = Screen.AllScreens;
            string[] sel = SelectedScreens;
            if (sel != null && sel.Length > 0)
            {
                foreach (Screen s in all)
                    if (!s.Primary && Array.IndexOf(sel, s.DeviceName) >= 0) list.Add(s);
            }
            if (list.Count == 0)
            {
                foreach (Screen s in all)
                    if (!s.Primary) list.Add(s);
            }
            return list;
        }

        public string ExtendMessage { get { return _extendMsg; } }

        public void ResetExtend()
        {
            _extendTries = 0;
            _lastExtend = DateTime.MinValue;
        }

        // Chamado quando a seleção de telas muda.
        public void NotifyScreensChanged()
        {
            _displayDirty = true;
            if (Active && !_kickTimer.Enabled) _kickTimer.Start();
        }

        // Se o Windows está em Duplicar (painel apareceria no projetor), muda para Estender sozinho.
        public void EnsureExtended()
        {
            if (SharedScreens().Count > 0) { _extendTries = 0; _extendMsg = ""; return; }
            TryAutoExtend();
        }

        // Texto de situação de cada recurso (vazio = desligado).
        public string StatusOf(int index)
        {
            bool on = index == 0 ? _browsersOnly : index == 1 ? _black : index == 2 ? _fullscreen : _youtube;
            if (!on) return "";
            if (SharedScreens().Count == 0)
            {
                if (_extendMsg.Length > 0) return _extendMsg;
                if (Screen.AllScreens.Length == 1)
                    return "Só existe 1 tela (a do notebook), então não há o que filtrar. " +
                           "Conecte um projetor/TV ou crie um monitor virtual e compartilhe essa 2ª tela.";
                return "Aguardando a tela compartilhada (Win+P → Estender).";
            }

            string s;
            switch (index)
            {
                case 0:
                    s = "Ativo: só navegadores na tela compartilhada.";
                    break;
                case 1:
                    s = "Ativo: " + _covers.Count + " tela(s) preta(s).";
                    break;
                case 2:
                    s = _fsTotal == 0
                        ? "Ativo: aguardando um navegador na tela compartilhada."
                        : "Tela cheia em " + _fsDone + " de " + _fsTotal + " navegador(es).";
                    break;
                default:
                    s = _ytState.Length > 0 ? _ytState : "Ativo.";
                    break;
            }
            if ((index == 0 || index == 3) && _failedMoves > 0)
                s += " Atenção: " + _failedMoves + " janela(s) não saiu(saíram) da tela compartilhada " +
                     "(janelas protegidas ou travadas). Feche-as ou mova-as à mão.";
            return s;
        }

        // ---------- detecção de telas / modo Duplicar ----------

        // Quantas saídas de vídeo estão ativas (em modo Duplicar há mais saídas do que telas).
        public static int ActivePaths()
        {
            try
            {
                uint paths, modes;
                if (Native.GetDisplayConfigBufferSizes(Native.QDC_ONLY_ACTIVE_PATHS, out paths, out modes) != 0) return -1;
                return (int)paths;
            }
            catch { return -1; }
        }

        public static bool IsDuplicateMode()
        {
            int screens = Screen.AllScreens.Length;
            int paths = ActivePaths();
            return screens >= 1 && paths > screens;
        }

        // Texto de diagnóstico mostrado quando nenhuma tela compartilhada é encontrada.
        public static string Diagnose()
        {
            int screens = Screen.AllScreens.Length;
            int paths = ActivePaths();
            string info = "O Windows vê " + screens + " tela(s)" +
                (paths > 0 ? " e " + paths + " saída(s) ativa(s)" : "") + ". ";
            if (paths > screens) return info + "Modo Duplicar: use Win+P → Estender.";
            if (screens == 1)
                return info + "Só há a tela do notebook: conecte o projetor/TV ou crie um monitor virtual.";
            return info + "Confira o cabo/hub HDMI e use Win+P → Estender.";
        }

        // Com um recurso ligado e o Windows em Duplicar, muda para Estender sozinho (até 3 tentativas).
        private void TryAutoExtend()
        {
            if (!IsDuplicateMode()) { _extendMsg = ""; return; }
            if (_extendTries >= 3)
            {
                _extendMsg = "Não consegui mudar para Estender sozinho. Use Win+P → Estender.";
                return;
            }
            _extendMsg = "O Windows está em modo Duplicar. Mudando para Estender...";
            if ((DateTime.UtcNow - _lastExtend).TotalSeconds < 15.0) return;
            _lastExtend = DateTime.UtcNow;
            _extendTries++;
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo(Path.Combine(Environment.SystemDirectory, "displayswitch.exe"), "/extend");
                psi.UseShellExecute = false;
                psi.CreateNoWindow = true;
                Process.Start(psi);
            }
            catch (Exception ex) { LogOnce(ex); }
            _displayDirty = true;
        }

        private void RaiseChanged()
        {
            if (Changed != null) Changed(this, EventArgs.Empty);
        }

        private void Apply()
        {
            try
            {
                if (Active)
                {
                    if (!_timer.Enabled) { _extendTries = 0; _lastExtend = DateTime.MinValue; }
                    if (!NeedCover) DestroyCovers();
                    InstallHooks();
                    Tick();
                    _timer.Start();
                }
                else
                {
                    _timer.Stop();
                    _kickTimer.Stop();
                    RemoveHooks();
                    DestroyCovers();
                    LowerRaised();   // programas liberados (Holyrics) deixam de ficar fixados no topo
                    try { BrowserAudio.Restore(); _audioMuting = false; } catch { }
                }
                if (!NeedCover) RestoreTaskbars();
            }
            catch (Exception ex) { LogOnce(ex); }
            RaiseChanged();
        }

        // ---------- reação imediata a eventos do Windows ----------

        private void InstallHooks()
        {
            if (_hooks.Count > 0) return;
            _winProc = new Native.WinEventProc(OnWinEvent);
            uint flags = Native.WINEVENT_OUTOFCONTEXT | Native.WINEVENT_SKIPOWNPROCESS;
            AddHook(Native.EVENT_SYSTEM_FOREGROUND, Native.EVENT_SYSTEM_FOREGROUND, flags);
            AddHook(Native.EVENT_OBJECT_SHOW, Native.EVENT_OBJECT_SHOW, flags);
            AddHook(Native.EVENT_OBJECT_LOCATIONCHANGE, Native.EVENT_OBJECT_NAMECHANGE, flags);
        }

        private void AddHook(uint min, uint max, uint flags)
        {
            IntPtr h = Native.SetWinEventHook(min, max, IntPtr.Zero, _winProc, 0, 0, flags);
            if (h != IntPtr.Zero) _hooks.Add(h);
        }

        private void RemoveHooks()
        {
            foreach (IntPtr h in _hooks)
            {
                try { Native.UnhookWinEvent(h); } catch { }
            }
            _hooks.Clear();
        }

        private void OnWinEvent(IntPtr hook, uint evt, IntPtr hwnd, int idObject, int idChild, uint thread, uint time)
        {
            if (_disposed || !Active || _inTick) return;
            if (idObject != Native.OBJID_WINDOW || hwnd == IntPtr.Zero) return;
            if (!_kickTimer.Enabled) _kickTimer.Start();
        }

        // ---------- capas pretas ----------

        private void RebuildCovers()
        {
            DestroyCovers();
            if (!NeedCover) return;
            foreach (Screen s in SharedScreens())
            {
                CoverForm f = new CoverForm();
                f.Bounds = s.Bounds;
                f.TopMost = _black;
                f.Show();
                _covers[s.DeviceName] = f;
            }
        }

        private void DestroyCovers()
        {
            ClearMirror();
            foreach (CoverForm f in _covers.Values)
            {
                try { f.Close(); f.Dispose(); } catch { }
            }
            _covers.Clear();
        }

        private void Tick()
        {
            if (!Active || _inTick || _disposed) return;
            _inTick = true;
            try
            {
                List<Screen> shared = SharedScreens();
                _sharedNow = shared;

                if (shared.Count == 0) TryAutoExtend();
                else { _extendTries = 0; _extendMsg = ""; }

                if (NeedCover)
                {
                    bool bad = _displayDirty || _covers.Count != shared.Count;
                    foreach (Screen s in shared)
                        if (!_covers.ContainsKey(s.DeviceName)) bad = true;
                    foreach (CoverForm cf in _covers.Values)
                        if (cf.IsDisposed || !cf.Visible) bad = true;
                    if (bad)
                    {
                        _displayDirty = false;
                        RebuildCovers();
                    }
                    HideSecondaryTaskbars();
                }

                if (_swapDirty)
                {
                    _swapDirty = false;
                    HandleSwap(shared);
                }

                if (_youtube) YouTubeTick(shared);
                else if (_browsersOnly || _swap) MoveNonBrowsers(shared);

                if (_fullscreen && !_youtube) FullscreenTick(shared);

                IntPtr lowestShown = NeedCover ? RaiseShown(shared) : IntPtr.Zero;

                if (NeedCover)
                {
                    foreach (Screen s in shared)
                    {
                        CoverForm f;
                        if (!_covers.TryGetValue(s.DeviceName, out f)) continue;
                        if (f.Bounds != s.Bounds) f.Bounds = s.Bounds;
                        f.UpdateBackdrop(!_black && BackdropStore.On);
                        if (_black)
                        {
                            if (!f.TopMost) f.TopMost = true;
                            // reafirma o topo: nenhuma outra janela "sempre visível" fica acima da tela preta,
                            // exceto as liberadas (Holyrics) e o vídeo da TV, que ficam por cima dela.
                            Native.SetWindowPos(f.Handle, lowestShown != IntPtr.Zero ? lowestShown : Native.HWND_TOPMOST,
                                0, 0, 0, 0, Native.SWP_NOMOVE | Native.SWP_NOSIZE | Native.SWP_NOACTIVATE);
                        }
                        else
                        {
                            if (f.TopMost) f.TopMost = false;
                            if (BackdropStore.On)
                                DesktopZ.Place(f.Handle);   // fundo personalizado: logo acima do papel de parede e dos ícones
                            else
                                Native.SetWindowPos(f.Handle, Native.HWND_BOTTOM, 0, 0, 0, 0,
                                    Native.SWP_NOMOVE | Native.SWP_NOSIZE | Native.SWP_NOACTIVATE);
                        }
                    }
                    // o relógio sempre fica acima da tela preta e das janelas liberadas
                    IntPtr[] ov = OverlayHandles;
                    if (ov != null)
                        foreach (IntPtr oh in ov)
                            if (oh != IntPtr.Zero && Native.IsWindow(oh))
                                Native.SetWindowPos(oh, Native.HWND_TOPMOST, 0, 0, 0, 0,
                                    Native.SWP_NOMOVE | Native.SWP_NOSIZE | Native.SWP_NOACTIVATE);
                }

                UpdatePushState();
                AudioTick();
            }
            catch (Exception ex) { LogOnce(ex); }
            finally { _inTick = false; }
        }

        // Troca de navegador ligada: só o navegador ativo toca som; os outros ficam mudos.
        private void AudioTick()
        {
            try
            {
                bool want = _swap && _activeBrowser.Length > 0;
                if (!want)
                {
                    if (_audioMuting) { BrowserAudio.Restore(); _audioMuting = false; }
                    return;
                }
                if ((DateTime.UtcNow - _audioAt).TotalMilliseconds < 600) return;
                _audioAt = DateTime.UtcNow;
                _audioMuting = true;
                BrowserAudio.Enforce(_activeBrowser, BrowserProcs);
            }
            catch (Exception ex) { _lastError = ex.Message; }
        }

        private void HideSecondaryTaskbars()
        {
            Guard.HideTaskbarsOn(_sharedNow, _hiddenTaskbars);
        }

        private void RestoreTaskbars()
        {
            // com o fundo personalizado ligado, a barra da tela compartilhada nunca deve reaparecer
            if (BackdropStore.On && SharedScreens().Count > 0 && !_disposed)
            {
                _hiddenTaskbars.Clear();
                return;
            }
            foreach (IntPtr h in _hiddenTaskbars) Native.ShowWindow(h, Native.SW_SHOWNA);
            _hiddenTaskbars.Clear();
            Guard.SweepTaskbars();
        }

        // Botão "Liberar tudo": desliga todos os recursos e devolve janelas e barras de tarefas.
        public void ReleaseAll()
        {
            _browsersOnly = false;
            _black = false;
            _fullscreen = false;
            _youtube = false;
            _swap = false;
            _pendingBring = "";
            _swapNote = "";
            _swapDirty = false;
            RestoreWindows();
            Apply();
            RestoreTaskbars();
        }

        public void Shutdown()
        {
            _timer.Stop();
            _kickTimer.Stop();
            RemoveHooks();
            DestroyCovers();
            RestoreWindows();
            RestoreTaskbars();
            try { BrowserAudio.Restore(); } catch { }
        }

        public void Dispose()
        {
            Shutdown();
            _disposed = true;
            StopFast();
            SystemEvents.DisplaySettingsChanged -= OnDisplaySettings;
            SystemEvents.PowerModeChanged -= OnPowerMode;
            SystemEvents.SessionSwitch -= OnSessionSwitch;
            _timer.Dispose();
            _kickTimer.Dispose();
        }
    }
}
