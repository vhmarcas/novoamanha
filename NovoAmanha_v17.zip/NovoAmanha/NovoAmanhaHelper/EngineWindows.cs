using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace NovoAmanha
{
    internal partial class Engine
    {
        private struct Win
        {
            public IntPtr H;
            public uint Pid;
            public RECT R;
            public string Title;
            public bool IsBrowser;
            public string Browser;   // nome do processo do navegador (minúsculo) ou ""
            public bool IsFree;      // programa liberado (ex.: Holyrics): não mexer
        }

        private class PushInfo
        {
            public int Tries;
            public DateTime Last;
        }

        private const byte VK_F11 = 0x7A;
        private const byte VK_F = 0x46;
        private const byte VK_ESCAPE = 0x1B;
        private const byte VK_CONTROL = 0x11;
        private const byte VK_L = 0x4C;
        private const byte VK_V = 0x56;
        private const byte VK_N = 0x4E;
        private const byte VK_K = 0x4B;
        private const byte VK_RETURN = 0x0D;

        private IntPtr _ytWindow = IntPtr.Zero;
        private string _ytLastTitle = "";
        private string _ytState = "";
        private int _fsTotal, _fsDone, _failedMoves;
        private readonly List<IntPtr> _fsApplied = new List<IntPtr>();   // janelas com F11 aplicado
        private readonly List<IntPtr> _ytFs = new List<IntPtr>();        // janelas com o player em tela cheia (tecla F)
        private readonly Dictionary<IntPtr, int> _f11Attempts = new Dictionary<IntPtr, int>();
        private readonly Dictionary<IntPtr, DateTime> _f11Last = new Dictionary<IntPtr, DateTime>();
        private readonly Dictionary<IntPtr, PushInfo> _push = new Dictionary<IntPtr, PushInfo>();
        private readonly Dictionary<uint, string> _browserCache = new Dictionary<uint, string>();
        private readonly Dictionary<uint, string> _nameCache = new Dictionary<uint, string>();
        private readonly List<IntPtr> _raised = new List<IntPtr>();      // janelas que o programa colocou "sempre por cima"
        private DateTime _cacheStamp = DateTime.UtcNow;

        // ---------- listagem de janelas ----------

        private List<Win> ListWindows()
        {
            List<Win> list = new List<Win>();
            if ((DateTime.UtcNow - _cacheStamp).TotalSeconds > 60)
            {
                _browserCache.Clear();
                _nameCache.Clear();
                _cacheStamp = DateTime.UtcNow;
            }
            Native.EnumWindows(delegate(IntPtr h, IntPtr lp)
            {
                if (!Native.IsWindowVisible(h) || Native.IsIconic(h)) return true;
                string title = Native.TitleOf(h);
                if (title.Length == 0) return true;
                int ex = Native.GetWindowLong(h, Native.GWL_EXSTYLE);
                if ((ex & Native.WS_EX_TOOLWINDOW) != 0) return true;
                int cloaked;
                if (Native.DwmGetWindowAttribute(h, Native.DWMWA_CLOAKED, out cloaked, 4) == 0 && cloaked != 0) return true;

                string cls = Native.ClassOf(h);
                foreach (string c in SkipClasses) if (cls == c) return true;

                uint pid;
                Native.GetWindowThreadProcessId(h, out pid);
                if (pid == _ownPid || pid == 0) return true;

                RECT r;
                if (!Native.GetWindowRect(h, out r)) return true;

                string bname = BrowserNameFor(pid);

                Win w = new Win();
                w.H = h;
                w.Pid = pid;
                w.R = r;
                w.Title = title;
                w.IsBrowser = bname.Length > 0;
                w.Browser = bname;
                w.IsFree = !w.IsBrowser && IsFreeApp(pid, title);
                list.Add(w);
                return true;
            }, IntPtr.Zero);
            return list; // ordem de empilhamento: de cima para baixo
        }

        private static string BrowserNameOfPid(uint pid)
        {
            try
            {
                string name = Process.GetProcessById((int)pid).ProcessName.ToLowerInvariant();
                foreach (string b in BrowserProcs) if (name == b) return b;
            }
            catch { }
            return "";
        }

        private string ProcNameFor(uint pid)
        {
            string n;
            if (!_nameCache.TryGetValue(pid, out n))
            {
                n = "";
                try { using (Process p = Process.GetProcessById((int)pid)) n = p.ProcessName.ToLowerInvariant(); }
                catch { }
                _nameCache[pid] = n;
            }
            return n;
        }

        // Programa liberado (lista "free_apps" do config; padrão: Holyrics). Navegadores nunca contam.
        private bool IsFreeApp(uint pid, string title)
        {
            string[] apps = FreeApps;
            if (apps == null || apps.Length == 0) return false;
            string n = ProcNameFor(pid);
            string t = (title ?? "").ToLowerInvariant();
            foreach (string a in apps)
            {
                if (a.Length == 0) continue;
                if (n.IndexOf(a, StringComparison.Ordinal) >= 0) return true;
                // programas Java (como o Holyrics) aparecem como "java"/"javaw": aí o título decide.
                // Para qualquer outro programa o título NÃO conta (uma janela com "holyrics" no título não escapa do filtro).
                if ((n == "java" || n == "javaw") && t.IndexOf(a, StringComparison.Ordinal) >= 0) return true;
            }
            return false;
        }

        // Põe "sempre por cima" as janelas liberadas que estão na compartilhada (e o vídeo da TV, quando pronto),
        // para aparecerem acima da tela preta. Devolve a mais baixa delas (a tela preta fica logo abaixo) ou
        // Zero se não há nenhuma / alguma acabou de ser levantada (então a tela preta só reafirma o topo neste ciclo).
        private IntPtr RaiseShown(List<Screen> shared)
        {
            if (shared.Count == 0) return IntPtr.Zero;
            List<IntPtr> want = new List<IntPtr>();   // de cima para baixo
            Native.EnumWindows(delegate(IntPtr h, IntPtr lp)
            {
                if (!Native.IsWindowVisible(h) || Native.IsIconic(h)) return true;
                uint pid;
                Native.GetWindowThreadProcessId(h, out pid);
                if (pid == _ownPid || pid == 0) return true;
                RECT r;
                if (!Native.GetWindowRect(h, out r) || r.Width <= 0 || r.Height <= 0) return true;

                bool tv = _youtube && h == _tvWin;
                if (tv)
                {
                    // com tela preta, o vídeo da TV só aparece quando já está em tela cheia tocando um vídeo
                    if (_black && !(IsFullscreenRect(r) && IsWatchPage(Native.TitleOf(h)))) return true;
                }
                else
                {
                    string cls = Native.ClassOf(h);
                    foreach (string c in SkipClasses) if (cls == c) return true;
                    if (BrowserNameFor(pid).Length > 0) return true;
                    if (!IsFreeApp(pid, Native.TitleOf(h))) return true;
                }
                if (!OnShared(r, shared)) return true;
                want.Add(h);
                return true;
            }, IntPtr.Zero);

            if (want.Count == 0) return IntPtr.Zero;

            bool allTop = true;
            bool tvRaised = false;
            foreach (IntPtr h in want)
            {
                if ((Native.GetWindowLong(h, Native.GWL_EXSTYLE) & Native.WS_EX_TOPMOST) != 0) continue;
                allTop = false;
                if (!_raised.Contains(h)) _raised.Add(h);
                if (h == _tvWin) tvRaised = true;
                Native.SetWindowPos(h, Native.HWND_TOPMOST, 0, 0, 0, 0,
                    Native.SWP_NOMOVE | Native.SWP_NOSIZE | Native.SWP_NOACTIVATE | Native.SWP_ASYNCWINDOWPOS);
            }
            if (tvRaised)
                foreach (IntPtr h in want)
                    if (h != _tvWin)   // os liberados (Holyrics) ficam acima do vídeo
                        Native.SetWindowPos(h, Native.HWND_TOPMOST, 0, 0, 0, 0,
                            Native.SWP_NOMOVE | Native.SWP_NOSIZE | Native.SWP_NOACTIVATE | Native.SWP_ASYNCWINDOWPOS);
            return allTop ? want[want.Count - 1] : IntPtr.Zero;
        }

        private void LowerRaised()
        {
            foreach (IntPtr h in _raised)
            {
                try
                {
                    if (Native.IsWindow(h))
                        Native.SetWindowPos(h, Native.HWND_NOTOPMOST, 0, 0, 0, 0,
                            Native.SWP_NOMOVE | Native.SWP_NOSIZE | Native.SWP_NOACTIVATE | Native.SWP_ASYNCWINDOWPOS);
                }
                catch { }
            }
            _raised.Clear();
        }

        private string BrowserNameFor(uint pid)
        {
            string n;
            if (!_browserCache.TryGetValue(pid, out n))
            {
                n = BrowserNameOfPid(pid);
                _browserCache[pid] = n;
            }
            return n;
        }

        // Janela "está" na tela compartilhada se o centro dela está lá ou se pelo menos 20% dela está lá.
        internal static bool OnShared(RECT r, List<Screen> shared)
        {
            Point center = new Point(r.Left + r.Width / 2, r.Top + r.Height / 2);
            foreach (Screen s in shared)
                if (s.Bounds.Contains(center)) return true;

            long area = (long)r.Width * r.Height;
            if (area <= 0) return false;
            Rectangle wr = new Rectangle(r.Left, r.Top, r.Width, r.Height);
            foreach (Screen s in shared)
            {
                Rectangle i = Rectangle.Intersect(s.Bounds, wr);
                if (i.Width > 0 && i.Height > 0 && (long)i.Width * i.Height * 5 >= area) return true;
            }
            return false;
        }

        private static bool IsFullscreenRect(RECT r)
        {
            Point center = new Point(r.Left + r.Width / 2, r.Top + r.Height / 2);
            Rectangle b = Screen.FromPoint(center).Bounds;
            return Math.Abs(r.Left - b.Left) <= 2 && Math.Abs(r.Top - b.Top) <= 2 &&
                   Math.Abs(r.Width - b.Width) <= 2 && Math.Abs(r.Height - b.Height) <= 2;
        }

        // ---------- mover janelas ----------

        // Posiciona sem travar mesmo que a janela esteja "não respondendo".
        private static bool Place(IntPtr h, int x, int y, int w, int hh)
        {
            return Native.SetWindowPos(h, IntPtr.Zero, x, y, w, hh,
                Native.SWP_NOZORDER | Native.SWP_NOACTIVATE | Native.SWP_ASYNCWINDOWPOS);
        }

        private void PushToPrimary(Win w)
        {
            PushInfo pi;
            if (!_push.TryGetValue(w.H, out pi))
            {
                pi = new PushInfo();
                _push[w.H] = pi;
            }
            if ((DateTime.UtcNow - pi.Last).TotalMilliseconds < 300) return;
            pi.Last = DateTime.UtcNow;
            pi.Tries++;

            if (_fsApplied.Contains(w.H))
            {
                if (IsFullscreenRect(w.R)) SendF11(w.H);
                _fsApplied.Remove(w.H);
            }
            if (_ytFs.Contains(w.H))
            {
                if (IsFullscreenRect(w.R)) SendKey(w.H, VK_ESCAPE);
                _ytFs.Remove(w.H);
            }

            Rectangle work = Screen.PrimaryScreen.WorkingArea;
            if (!_moved.ContainsKey(w.H)) _moved[w.H] = w.R;
            if (Native.IsZoomed(w.H)) Native.ShowWindow(w.H, Native.SW_RESTORE);
            int ww = Math.Min(w.R.Width, work.Width);
            int hh = Math.Min(w.R.Height, work.Height);
            Place(w.H, work.Left + 40, work.Top + 40, ww, hh);
        }

        private void MoveToShared(Win w, Screen target)
        {
            Rectangle b = target.Bounds;
            if (!_moved.ContainsKey(w.H)) _moved[w.H] = w.R;
            if (Native.IsZoomed(w.H)) Native.ShowWindow(w.H, Native.SW_RESTORE);
            int ww = Math.Min(w.R.Width, b.Width - 100);
            int hh = Math.Min(w.R.Height, b.Height - 100);
            Place(w.H, b.Left + 50, b.Top + 50, ww, hh);
        }

        private void MoveNonBrowsers(List<Screen> shared)
        {
            foreach (Win w in ListWindows())
            {
                if (!OnShared(w.R, shared)) continue;
                if (w.IsFree) continue;                      // Holyrics e afins: livres na compartilhada
                if (!w.IsBrowser) PushToPrimary(w);
                else if (!BrowserAllowed(w)) PushToPrimary(w);   // troca de navegador: o outro fica só no notebook
            }
        }

        // Janelas que continuam na tela compartilhada depois de várias tentativas (ex.: programas em modo administrador).
        private void UpdatePushState()
        {
            List<IntPtr> remove = new List<IntPtr>();
            int failed = 0;
            foreach (KeyValuePair<IntPtr, PushInfo> kv in _push)
            {
                RECT r;
                if (!Native.IsWindow(kv.Key) || !Native.GetWindowRect(kv.Key, out r) || !OnShared(r, _sharedNow))
                {
                    remove.Add(kv.Key);
                    continue;
                }
                if (kv.Value.Tries >= 6) failed++;
            }
            foreach (IntPtr h in remove) _push.Remove(h);
            _failedMoves = failed;
        }

        // ---------- tentativas de tela cheia (com nova chance depois de uns segundos) ----------

        // true = pode tentar agora. exhausted = já tentou 3 vezes (volta a tentar depois de 8 s).
        private bool Gate(IntPtr h, out bool exhausted)
        {
            exhausted = false;
            int n;
            _f11Attempts.TryGetValue(h, out n);
            DateTime last;
            bool has = _f11Last.TryGetValue(h, out last);
            double age = has ? (DateTime.UtcNow - last).TotalSeconds : 999.0;
            if (n >= 3)
            {
                if (age < 8.0) { exhausted = true; return false; }
                n = 0;
            }
            if (age < 2.5) return false;
            _f11Last[h] = DateTime.UtcNow;
            _f11Attempts[h] = n + 1;
            return true;
        }

        // ---------- modo "navegador sem barras" (tela cheia F11) ----------

        private void FullscreenTick(List<Screen> shared)
        {
            int total = 0, done = 0;
            foreach (Win w in ListWindows())
            {
                if (!w.IsBrowser || !OnShared(w.R, shared)) continue;
                total++;
                if (IsFullscreenRect(w.R)) { done++; continue; }
                TryEnterFullscreen(w.H);
            }
            _fsTotal = total;
            _fsDone = done;
        }

        private void TryEnterFullscreen(IntPtr h)
        {
            bool exhausted;
            if (!Gate(h, out exhausted)) return;
            if (SendF11(h) && !_fsApplied.Contains(h)) _fsApplied.Add(h);
        }

        // ---------- modo "só YouTube" ----------

        private class UrlInfo
        {
            public string Title;
            public string Url;
            public DateTime At;
        }

        private readonly Dictionary<IntPtr, UrlInfo> _urls = new Dictionary<IntPtr, UrlInfo>();
        private DateTime _ytLostSince = DateTime.MinValue;

        // Página de vídeo/Shorts: o título é "Nome do vídeo - YouTube" (a página inicial é só "YouTube").
        // Atenção: a página de busca/canal também tem o formato "texto - YouTube"; por isso, quando dá,
        // o endereço da aba é conferido em IsWatchNow.
        private static bool IsWatchPage(string title)
        {
            return title.IndexOf(" - YouTube", StringComparison.OrdinalIgnoreCase) > 0;
        }

        private static bool IsWatchUrl(string url)
        {
            string u = url.ToLowerInvariant();
            return u.IndexOf("/watch", StringComparison.Ordinal) >= 0 ||
                   u.IndexOf("/shorts/", StringComparison.Ordinal) >= 0 ||
                   u.IndexOf("/live/", StringComparison.Ordinal) >= 0 ||
                   u.IndexOf("youtu.be/", StringComparison.Ordinal) >= 0;
        }

        // Endereço da aba ativa (só com a leitura de abas ativada no build; guarda por 5 s para não pesar).
        private string UrlOf(Win w)
        {
            if (!TabScanner.Available) return null;
            UrlInfo ui;
            if (_urls.TryGetValue(w.H, out ui) && ui.Title == w.Title && (DateTime.UtcNow - ui.At).TotalSeconds < 5.0)
                return ui.Url;
            if (ui == null)
            {
                ui = new UrlInfo();
                _urls[w.H] = ui;
            }
            ui.Title = w.Title;
            ui.Url = TabScanner.AddressBar(w.H);
            ui.At = DateTime.UtcNow;
            return ui.Url;
        }

        // true = a aba ativa deste navegador está mesmo num vídeo (não na página inicial nem na busca).
        private bool IsWatchNow(Win w)
        {
            if (!IsWatchPage(w.Title)) return false;
            string url = UrlOf(w);
            if (url == null || url.Length == 0) return true;   // sem leitura do endereço: confia no título
            return IsWatchUrl(url);
        }

        // ---------- modo "só YouTube" com janela própria na TV ----------
        // A janela do notebook fica livre para navegar. Quando ela abre um vídeo, o programa abre uma
        // SEGUNDA janela do navegador (Ctrl+N), leva para a TV, abre o mesmo vídeo e põe em tela cheia de verdade.
        // O vídeo do notebook é pausado para não tocar duas vezes.

        private IntPtr _tvWin = IntPtr.Zero;
        private string _tvUrl = "";
        private string _tvNavUrl = "";
        private bool _tvPending;
        private DateTime _tvLaunch = DateTime.MinValue;
        private DateTime _tvRetryAt = DateTime.MinValue;
        private Dictionary<IntPtr, bool> _tvBefore;

        private static string NormUrl(string u)
        {
            int i = u.IndexOf("://", StringComparison.Ordinal);
            if (i >= 0) u = u.Substring(i + 3);
            if (u.StartsWith("www.", StringComparison.OrdinalIgnoreCase)) u = u.Substring(4);
            return u;
        }

        // Identifica o vídeo (ignora parâmetros que mudam, como o tempo).
        private static string VideoKey(string url)
        {
            string u = NormUrl(url);
            int i = u.IndexOf("v=", StringComparison.Ordinal);
            if (i > 0 && (u[i - 1] == '?' || u[i - 1] == '&'))
            {
                int e = u.IndexOf('&', i);
                return e < 0 ? u.Substring(i) : u.Substring(i, e - i);
            }
            return u;
        }

        private static string FullUrl(string url)
        {
            return url.IndexOf("://", StringComparison.Ordinal) > 0 ? url : "https://" + url;
        }

        private void YouTubeTick(List<Screen> shared)
        {
            if (shared.Count == 0) { _ytState = ""; ClearMirror(); return; }
            if (!TabScanner.Available) { YouTubeMirrorTick(shared); return; }

            List<Win> wins = ListWindows();

            // janela da TV (a que o programa abriu)
            Win tv = new Win();
            bool haveTv = false;
            if (_tvWin != IntPtr.Zero)
            {
                foreach (Win w in wins)
                    if (w.H == _tvWin) { tv = w; haveTv = true; break; }
                if (!haveTv && !_tvPending && !Native.IsWindow(_tvWin)) _tvWin = IntPtr.Zero;
            }

            // procurando a janela nova que o Ctrl+N abriu
            if (_tvPending)
            {
                if (!haveTv && _tvBefore != null)
                {
                    foreach (Win w in wins)
                    {
                        if (w.IsBrowser && !_tvBefore.ContainsKey(w.H))
                        {
                            _tvWin = w.H;
                            tv = w;
                            haveTv = true;
                            _tvPending = false;
                            _tvBefore = null;
                            _f11Attempts.Remove(w.H);
                            if (_tvNavUrl.Length > 0) NavigateTv(w.H, _tvNavUrl);
                            break;
                        }
                    }
                }
                if (_tvPending && (DateTime.UtcNow - _tvLaunch).TotalSeconds > 8.0)
                {
                    _tvPending = false;
                    _tvBefore = null;
                    _tvUrl = "";
                    _tvRetryAt = DateTime.UtcNow.AddSeconds(30);
                }
            }

            // janela do notebook com um vídeo aberto
            Win a = new Win();
            string aUrl = null;
            bool haveA = false, urlUnknown = false;
            foreach (Win w in wins)
            {
                if (!w.IsBrowser || w.H == _tvWin || !BrowserAllowed(w) || OnShared(w.R, shared) || !IsWatchPage(w.Title)) continue;
                string u = UrlOf(w);
                if (u == null || u.Length == 0) { urlUnknown = true; continue; }
                if (IsWatchUrl(u)) { a = w; aUrl = u; haveA = true; break; }
            }

            // não deu para ler o endereço e não há janela na TV: usa o espelho
            if (!haveA && urlUnknown && !haveTv && !_tvPending)
            {
                YouTubeMirrorTick(shared);
                return;
            }
            ClearMirror();

            if (haveA && !_tvPending && DateTime.UtcNow >= _tvRetryAt)
            {
                string key = VideoKey(aUrl);
                if (key != _tvUrl)
                {
                    _tvUrl = key;
                    _tvNavUrl = FullUrl(aUrl);
                    SendKey(a.H, VK_K);   // pausa o vídeo no notebook
                    if (haveTv)
                    {
                        NavigateTv(tv.H, _tvNavUrl);
                    }
                    else
                    {
                        _tvBefore = new Dictionary<IntPtr, bool>();
                        foreach (Win w in wins) if (w.IsBrowser) _tvBefore[w.H] = true;
                        _tvPending = true;
                        _tvLaunch = DateTime.UtcNow;
                        SendSeq(a.H, new byte[][] { new byte[] { VK_CONTROL, VK_N } });   // nova janela
                    }
                }
            }

            // nada além da janela da TV fica na tela compartilhada
            foreach (Win w in wins)
            {
                if (haveTv && w.H == tv.H) continue;
                if (w.IsFree) continue;
                if (OnShared(w.R, shared)) PushToPrimary(w);
            }

            if (_tvPending)
            {
                _ytState = "Abrindo o vídeo na TV...";
                return;
            }
            if (!haveTv)
            {
                _ytState = DateTime.UtcNow < _tvRetryAt
                    ? "Não consegui abrir a janela da TV. Vou tentar de novo em instantes."
                    : "Aguardando um vídeo do YouTube. Escolha um vídeo na janela do notebook: ele abre em tela cheia na TV.";
                return;
            }

            if (!OnShared(tv.R, shared))
            {
                MoveToShared(tv, shared[0]);
                _ytState = "Abrindo o vídeo na TV...";
                return;
            }

            if (tv.Title != _ytLastTitle)
            {
                _ytLastTitle = tv.Title;
                _f11Attempts.Remove(tv.H);   // vídeo novo: tentativas zeradas
            }

            if (IsFullscreenRect(tv.R))
            {
                _ytState = "Ativo: vídeo em tela cheia na TV. A janela do notebook está livre para navegar.";
                return;
            }

            if (!IsWatchPage(tv.Title))
            {
                _ytState = "Abrindo o vídeo na TV...";
                return;
            }

            bool exhausted;
            if (Gate(tv.H, out exhausted))
            {
                if (SendKey(tv.H, VK_F) && !_ytFs.Contains(tv.H)) _ytFs.Add(tv.H);
                _ytState = "Abrindo o vídeo na TV...";
            }
            else if (exhausted)
            {
                _ytState = "Não consegui entrar em tela cheia na TV. Clique no vídeo da TV e aperte F (vou tentar de novo).";
            }
            else
            {
                _ytState = "Abrindo o vídeo na TV...";
            }
        }

        // Abre o endereço na janela da TV: Ctrl+L, colar, Enter.
        private void NavigateTv(IntPtr h, string url)
        {
            string old = null;
            try { if (Clipboard.ContainsText()) old = Clipboard.GetText(); }
            catch { }
            try { Clipboard.SetText(url); }
            catch { return; }
            SendSeq(h, new byte[][]
            {
                new byte[] { VK_CONTROL, VK_L },
                new byte[] { VK_CONTROL, VK_V },
                new byte[] { 0, VK_RETURN }
            });
            try { if (old != null) Clipboard.SetText(old); }   // devolve o que o usuário tinha copiado
            catch { }
        }

        // Modo de reserva: espelho do player (usado quando o programa não consegue ler o endereço da aba).
        private void YouTubeMirrorTick(List<Screen> shared)
        {
            if (shared.Count == 0) { _ytState = ""; ClearMirror(); return; }
            List<Win> wins = ListWindows();

            Win yt = new Win();
            bool have = false;

            // 1) Janela já escolhida: continua nela enquanto o título for de vídeo.
            //    Se o título some por instantes (carregando outro vídeo), espera 4 s antes de largar.
            if (_ytWindow != IntPtr.Zero)
            {
                foreach (Win w in wins)
                    if (w.H == _ytWindow && w.IsBrowser && BrowserAllowed(w)) { yt = w; have = true; break; }
                if (have)
                {
                    if (IsWatchPage(yt.Title)) _ytLostSince = DateTime.MinValue;
                    else
                    {
                        if (_ytLostSince == DateTime.MinValue) _ytLostSince = DateTime.UtcNow;
                        if ((DateTime.UtcNow - _ytLostSince).TotalSeconds > 4.0) have = false;
                    }
                }
            }

            // 2) Sem janela escolhida: procura um navegador que esteja num VÍDEO.
            //    A página inicial e a busca do YouTube ficam no notebook para dar para navegar.
            if (!have)
            {
                _ytWindow = IntPtr.Zero;
                _ytLostSince = DateTime.MinValue;
                foreach (Win w in wins)
                    if (w.IsBrowser && BrowserAllowed(w) && IsWatchNow(w)) { yt = w; have = true; _ytWindow = w.H; break; }
            }

            // Nenhuma janela fica na tela compartilhada (a TV só mostra o espelho do vídeo).
            foreach (Win w in wins)
                if (!w.IsFree && OnShared(w.R, shared)) PushToPrimary(w);

            if (!have)
            {
                ClearMirror();
                _ytState = "Aguardando um vídeo do YouTube. Abra um vídeo no notebook: a TV passa a mostrar uma cópia dele.";
                return;
            }

            // A janela do YouTube NÃO sai do notebook: a TV recebe uma cópia ao vivo só do player.
            if (TabScanner.Available) EnsureFast(yt.H); else RefreshPlayer(yt.H);
            PlayerInfo pi = _player;
            Rectangle? player = null;
            if (pi != null && pi.H == yt.H && pi.Ok) player = pi.R;

            foreach (Screen s in shared)
            {
                CoverForm f;
                if (_covers.TryGetValue(s.DeviceName, out f)) MirrorTo(f, s.DeviceName, yt, player);
            }
            _ytState = player.HasValue
                ? "Ativo: só o vídeo aparece em tela cheia na tela compartilhada."
                : "Ativo: espelhando o navegador (não consegui achar o player; usando corte aproximado).";
        }

        // ---------- posição do player (lida em segundo plano para não travar) ----------

        private class PlayerInfo
        {
            public IntPtr H;
            public Rectangle R;
            public bool Ok;
        }

        private volatile PlayerInfo _player;
        private int _playerBusy;
        private DateTime _playerAsk = DateTime.MinValue;

        private void RefreshPlayer(IntPtr h)
        {
            if (_playerBusy != 0) return;
            if ((DateTime.UtcNow - _playerAsk).TotalMilliseconds < 700) return;
            _playerAsk = DateTime.UtcNow;
            _playerBusy = 1;
            ThreadPool.QueueUserWorkItem(delegate(object state)
            {
                try
                {
                    Rectangle? r = TabScanner.PlayerRect(h);
                    PlayerInfo pi = new PlayerInfo();
                    pi.H = h;
                    pi.Ok = r.HasValue;
                    if (r.HasValue) pi.R = r.Value;
                    _player = pi;
                }
                catch { }
                finally { _playerBusy = 0; }
            });
        }

        // ---------- verificação rápida da posição do player ----------
        // Uma thread própria lê a posição do player sem parar (intervalo de 1 ms entre uma leitura e outra;
        // a leitura em si leva o tempo que o navegador demorar para responder). Quando o player ou a janela
        // mudam de lugar, o espelho na tela compartilhada é atualizado na hora, sem esperar o ciclo de 250 ms.

        private const int FastPollMs = 1;
        private Thread _fastThread;
        private volatile bool _fastRun;
        private volatile IntPtr _fastTarget = IntPtr.Zero;
        private SynchronizationContext _ui;
        private int _fastPost;

        private void EnsureFast(IntPtr h)
        {
            if (_ui == null) _ui = SynchronizationContext.Current;
            _fastTarget = h;
            if (_fastThread != null && _fastThread.IsAlive) return;
            _fastRun = true;
            _fastThread = new Thread(FastLoop);
            _fastThread.IsBackground = true;
            _fastThread.Name = "PlayerFast";
            _fastThread.Priority = ThreadPriority.AboveNormal;
            _fastThread.Start();
        }

        private void StopFast()
        {
            _fastRun = false;
            _fastTarget = IntPtr.Zero;
        }

        private void FastLoop()
        {
            try { Native.timeBeginPeriod(1); } catch { }
            RECT lastWin = new RECT();
            while (_fastRun)
            {
                IntPtr h = _fastTarget;
                if (h == IntPtr.Zero) { Thread.Sleep(20); continue; }
                bool changed = false;
                bool found = false;
                try
                {
                    Rectangle? r = TabScanner.PlayerRect(h);
                    found = r.HasValue;
                    PlayerInfo pi = new PlayerInfo();
                    pi.H = h;
                    pi.Ok = found;
                    if (found) pi.R = r.Value;
                    PlayerInfo old = _player;
                    if (old == null || old.H != h || old.Ok != pi.Ok || (pi.Ok && old.R != pi.R)) changed = true;
                    _player = pi;

                    RECT wr;
                    if (Native.GetWindowRect(h, out wr))
                    {
                        if (wr.Left != lastWin.Left || wr.Top != lastWin.Top || wr.Right != lastWin.Right || wr.Bottom != lastWin.Bottom)
                        {
                            lastWin = wr;
                            changed = true;
                        }
                    }
                }
                catch { }

                SynchronizationContext ui = _ui;
                if (changed && ui != null && Interlocked.Exchange(ref _fastPost, 1) == 0)
                {
                    ui.Post(delegate(object state)
                    {
                        _fastPost = 0;
                        FastMirror();
                    }, null);
                }
                // sem player achado: dá um respiro maior para não sobrecarregar o navegador
                Thread.Sleep(found ? FastPollMs : 50);
            }
            try { Native.timeEndPeriod(1); } catch { }
        }

        // Roda na thread da interface: refaz o recorte do espelho com a posição mais recente.
        private void FastMirror()
        {
            try
            {
                if (_disposed || !_youtube) return;
                IntPtr h = _fastTarget;
                if (h == IntPtr.Zero || !Native.IsWindow(h)) return;
                RECT wr;
                if (!Native.GetWindowRect(h, out wr)) return;
                Win yt = new Win();
                yt.H = h;
                yt.R = wr;
                PlayerInfo pi = _player;
                Rectangle? player = null;
                if (pi != null && pi.H == h && pi.Ok) player = pi.R;
                foreach (Screen s in _sharedNow)
                {
                    CoverForm f;
                    if (_covers.TryGetValue(s.DeviceName, out f)) MirrorTo(f, s.DeviceName, yt, player);
                }
            }
            catch { }
        }

        // ---------- espelho do vídeo na tela compartilhada (miniatura do DWM) ----------

        private class Thumb
        {
            public IntPtr Id;
            public IntPtr Dest;
            public IntPtr Src;
            public string Key = "";
        }

        private readonly Dictionary<string, Thumb> _thumbs = new Dictionary<string, Thumb>();
        private float _dpiScale;

        private void ClearMirror()
        {
            _fastTarget = IntPtr.Zero;
            foreach (Thumb t in _thumbs.Values)
            {
                try { Native.DwmUnregisterThumbnail(t.Id); } catch { }
            }
            _thumbs.Clear();
        }

        private void MirrorTo(CoverForm f, string dev, Win yt, Rectangle? player)
        {
            if (f == null || f.IsDisposed || !f.IsHandleCreated) return;
            IntPtr src = yt.H;
            Thumb t;
            _thumbs.TryGetValue(dev, out t);
            if (t != null && (t.Dest != f.Handle || t.Src != src))
            {
                try { Native.DwmUnregisterThumbnail(t.Id); } catch { }
                _thumbs.Remove(dev);
                t = null;
            }
            if (t == null)
            {
                IntPtr id;
                if (Native.DwmRegisterThumbnail(f.Handle, src, out id) != 0) return;
                t = new Thumb();
                t.Id = id;
                t.Dest = f.Handle;
                t.Src = src;
                _thumbs[dev] = t;
            }

            SIZE sz;
            if (Native.DwmQueryThumbnailSourceSize(t.Id, out sz) != 0 || sz.Width <= 0 || sz.Height <= 0) return;

            int sx = 0, sy = 0, sw = sz.Width, sh = sz.Height;
            bool usePlayer = false;
            if (player.HasValue)
            {
                Rectangle pr = player.Value;
                sx = pr.Left - yt.R.Left + 2;
                sy = pr.Top - yt.R.Top + 2;
                sw = pr.Width - 4;
                sh = pr.Height - 4;
                if (sx < 0) { sw += sx; sx = 0; }
                if (sy < 0) { sh += sy; sy = 0; }
                if (sx + sw > sz.Width) sw = sz.Width - sx;
                if (sy + sh > sz.Height) sh = sz.Height - sy;
                usePlayer = sw >= 60 && sh >= 60;
            }
            if (!usePlayer)
            {
                // Sem a posição do player: corta o topo (abas e barra de endereço) como aproximação.
                if (_dpiScale <= 0f)
                {
                    using (Graphics g = Graphics.FromHwnd(IntPtr.Zero)) _dpiScale = g.DpiX / 96f;
                    if (_dpiScale <= 0f) _dpiScale = 1f;
                }
                int crop = IsFullscreenRect(yt.R) ? 0 : (int)(100 * _dpiScale);
                sx = 0; sw = sz.Width;
                sy = crop; sh = sz.Height - crop;
                if (sh < 100) { sy = 0; sh = sz.Height; }
            }

            int cw = f.ClientSize.Width, ch = f.ClientSize.Height;
            if (cw <= 0 || ch <= 0) return;
            double k = Math.Min((double)cw / sw, (double)ch / sh);
            int dw = (int)(sw * k), dh = (int)(sh * k);
            int dx = (cw - dw) / 2, dy = (ch - dh) / 2;

            string key = dx + "," + dy + "," + dw + "," + dh + "," + sx + "," + sy + "," + sw + "," + sh;
            if (key == t.Key) return;
            t.Key = key;

            DWM_THUMBNAIL_PROPERTIES p = new DWM_THUMBNAIL_PROPERTIES();
            p.dwFlags = Native.DWM_TNP_RECTDESTINATION | Native.DWM_TNP_RECTSOURCE | Native.DWM_TNP_OPACITY | Native.DWM_TNP_VISIBLE;
            p.rcDestination = new RECT { Left = dx, Top = dy, Right = dx + dw, Bottom = dy + dh };
            p.rcSource = new RECT { Left = sx, Top = sy, Right = sx + sw, Bottom = sy + sh };
            p.opacity = 255;
            p.fVisible = 1;
            p.fSourceClientAreaOnly = 0;
            Native.DwmUpdateThumbnailProperties(t.Id, ref p);
        }

        // ---------- troca de navegador ----------

        // Com a troca ligada, só o navegador "ativo" pode aparecer na tela compartilhada.
        private bool BrowserAllowed(Win w)
        {
            if (!_swap || _activeBrowser.Length == 0) return true;
            return string.Equals(w.Browser ?? "", _activeBrowser, StringComparison.OrdinalIgnoreCase);
        }

        // Fecha a janela que o programa abriu na TV (modo YouTube) e esquece o vídeo atual.
        private void CloseTvWindow()
        {
            if (_tvWin != IntPtr.Zero && Native.IsWindow(_tvWin))
            {
                try { Native.PostMessage(_tvWin, Native.WM_CLOSE, IntPtr.Zero, IntPtr.Zero); } catch { }
                _moved.Remove(_tvWin);
            }
            _tvWin = IntPtr.Zero;
            _tvUrl = "";
            _tvNavUrl = "";
            _tvPending = false;
            _tvBefore = null;
            _tvRetryAt = DateTime.MinValue;
        }

        // Chamado no ciclo seguinte à troca: leva o novo navegador para a compartilhada (os outros saem em seguida).
        private void HandleSwap(List<Screen> shared)
        {
            string bring = _pendingBring;
            _pendingBring = "";
            _swapNote = "";
            if (_youtube)
            {
                // a janela da TV era do navegador anterior: fecha; o vídeo aberto no novo navegador assume
                CloseTvWindow();
                _ytWindow = IntPtr.Zero;
                _ytLostSince = DateTime.MinValue;
                ClearMirror();
                return;
            }
            if (_swap && bring.Length > 0 && shared.Count > 0)
            {
                if (!BringBrowserToShared(bring, shared[0]))
                    _swapNote = BrowserCatalog.ShortName(bring) + " não está aberto: abra ele no notebook.";
            }
        }

        // Acha a janela principal do navegador (até minimizada) e leva para a tela compartilhada.
        // Devolve false se o navegador não tem nenhuma janela aberta.
        private bool BrowserWindowToShared(string proc, Screen target)
        {
            IntPtr pick = IntPtr.Zero;
            bool already = false;
            List<Screen> sharedNow = _sharedNow;
            Native.EnumWindows(delegate(IntPtr h, IntPtr lp)
            {
                if (pick != IntPtr.Zero || already) return true;
                if (!Native.IsWindowVisible(h)) return true;
                if (Native.TitleOf(h).Length == 0) return true;
                int ex = Native.GetWindowLong(h, Native.GWL_EXSTYLE);
                if ((ex & Native.WS_EX_TOOLWINDOW) != 0) return true;
                string cls = Native.ClassOf(h);
                foreach (string c in SkipClasses) if (cls == c) return true;
                uint pid;
                Native.GetWindowThreadProcessId(h, out pid);
                if (pid == _ownPid || pid == 0) return true;
                if (!string.Equals(BrowserNameFor(pid), proc, StringComparison.OrdinalIgnoreCase)) return true;
                RECT r;
                if (!Native.GetWindowRect(h, out r)) return true;
                bool icon = Native.IsIconic(h);
                if (!icon && OnShared(r, sharedNow)) { already = true; return true; }
                if (!icon && r.Width < 200) return true;
                pick = h;
                return true;
            }, IntPtr.Zero);

            if (already) return true;
            if (pick == IntPtr.Zero) return false;
            if (Native.IsIconic(pick)) Native.ShowWindow(pick, Native.SW_RESTORE);
            RECT rr;
            if (!Native.GetWindowRect(pick, out rr)) return false;
            Win w = new Win();
            w.H = pick;
            w.R = rr;
            w.Title = "";
            w.IsBrowser = true;
            w.Browser = proc;
            MoveToShared(w, target);
            return true;
        }

        private bool BringBrowserToShared(string proc, Screen target)
        {
            return BrowserWindowToShared(proc, target);
        }

        // ---------- o que está aparecendo na compartilhada (para o texto fixo do canto) ----------

        private static bool IsYouTubeTitle(string title)
        {
            return title.IndexOf("YouTube", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        // Tira o nome do navegador do fim do título da janela.
        private static string CleanTitle(string t)
        {
            if (t == null) return "";
            t = t.Replace("\u200b", "");
            int i = Math.Max(t.LastIndexOf(" - ", StringComparison.Ordinal),
                    Math.Max(t.LastIndexOf(" \u2014 ", StringComparison.Ordinal), t.LastIndexOf(" \u2013 ", StringComparison.Ordinal)));
            if (i > 0 && t.Length - i < 30) t = t.Substring(0, i);
            return t;
        }

        public ShareSnapshot Snapshot()
        {
            ShareSnapshot s = new ShareSnapshot();
            s.Title = "";
            s.Detail = "";
            s.Browser = "";
            try
            {
                List<Screen> shared = SharedScreens();
                if (shared.Count == 0) { s.Kind = 0; return s; }

                // "Só YouTube" ligado (sozinho ou junto com a tela preta) = YouTube na compartilhada: SIM.
                if (_youtube)
                {
                    s.Kind = 3;
                    IntPtr vh = IntPtr.Zero;
                    if (_tvWin != IntPtr.Zero && Native.IsWindow(_tvWin)) vh = _tvWin;
                    else if (_thumbs.Count > 0 && _ytWindow != IntPtr.Zero && Native.IsWindow(_ytWindow)) vh = _ytWindow;
                    if (vh != IntPtr.Zero)
                    {
                        uint vpid;
                        Native.GetWindowThreadProcessId(vh, out vpid);
                        s.Browser = BrowserCatalog.ShortName(BrowserNameFor(vpid));
                        s.Detail = CleanTitle(Native.TitleOf(vh));
                    }
                    else
                    {
                        s.Detail = "ligado, aguardando um vídeo (" + (_black ? "aparece tela preta" : "aparece o fundo") + ")";
                    }
                    return s;
                }

                if (_black) { s.Kind = 2; return s; }

                foreach (Win w in ListWindows())
                {
                    if (!OnShared(w.R, shared)) continue;
                    if (w.IsBrowser)
                    {
                        s.Browser = BrowserCatalog.ShortName(w.Browser);
                        s.Detail = CleanTitle(w.Title);
                        s.Kind = IsYouTubeTitle(w.Title) ? 3 : 4;
                        return s;
                    }
                    s.Kind = 5;
                    s.Title = w.Title;
                    return s;
                }
                s.Kind = 1;
            }
            catch { s.Kind = 1; }
            return s;
        }

        // ---------- envio de tecla com segurança de foco ----------

        private bool SendF11(IntPtr target)
        {
            return SendKey(target, VK_F11);
        }

        // Espera o usuário soltar Ctrl/Alt/Shift/Win (o atalho que acabou de apertar). Sem isso, o F11 enviado
        // chegaria no navegador como Ctrl+Alt+F11 e não faria nada.
        private static void WaitModifiersUp()
        {
            int[] mods = new int[] { 0x10, 0x11, 0x12, 0x5B, 0x5C };
            for (int i = 0; i < 20; i++)
            {
                bool down = false;
                foreach (int vk in mods)
                    if ((Native.GetAsyncKeyState(vk) & 0x8000) != 0) { down = true; break; }
                if (!down) return;
                Thread.Sleep(25);
            }
        }

        private bool SendKey(IntPtr target, byte vk)
        {
            uint fgThread = 0;
            uint me = Native.GetCurrentThreadId();
            bool attached = false;
            try
            {
                IntPtr prev = Native.GetForegroundWindow();
                uint dummy;
                fgThread = prev == IntPtr.Zero ? 0 : Native.GetWindowThreadProcessId(prev, out dummy);
                if (fgThread != 0 && fgThread != me) attached = Native.AttachThreadInput(me, fgThread, true);

                Native.SetForegroundWindow(target);
                bool ok = false;
                for (int i = 0; i < 10; i++)
                {
                    if (Native.GetForegroundWindow() == target) { ok = true; break; }
                    Thread.Sleep(30);
                }
                if (ok)
                {
                    WaitModifiersUp();
                    Thread.Sleep(60);
                    Native.keybd_event(vk, 0, 0, UIntPtr.Zero);   // tecla baixo
                    Native.keybd_event(vk, 0, 2, UIntPtr.Zero);   // tecla cima
                    Thread.Sleep(120);
                }
                if (prev != IntPtr.Zero && prev != target) Native.SetForegroundWindow(prev);
                return ok;
            }
            catch { return false; }
            finally
            {
                if (attached)
                {
                    try { Native.AttachThreadInput(me, fgThread, false); }
                    catch { }
                }
            }
        }

        // Envia uma sequência de teclas: cada passo é {modificador (0 = nenhum), tecla}.
        private bool SendSeq(IntPtr target, byte[][] steps)
        {
            uint fgThread = 0;
            uint me = Native.GetCurrentThreadId();
            bool attached = false;
            try
            {
                IntPtr prev = Native.GetForegroundWindow();
                uint dummy;
                fgThread = prev == IntPtr.Zero ? 0 : Native.GetWindowThreadProcessId(prev, out dummy);
                if (fgThread != 0 && fgThread != me) attached = Native.AttachThreadInput(me, fgThread, true);

                Native.SetForegroundWindow(target);
                bool ok = false;
                for (int i = 0; i < 15; i++)
                {
                    if (Native.GetForegroundWindow() == target) { ok = true; break; }
                    Thread.Sleep(30);
                }
                if (ok)
                {
                    WaitModifiersUp();
                    Thread.Sleep(150);
                    foreach (byte[] st in steps)
                    {
                        if (st[0] != 0) Native.keybd_event(st[0], 0, 0, UIntPtr.Zero);
                        Native.keybd_event(st[1], 0, 0, UIntPtr.Zero);
                        Native.keybd_event(st[1], 0, 2, UIntPtr.Zero);
                        if (st[0] != 0) Native.keybd_event(st[0], 0, 2, UIntPtr.Zero);
                        Thread.Sleep(180);
                    }
                }
                if (prev != IntPtr.Zero && prev != target) Native.SetForegroundWindow(prev);
                return ok;
            }
            catch { return false; }
            finally
            {
                if (attached)
                {
                    try { Native.AttachThreadInput(me, fgThread, false); }
                    catch { }
                }
            }
        }

        // ---------- restaurar ----------

        // Tudo de uma vez (liberar tudo / fechar o programa).
        private void RestoreWindows()
        {
            RestoreFullscreen();
            RestoreYoutube();
            RestorePositions();
        }

        // Desfaz o F11 que o programa aplicou nos navegadores.
        private void RestoreFullscreen()
        {
            foreach (IntPtr h in _fsApplied.ToArray())
            {
                try
                {
                    RECT r;
                    if (Native.IsWindow(h) && Native.GetWindowRect(h, out r) && IsFullscreenRect(r)) SendF11(h);
                }
                catch { }
            }
            _fsApplied.Clear();
            _f11Attempts.Clear();
            _f11Last.Clear();
            _fsTotal = 0;
            _fsDone = 0;
        }

        // Desfaz o modo YouTube (janela da TV, espelho, tela cheia do player).
        private void RestoreYoutube()
        {
            ClearMirror();
            _player = null;

            foreach (IntPtr h in _ytFs.ToArray())
            {
                try
                {
                    RECT r;
                    if (Native.IsWindow(h) && Native.GetWindowRect(h, out r) && IsFullscreenRect(r)) SendKey(h, VK_ESCAPE);
                }
                catch { }
            }
            _ytFs.Clear();

            if (!_youtube) CloseTvWindow();
            _ytState = "";
            _ytLastTitle = "";
            _ytWindow = IntPtr.Zero;
            _ytLostSince = DateTime.MinValue;
            _urls.Clear();
        }

        // Devolve as janelas que foram empurradas para a tela principal ao lugar de origem.
        private void RestorePositions()
        {
            LowerRaised();
            _push.Clear();
            _failedMoves = 0;

            foreach (KeyValuePair<IntPtr, RECT> kv in _moved)
            {
                try
                {
                    if (!Native.IsWindow(kv.Key)) continue;
                    if (_youtube && kv.Key == _tvWin) continue;
                    Native.SetWindowPos(kv.Key, IntPtr.Zero, kv.Value.Left, kv.Value.Top,
                        kv.Value.Width, kv.Value.Height, Native.SWP_NOZORDER | Native.SWP_NOACTIVATE);
                }
                catch { }
            }
            _moved.Clear();
        }
    }
}
