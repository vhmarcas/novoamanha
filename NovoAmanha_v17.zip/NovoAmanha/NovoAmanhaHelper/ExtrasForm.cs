using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace NovoAmanha
{
    // Janela "Relógio e fundo da tela": tudo muda ao vivo na tela compartilhada.
    internal class ExtrasForm : Form
    {
        private readonly Settings _s;
        private readonly Dictionary<string, string> _names;
        private readonly MethodInvoker _changed;
        private readonly Panel _host = new Panel();
        private bool _loading = true;
        private int _y;

        private ToggleSwitch _clockOn;
        private CheckBox _chH, _chM, _chS;
        private Button _btnFore, _btnBack;
        private TrackBar _tbAlpha, _tbSize;
        private Label _lblAlpha, _lblSize;
        private readonly Button[] _pos = new Button[9];
        private readonly List<CheckBox> _scrChecks = new List<CheckBox>();

        private ToggleSwitch _backOn;
        private Button _btnBackColor;
        private Label _lblPath;
        private ComboBox _cmbFit;

        public ExtrasForm(Settings s, Dictionary<string, string> names, MethodInvoker changed)
        {
            _s = s;
            _names = names ?? new Dictionary<string, string>();
            _changed = changed;

            Text = "Relógio e fundo da tela";
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            StartPosition = FormStartPosition.CenterParent;
            ShowInTaskbar = false;
            BackColor = Theme.Bg;
            ForeColor = Theme.Text;
            AutoScaleMode = AutoScaleMode.None;
            int h = Math.Min(780, Screen.PrimaryScreen.WorkingArea.Height - 60);
            ClientSize = new Size(640, Math.Max(420, h));

            _host.Dock = DockStyle.Fill;
            _host.AutoScroll = true;
            _host.BackColor = Theme.Bg;
            Controls.Add(_host);

            BuildClock();
            BuildBackdrop();
            BuildHolyrics();
            _y += 16;
            _host.AutoScrollMinSize = new Size(0, _y);
            _loading = false;
        }

        // ---------- ajudantes de montagem ----------

        private Label Lbl(string text, int x, int y, int w, int h, Color col, float size, bool bold)
        {
            Label l = new Label();
            l.AutoSize = false;
            l.Text = text;
            l.Font = new Font("Segoe UI", size, bold ? FontStyle.Bold : FontStyle.Regular);
            l.ForeColor = col;
            l.BackColor = Theme.Bg;
            l.SetBounds(x, y, w, h);
            _host.Controls.Add(l);
            return l;
        }

        private Button Swatch(int x, int y, int w, int h, int argb, EventHandler click)
        {
            Button b = new Button();
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderColor = Theme.Edge;
            b.FlatAppearance.BorderSize = 2;
            b.Cursor = Cursors.Hand;
            b.BackColor = Color.FromArgb(255, Color.FromArgb(argb));
            b.SetBounds(x, y, w, h);
            b.Click += click;
            _host.Controls.Add(b);
            return b;
        }

        private FxButton Act(string text, int x, int y, int w, int h, EventHandler click)
        {
            FxButton b = new FxButton();
            b.Text = text;
            b.Font = new Font("Segoe UI", 9.5f);
            b.ForeColor = Theme.Text;
            b.Backdrop = Theme.Bg;
            b.SetBounds(x, y, w, h);
            b.Click += click;
            _host.Controls.Add(b);
            return b;
        }

        private CheckBox Check(string text, int x, int y, int w, bool on, EventHandler change)
        {
            CheckBox c = new CheckBox();
            c.Text = text;
            c.Font = new Font("Segoe UI", 10.5f);
            c.ForeColor = Theme.Text;
            c.BackColor = Theme.Bg;
            c.Checked = on;
            c.SetBounds(x, y, w, 26);
            c.CheckedChanged += change;
            _host.Controls.Add(c);
            return c;
        }

        private TrackBar Track(int x, int y, int w, int min, int max, int val, int tick)
        {
            TrackBar t = new TrackBar();
            t.Minimum = min;
            t.Maximum = max;
            t.TickFrequency = tick;
            t.Value = Math.Max(min, Math.Min(max, val));
            t.SetBounds(x, y, w, 40);
            t.BackColor = Theme.Bg;
            _host.Controls.Add(t);
            return t;
        }

        private void Heading(string text)
        {
            Lbl(text, 20, _y, 600, 30, Theme.Accent, 14f, true);
            _y += 36;
        }

        private void Apply()
        {
            if (_loading) return;
            try
            {
                _s.Save();
                if (_changed != null) _changed();
            }
            catch (Exception ex) { ErrorLog.Write(ex); }
        }

        private static Color Contrast(Color c)
        {
            return (c.R * 299 + c.G * 587 + c.B * 114) / 1000 > 140 ? Color.Black : Color.White;
        }

        private bool PickColor(ref int argb)
        {
            using (ColorDialog cd = new ColorDialog())
            {
                cd.FullOpen = true;
                cd.AnyColor = true;
                cd.Color = Color.FromArgb(255, Color.FromArgb(argb));
                if (cd.ShowDialog(this) != DialogResult.OK) return false;
                argb = Color.FromArgb(255, cd.Color).ToArgb();
                return true;
            }
        }

        // ---------- relógio ----------

        private void BuildClock()
        {
            _y = 16;
            Heading("RELÓGIO NA TELA COMPARTILHADA");

            _clockOn = new ToggleSwitch();
            _clockOn.BackColor = Theme.Bg;
            _clockOn.SetBounds(20, _y, 54, 28);
            _clockOn.Checked = _s.ClockOn;
            _host.Controls.Add(_clockOn);
            Lbl("Mostrar o relógio (hora do dia)", 88, _y, 500, 28, Theme.Text, 11f, false);
            _clockOn.CheckedChanged += delegate
            {
                _s.ClockOn = _clockOn.Checked;
                if (_s.ClockOn && (_s.ClockScreens ?? "").Length == 0) SelectAllScreens();
                Apply();
            };
            _y += 44;

            Lbl("O que aparece:", 20, _y + 2, 130, 24, Theme.Muted, 10f, false);
            _chH = Check("Horas", 160, _y, 90, _s.ClockH, delegate { _s.ClockH = _chH.Checked; Apply(); });
            _chM = Check("Minutos", 260, _y, 100, _s.ClockM, delegate { _s.ClockM = _chM.Checked; Apply(); });
            _chS = Check("Segundos", 370, _y, 110, _s.ClockS, delegate { _s.ClockS = _chS.Checked; Apply(); });
            _y += 38;

            Lbl("Cor dos números:", 20, _y + 4, 150, 24, Theme.Muted, 10f, false);
            _btnFore = Swatch(180, _y, 90, 30, _s.ClockColor, delegate
            {
                int v = _s.ClockColor;
                if (PickColor(ref v)) { _s.ClockColor = v; _btnFore.BackColor = Color.FromArgb(255, Color.FromArgb(v)); Apply(); }
            });
            Lbl("Cor do fundo:", 300, _y + 4, 120, 24, Theme.Muted, 10f, false);
            _btnBack = Swatch(430, _y, 90, 30, _s.ClockBg, delegate
            {
                int v = _s.ClockBg;
                if (PickColor(ref v)) { _s.ClockBg = v; _btnBack.BackColor = Color.FromArgb(255, Color.FromArgb(v)); Apply(); }
            });
            _y += 44;

            Lbl("Opacidade do fundo:", 20, _y + 8, 170, 24, Theme.Muted, 10f, false);
            _tbAlpha = Track(190, _y, 330, 0, 100, _s.ClockBgAlpha, 10);
            _lblAlpha = Lbl(_s.ClockBgAlpha + "%", 530, _y + 8, 80, 24, Theme.Text, 10.5f, true);
            _tbAlpha.ValueChanged += delegate
            {
                _s.ClockBgAlpha = _tbAlpha.Value;
                _lblAlpha.Text = _tbAlpha.Value + "%";
                Apply();
            };
            _y += 46;

            Lbl("Tamanho:", 20, _y + 8, 170, 24, Theme.Muted, 10f, false);
            _tbSize = Track(190, _y, 330, 30, 400, _s.ClockSize, 50);
            _lblSize = Lbl(_s.ClockSize + " px", 530, _y + 8, 80, 24, Theme.Text, 10.5f, true);
            _tbSize.ValueChanged += delegate
            {
                _s.ClockSize = _tbSize.Value;
                _lblSize.Text = _tbSize.Value + " px";
                Apply();
            };
            _y += 50;

            Lbl("Posição na tela:", 20, _y + 4, 150, 24, Theme.Muted, 10f, false);
            string[] arrows = new string[] { "↖", "⬆", "↗", "⬅", "●", "➡", "↙", "⬇", "↘" };
            for (int i = 0; i < 9; i++)
            {
                int idx = i;
                int col = i % 3;
                int row = i / 3;
                Button b = new Button();
                b.FlatStyle = FlatStyle.Flat;
                b.FlatAppearance.BorderColor = Theme.Edge;
                b.FlatAppearance.BorderSize = 1;
                b.Font = new Font("Segoe UI Symbol", 14f, FontStyle.Bold);
                b.Text = arrows[i];
                b.Cursor = Cursors.Hand;
                b.SetBounds(190 + col * 62, _y + row * 52, 56, 46);
                b.Click += delegate { _s.ClockPos = idx; RefreshPos(); Apply(); };
                _host.Controls.Add(b);
                _pos[i] = b;
            }
            Lbl("A seta marca onde o relógio fica: cantos, bordas ou o centro.", 380, _y, 230, 70, Theme.Muted, 9f, false);
            RefreshPos();
            _y += 3 * 52 + 12;

            Lbl("Em qual tela aparece (só nas marcadas; as outras ficam sem relógio):", 20, _y, 600, 24, Theme.Muted, 10f, false);
            _y += 28;
            BuildScreenList();
        }

        private void RefreshPos()
        {
            for (int i = 0; i < 9; i++)
            {
                bool on = i == _s.ClockPos;
                _pos[i].BackColor = on ? Theme.Accent : Theme.Card;
                _pos[i].ForeColor = on ? Color.Black : Theme.Text;
            }
        }

        private void BuildScreenList()
        {
            Screen[] all = Screen.AllScreens;
            string[] picked = (_s.ClockScreens ?? "").Split('|');
            int n = 0;
            for (int i = 0; i < all.Length; i++)
            {
                Screen sc = all[i];
                if (sc.Primary) continue;
                n++;
                string label;
                if (!_names.TryGetValue(sc.DeviceName, out label) || label.Length == 0) label = "Tela extra " + n;
                label += "   (" + sc.Bounds.Width + "x" + sc.Bounds.Height + ")";
                CheckBox c = Check(label, 40, _y, 560, Array.IndexOf(picked, sc.DeviceName) >= 0, delegate { ScreensChanged(); });
                c.Tag = sc.DeviceName;
                _scrChecks.Add(c);
                _y += 30;
            }
            if (n == 0)
            {
                Lbl("Nenhuma tela extra conectada agora. Conecte o projetor/TV e abra esta janela de novo.", 40, _y, 560, 44, Theme.Warn, 10f, false);
                _y += 48;
            }
            else
            {
                Lbl("TV e projetor em modo Duplicar são UMA tela só para o Windows, então aparecem juntos. " +
                    "Para controlar cada um, use Win+P → Estender.", 40, _y + 2, 560, 44, Theme.Muted, 9f, false);
                _y += 52;
            }
        }

        private void ScreensChanged()
        {
            if (_loading) return;
            List<string> l = new List<string>();
            foreach (CheckBox c in _scrChecks)
                if (c.Checked) l.Add((string)c.Tag);
            _s.ClockScreens = string.Join("|", l.ToArray());
            Apply();
        }

        private void SelectAllScreens()
        {
            bool prev = _loading;
            _loading = true;
            foreach (CheckBox c in _scrChecks) c.Checked = true;
            _loading = prev;
            List<string> l = new List<string>();
            foreach (CheckBox c in _scrChecks) l.Add((string)c.Tag);
            _s.ClockScreens = string.Join("|", l.ToArray());
        }

        // ---------- fundo ----------

        private void BuildBackdrop()
        {
            _y += 8;
            Heading("FUNDO NA TELA COMPARTILHADA");

            _backOn = new ToggleSwitch();
            _backOn.BackColor = Theme.Bg;
            _backOn.SetBounds(20, _y, 54, 28);
            _backOn.Checked = _s.BackOn;
            _host.Controls.Add(_backOn);
            Lbl("Usar um fundo personalizado", 88, _y, 500, 28, Theme.Text, 11f, false);
            _backOn.CheckedChanged += delegate { _s.BackOn = _backOn.Checked; Apply(); };
            _y += 40;

            Lbl("Fica por cima do papel de parede e dos ícones da área de trabalho, mas por baixo das janelas. " +
                "Com a Tela preta ligada, ela continua preta. Aparece nas telas marcadas na lista de dispositivos.",
                20, _y, 590, 60, Theme.Muted, 9.5f, false);
            _y += 66;

            Lbl("Cor de fundo:", 20, _y + 4, 130, 24, Theme.Muted, 10f, false);
            _btnBackColor = Swatch(160, _y, 90, 30, _s.BackColor, delegate
            {
                int v = _s.BackColor;
                if (PickColor(ref v)) { _s.BackColor = v; _btnBackColor.BackColor = Color.FromArgb(255, Color.FromArgb(v)); Apply(); }
            });
            _y += 44;

            Lbl("Imagem (opcional):", 20, _y + 4, 150, 24, Theme.Muted, 10f, false);
            Act("Escolher imagem...", 180, _y, 170, 32, delegate { ChooseImage(); });
            Act("Tirar imagem", 360, _y, 130, 32, delegate
            {
                _s.BackPath = "";
                ShowPath();
                Apply();
            });
            _y += 40;
            _lblPath = Lbl("", 20, _y, 590, 24, Theme.Text, 9f, false);
            ShowPath();
            _y += 32;

            Lbl("Como encaixar:", 20, _y + 4, 130, 24, Theme.Muted, 10f, false);
            _cmbFit = new ComboBox();
            _cmbFit.DropDownStyle = ComboBoxStyle.DropDownList;
            _cmbFit.Font = new Font("Segoe UI", 10f);
            _cmbFit.Items.Add("Preencher (corta as bordas)");
            _cmbFit.Items.Add("Mostrar inteira (podem sobrar faixas)");
            _cmbFit.Items.Add("Esticar");
            _cmbFit.SelectedIndex = Math.Max(0, Math.Min(2, _s.BackFit));
            _cmbFit.SetBounds(160, _y, 340, 28);
            _cmbFit.SelectedIndexChanged += delegate { _s.BackFit = _cmbFit.SelectedIndex; Apply(); };
            _host.Controls.Add(_cmbFit);
            _y += 44;
        }

        // ---------- Holyrics ----------

        private void BuildHolyrics()
        {
            _y += 8;
            Heading("HOLYRICS (VERSÍCULO NA TELA)");

            Lbl("Com o fundo ligado, as janelas do Holyrics que aparecem na tela compartilhada ficam ACIMA do fundo, " +
                "e o relógio fica acima de tudo. Se o versículo ainda não aparecer, abra o detector, passe um versículo " +
                "no Holyrics e veja qual janela reage.",
                20, _y, 590, 62, Theme.Muted, 9.5f, false);
            _y += 68;

            Lbl("Programas liberados:", 20, _y + 4, 160, 24, Theme.Muted, 10f, false);
            TextBox tb = new TextBox();
            tb.Font = new Font("Segoe UI", 10f);
            tb.Text = _s.FreeApps ?? "";
            tb.SetBounds(190, _y, 330, 28);
            tb.TextChanged += delegate
            {
                if (_loading) return;
                _s.FreeApps = tb.Text;
                Engine.SetFreeApps(tb.Text);
                Apply();
            };
            _host.Controls.Add(tb);
            _y += 32;
            Lbl("Nomes separados por vírgula (padrão: holyrics). Aparecem livres na compartilhada.",
                190, _y, 420, 24, Theme.Muted, 9f, false);
            _y += 34;

            Act("Detector do Holyrics...", 20, _y, 260, 36, delegate { SpyForm.ShowSpy(_s, _changed); });
            _y += 48;
        }

        private void ShowPath()
        {
            _lblPath.Text = (_s.BackPath ?? "").Length == 0 ? "(nenhuma imagem: só a cor)" : _s.BackPath;
        }

        private void ChooseImage()
        {
            try
            {
                using (OpenFileDialog od = new OpenFileDialog())
                {
                    od.Title = "Escolha a imagem de fundo";
                    od.Filter = "Imagens|*.png;*.jpg;*.jpeg;*.bmp;*.gif|Todos os arquivos|*.*";
                    if (od.ShowDialog(this) != DialogResult.OK) return;
                    if (!File.Exists(od.FileName)) return;
                    _s.BackPath = od.FileName;
                    ShowPath();
                    Apply();
                }
            }
            catch (Exception ex) { ErrorLog.Write(ex); }
        }
    }
}
