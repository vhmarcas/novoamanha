using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows.Forms;

namespace NovoAmanha
{
    // Ajudantes (seguros para usar de qualquer thread) para achar as janelas dos programas liberados (Holyrics).
    internal static class FreeWin
    {
        private static readonly object Lk = new object();
        private static readonly Dictionary<uint, string> Names = new Dictionary<uint, string>();
        private static DateTime _stamp = DateTime.UtcNow;
        private static readonly uint OwnPid = (uint)Process.GetCurrentProcess().Id;
        private static readonly string[] Browsers = new string[] { "firefox", "msedge", "chrome", "brave", "opera", "vivaldi" };

        public static string ProcName(uint pid)
        {
            lock (Lk)
            {
                if ((DateTime.UtcNow - _stamp).TotalSeconds > 30)
                {
                    Names.Clear();
                    _stamp = DateTime.UtcNow;
                }
                string cached;
                if (Names.TryGetValue(pid, out cached)) return cached;
            }
            string name = "";
            try
            {
                using (Process p = Process.GetProcessById((int)pid))
                    name = p.ProcessName.ToLowerInvariant();
            }
            catch { }
            lock (Lk) { Names[pid] = name; }
            return name;
        }

        // A janela é de um programa liberado (lista "free_apps"; padrão Holyrics)? Navegadores e o próprio painel nunca contam.
        public static bool IsFree(IntPtr h)
        {
            string[] apps = Engine.FreeApps;
            if (apps == null || apps.Length == 0) return false;
            uint pid;
            Native.GetWindowThreadProcessId(h, out pid);
            if (pid == 0 || pid == OwnPid) return false;
            string n = ProcName(pid);
            if (Array.IndexOf(Browsers, n) >= 0) return false;
            string t = null;
            foreach (string a in apps)
            {
                if (a.Length == 0) continue;
                if (n.IndexOf(a, StringComparison.Ordinal) >= 0) return true;
                if (t == null) t = Native.TitleOf(h).ToLowerInvariant();
                if (t.IndexOf(a, StringComparison.Ordinal) >= 0) return true;
            }
            return false;
        }

        // Janelas liberadas visíveis (mesmo sem título, mesmo "ferramenta") em alguma das telas dadas.
        public static List<IntPtr> VisibleOn(List<Screen> shared)
        {
            List<IntPtr> res = new List<IntPtr>();
            if (shared == null || shared.Count == 0) return res;
            Native.EnumWindows(delegate(IntPtr h, IntPtr lp)
            {
                if (!Native.IsWindowVisible(h) || Native.IsIconic(h)) return true;
                int cloaked;
                if (Native.DwmGetWindowAttribute(h, Native.DWMWA_CLOAKED, out cloaked, 4) == 0 && cloaked != 0) return true;
                RECT r;
                if (!Native.GetWindowRect(h, out r) || r.Width <= 0 || r.Height <= 0) return true;
                if (!Engine.OnShared(r, shared)) return true;
                if (!IsFree(h)) return true;
                res.Add(h);
                return true;
            }, IntPtr.Zero);
            return res;
        }

        // Alguma das janelas de 'set' está acima de h na ordem das janelas?
        public static bool AnyAbove(IntPtr h, IntPtr[] set)
        {
            IntPtr p = Native.GetWindow(h, 3);   // GW_HWNDPREV = a janela logo acima
            int guard = 0;
            while (p != IntPtr.Zero && guard++ < 3000)
            {
                if (Array.IndexOf(set, p) >= 0) return true;
                p = Native.GetWindow(p, 3);
            }
            return false;
        }
    }
}
