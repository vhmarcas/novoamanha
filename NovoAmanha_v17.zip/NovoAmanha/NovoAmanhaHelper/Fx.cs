using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Reflection;
using System.Windows.Forms;

namespace NovoAmanha
{
    // Utilidades de desenho e animação.
    internal static class Fx
    {
        // Ligado enquanto a janela rola/redimensiona: as animações de enfeite pausam (tira o lag).
        public static bool Busy;

        private static string _tech;

        // Fonte "tecnológica" (Bahnschrift no Windows 10+; senão Segoe UI Semibold).
        public static string TechName()
        {
            if (_tech == null)
            {
                _tech = "Segoe UI Semibold";
                try { using (FontFamily ff = new FontFamily("Bahnschrift")) _tech = "Bahnschrift"; }
                catch { }
            }
            return _tech;
        }

        // Retângulo com dois cantos cortados (superior esquerdo e inferior direito).
        public static GraphicsPath Chamfer(Rectangle r, int c)
        {
            GraphicsPath p = new GraphicsPath();
            c = Math.Max(2, Math.Min(c, Math.Min(r.Width, r.Height) / 2));
            p.AddPolygon(new Point[]
            {
                new Point(r.Left + c, r.Top), new Point(r.Right, r.Top), new Point(r.Right, r.Bottom - c),
                new Point(r.Right - c, r.Bottom), new Point(r.Left, r.Bottom), new Point(r.Left, r.Top + c)
            });
            return p;
        }

        public static float Clamp01(float v) { return v < 0f ? 0f : (v > 1f ? 1f : v); }

        public static float Lerp(float a, float b, float t) { return a + (b - a) * t; }

        public static float EaseOut(float t)
        {
            t = Clamp01(t);
            return 1f - (1f - t) * (1f - t) * (1f - t);
        }

        public static Color Mix(Color a, Color b, float t)
        {
            t = Clamp01(t);
            return Color.FromArgb(
                (int)Lerp(a.A, b.A, t), (int)Lerp(a.R, b.R, t), (int)Lerp(a.G, b.G, t), (int)Lerp(a.B, b.B, t));
        }

        // Retângulo arredondado; "d" é o diâmetro dos cantos.
        public static GraphicsPath RoundRect(Rectangle r, int d)
        {
            GraphicsPath p = new GraphicsPath();
            d = Math.Max(2, Math.Min(d, Math.Min(r.Width, r.Height)));
            p.AddArc(r.X, r.Y, d, d, 180, 90);
            p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            p.CloseFigure();
            return p;
        }

        // Banner embutido no .exe (banner.jpg).
        public static Bitmap LoadBanner()
        {
            try
            {
                Assembly asm = Assembly.GetExecutingAssembly();
                using (Stream s = asm.GetManifestResourceStream("banner.jpg"))
                {
                    if (s == null) return null;
                    using (Image img = Image.FromStream(s)) return new Bitmap(img);
                }
            }
            catch { return null; }
        }
    }

    // ---------------------------------------------------------------------------------------------
    // Botão futurista (canto chanfrado). O relógio de animação só roda enquanto algo se mexe.
    // ---------------------------------------------------------------------------------------------
    internal class FxButton : Button
    {
        public Color Base = Color.FromArgb(14, 26, 50);
        public Color Edge = Theme.Edge;
        public Color Hot = Theme.Accent;
        public Color Backdrop = Theme.Card;

        private bool _pulse;
        private float _hv, _pr;
        private bool _over, _down;
        private readonly Timer _t = new Timer();
        private readonly Stopwatch _sw = Stopwatch.StartNew();

        public FxButton()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
            FlatStyle = FlatStyle.Flat;
            FlatAppearance.BorderSize = 0;
            Cursor = Cursors.Hand;
            UseVisualStyleBackColor = false;
            _t.Interval = 33;
            _t.Tick += delegate
            {
                if (!Visible || !IsHandleCreated)
                {
                    if (!_pulse) _t.Stop();
                    return;
                }
                float ho = _over ? 1f : 0f;
                float po = _down ? 1f : 0f;
                bool moving = Math.Abs(ho - _hv) > 0.004f || Math.Abs(po - _pr) > 0.004f;
                _hv += (ho - _hv) * 0.30f;
                _pr += (po - _pr) * 0.45f;
                if (!moving) { _hv = ho; _pr = po; }
                if ((moving || _pulse) && !Fx.Busy) Invalidate();
                if (!moving && !_pulse) _t.Stop();
            };
        }

        // Pulso para chamar atenção (botão de emergência quando há algo ligado).
        public bool Pulse
        {
            get { return _pulse; }
            set
            {
                if (_pulse == value) return;
                _pulse = value;
                Kick();
                Invalidate();
            }
        }

        private void Kick()
        {
            if (!_t.Enabled) _t.Start();
        }

        protected override void OnMouseEnter(EventArgs e) { base.OnMouseEnter(e); _over = true; Kick(); }
        protected override void OnMouseLeave(EventArgs e) { base.OnMouseLeave(e); _over = false; _down = false; Kick(); }
        protected override void OnMouseDown(MouseEventArgs e) { base.OnMouseDown(e); _down = true; Kick(); }
        protected override void OnMouseUp(MouseEventArgs e) { base.OnMouseUp(e); _down = false; Kick(); }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            g.Clear(Backdrop);
            if (Width < 10 || Height < 10) return;

            Rectangle r = new Rectangle(1, 1, Width - 3, Height - 3);
            float pulse = _pulse ? 0.5f + 0.5f * (float)Math.Sin(_sw.Elapsed.TotalSeconds * 3.2) : 0f;
            Color top = Fx.Mix(Base, Color.White, 0.10f + 0.16f * _hv - 0.06f * _pr);
            Color bot = Fx.Mix(Base, Color.Black, 0.20f - 0.10f * _hv + 0.08f * _pr);
            int c = Math.Max(5, Math.Min(r.Height / 3, 11));

            using (GraphicsPath p = Fx.Chamfer(r, c))
            {
                using (LinearGradientBrush b = new LinearGradientBrush(r, top, bot, 90f))
                    g.FillPath(b, p);
                if (pulse > 0f)
                {
                    using (Pen glow = new Pen(Color.FromArgb((int)(110 * pulse), Hot), 6f))
                        g.DrawPath(glow, p);
                }
                using (Pen pen = new Pen(Fx.Mix(Edge, Hot, Math.Max(_hv, pulse * 0.6f)), 1.3f))
                    g.DrawPath(pen, p);
            }
            // marca de energia no topo, cresce ao passar o mouse
            int mark = (int)(8 + 22 * _hv);
            using (Pen tp = new Pen(Color.FromArgb((int)(120 + 135 * _hv), Hot), 2f))
                g.DrawLine(tp, r.Left + c + 4, r.Top + 1, r.Left + c + 4 + mark, r.Top + 1);

            Color fc = Enabled ? ForeColor : Theme.Muted;
            TextFormatFlags fl = TextFormatFlags.HorizontalCenter | TextFormatFlags.WordBreak | TextFormatFlags.NoPrefix;
            int tw = Math.Max(10, Width - 12);
            Size ms = TextRenderer.MeasureText(g, Text, Font, new Size(tw, 0), fl);
            int ty = (Height - ms.Height) / 2 + (int)(_pr * 1.5f);
            TextRenderer.DrawText(g, Text, Font, new Rectangle(6, ty, tw, ms.Height + 2), fc, fl);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) _t.Dispose();
            base.Dispose(disposing);
        }
    }

    // ---------------------------------------------------------------------------------------------
    // Cabeçalho com o banner (alinhado embaixo). Camada fixa (banner + grade + colchetes) fica em cache;
    // por cima só rodam efeitos leves: faixa de luz, linha de varredura, faíscas e linha neon.
    // ---------------------------------------------------------------------------------------------
    internal class BannerPanel : Control
    {
        public string BadgeText = "PAINEL ONLINE";
        public Color BadgeColor = Theme.Good;
        public string RightText = "";
        public float K = 1f;

        private readonly Timer _timer = new Timer();
        private readonly Stopwatch _sw = Stopwatch.StartNew();
        private readonly List<float[]> _sparks = new List<float[]>();   // x, y, velocidade, tamanho, fase, deriva
        private Bitmap _src;
        private Bitmap _static;
        private int _staticW, _staticH;
        private Font _fBadge;
        private float _fontK = -1f;

        public BannerPanel()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
            BackColor = Theme.Bg;
            _src = Fx.LoadBanner();

            Random rnd = new Random(11);
            for (int i = 0; i < 14; i++)
            {
                _sparks.Add(new float[]
                {
                    (float)rnd.NextDouble(),
                    (float)rnd.NextDouble(),
                    0.04f + (float)rnd.NextDouble() * 0.10f,
                    1.6f + (float)rnd.NextDouble() * 2.6f,
                    (float)(rnd.NextDouble() * 6.28),
                    0.01f + (float)rnd.NextDouble() * 0.03f
                });
            }

            _timer.Interval = 50;   // 20 quadros por segundo bastam e pesam bem menos
            _timer.Tick += delegate
            {
                if (!Visible || !IsHandleCreated || Fx.Busy) return;
                Form f = FindForm();
                if (f != null && f.WindowState == FormWindowState.Minimized) return;
                Invalidate();
            };
            _timer.Start();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Rectangle r = ClientRectangle;
            if (r.Width < 8 || r.Height < 8) return;
            float t = (float)_sw.Elapsed.TotalSeconds;

            EnsureStatic(r);
            if (_static != null) g.DrawImageUnscaled(_static, 0, 0);
            else g.Clear(Theme.Bg);

            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

            DrawSweep(g, r, t);
            DrawScan(g, r, t);
            DrawSparks(g, r, t);
            DrawBadges(g, r, t);
            DrawLine(g, r, t);

            // entrada: o banner "acende" nos primeiros instantes
            float intro = Fx.Clamp01(t / 0.9f);
            if (intro < 1f)
            {
                using (SolidBrush b = new SolidBrush(Color.FromArgb((int)((1f - Fx.EaseOut(intro)) * 255f), 4, 8, 18)))
                    g.FillRectangle(b, r);
            }
        }

        // Camada que não muda: banner ancorado embaixo, sombra no topo, grade fina e colchetes nos cantos.
        private void EnsureStatic(Rectangle r)
        {
            if (_static != null && _staticW == r.Width && _staticH == r.Height && Math.Abs(_fontK - K) < 0.01f) return;
            if (_static != null) { _static.Dispose(); _static = null; }
            try
            {
                Bitmap bmp = new Bitmap(r.Width, r.Height, PixelFormat.Format32bppPArgb);
                using (Graphics g = Graphics.FromImage(bmp))
                {
                    g.SmoothingMode = SmoothingMode.AntiAlias;
                    g.Clear(Theme.Bg);
                    if (_src != null)
                    {
                        float sc = Math.Max(r.Width / (float)_src.Width, r.Height / (float)_src.Height);
                        int sw = (int)Math.Ceiling(_src.Width * sc);
                        int sh = (int)Math.Ceiling(_src.Height * sc);
                        g.InterpolationMode = InterpolationMode.HighQualityBilinear;
                        g.DrawImage(_src, new Rectangle((r.Width - sw) / 2, r.Height - sh, sw, sh));
                    }
                    else
                    {
                        using (LinearGradientBrush br = new LinearGradientBrush(r, Color.FromArgb(0, 80, 140), Color.FromArgb(90, 40, 160), 15f))
                            g.FillRectangle(br, r);
                        using (Font f1 = new Font(Fx.TechName(), 21f * K))
                            g.DrawString("Novo Amanhã Helper", f1, Brushes.White, 22f * K, r.Height * 0.4f);
                    }

                    // sombra azulada no topo
                    int h = Math.Max(4, r.Height / 2);
                    Rectangle vr = new Rectangle(0, 0, r.Width, h);
                    using (LinearGradientBrush b = new LinearGradientBrush(vr, Color.FromArgb(150, 2, 6, 20), Color.FromArgb(0, 2, 6, 20), 90f))
                        g.FillRectangle(b, vr);

                    // grade fina (linhas horizontais)
                    using (Pen gp = new Pen(Color.FromArgb(14, 120, 200, 255), 1f))
                        for (int y = 3; y < r.Height; y += 4) g.DrawLine(gp, 0, y, r.Width, y);

                    // colchetes nos 4 cantos
                    int L = Math.Max(10, (int)(18 * K));
                    using (Pen bp = new Pen(Color.FromArgb(200, Theme.Accent), 1.6f))
                    {
                        g.DrawLine(bp, 6, 6, 6 + L, 6); g.DrawLine(bp, 6, 6, 6, 6 + L);
                        g.DrawLine(bp, r.Width - 7, 6, r.Width - 7 - L, 6); g.DrawLine(bp, r.Width - 7, 6, r.Width - 7, 6 + L);
                        g.DrawLine(bp, 6, r.Height - 8, 6 + L, r.Height - 8); g.DrawLine(bp, 6, r.Height - 8, 6, r.Height - 8 - L);
                        g.DrawLine(bp, r.Width - 7, r.Height - 8, r.Width - 7 - L, r.Height - 8); g.DrawLine(bp, r.Width - 7, r.Height - 8, r.Width - 7, r.Height - 8 - L);
                    }
                }
                _static = bmp;
                _staticW = r.Width;
                _staticH = r.Height;
            }
            catch { _static = null; }
        }

        // Faixa de luz que atravessa o banner de tempos em tempos.
        private void DrawSweep(Graphics g, Rectangle r, float t)
        {
            float cycle = 6f;
            float ph = (t % cycle) / cycle;
            float act = 0.4f;
            if (ph >= act) return;
            float u = ph / act;
            int bw = Math.Max(30, (int)(r.Width * 0.16f));
            int skew = Math.Max(8, r.Height / 3);
            int x = (int)Fx.Lerp(-bw - skew, r.Width + skew, u);
            Rectangle br = new Rectangle(x, 0, bw + skew, r.Height);
            using (LinearGradientBrush b = new LinearGradientBrush(br, Color.Transparent, Color.Transparent, 0f))
            {
                ColorBlend cb = new ColorBlend(3);
                cb.Colors = new Color[]
                {
                    Color.FromArgb(0, 160, 240, 255),
                    Color.FromArgb(64, 190, 245, 255),
                    Color.FromArgb(0, 160, 240, 255)
                };
                cb.Positions = new float[] { 0f, 0.5f, 1f };
                b.InterpolationColors = cb;
                Point[] pts = new Point[]
                {
                    new Point(x + skew, 0), new Point(x + bw + skew, 0),
                    new Point(x + bw, r.Height), new Point(x, r.Height)
                };
                g.FillPolygon(b, pts);
            }
        }

        // Linha de varredura ciano descendo (efeito de scanner).
        private void DrawScan(Graphics g, Rectangle r, float t)
        {
            float cycle = 5f;
            float u = (t % cycle) / cycle;
            int y = (int)(u * (r.Height + 20)) - 10;
            using (SolidBrush glow = new SolidBrush(Color.FromArgb(18, Theme.Accent)))
                g.FillRectangle(glow, 0, y - 5, r.Width, 10);
            using (Pen line = new Pen(Color.FromArgb(70, Theme.Accent), 1f))
                g.DrawLine(line, 0, y, r.Width, y);
        }

        // Faíscas subindo (ciano e violeta).
        private void DrawSparks(Graphics g, Rectangle r, float t)
        {
            for (int i = 0; i < _sparks.Count; i++)
            {
                float[] s = _sparks[i];
                float life = (s[1] + s[2] * t) % 1f;
                float y = r.Height * (1f - life);
                float x = r.Width * s[0] + (float)Math.Sin(t * 1.3f + s[4]) * s[5] * r.Width;
                float a = (float)Math.Sin(Math.PI * life);
                float size = s[3] * K;
                Color c = (i % 3 == 0) ? Theme.Gold : Theme.Accent;
                using (SolidBrush glow = new SolidBrush(Color.FromArgb((int)(34 * a), c)))
                    g.FillEllipse(glow, x - size * 2f, y - size * 2f, size * 4f, size * 4f);
                using (SolidBrush core = new SolidBrush(Color.FromArgb((int)(220 * a), Fx.Mix(c, Color.White, 0.55f))))
                    g.FillEllipse(core, x - size / 2f, y - size / 2f, size, size);
            }
        }

        private void EnsureFonts()
        {
            if (_fBadge != null && Math.Abs(_fontK - K) < 0.01f) return;
            if (_fBadge != null) _fBadge.Dispose();
            _fBadge = new Font(Fx.TechName(), 8.5f * K);
            _fontK = K;
        }

        private void DrawBadges(Graphics g, Rectangle r, float t)
        {
            EnsureFonts();
            DrawPill(g, BadgeText, (int)(16 * K), (int)(14 * K), false, BadgeColor, true, t);
            if (RightText.Length > 0)
                DrawPill(g, RightText, r.Width - (int)(16 * K), (int)(14 * K), true, Theme.Accent, false, t);
        }

        private void DrawPill(Graphics g, string text, int anchorX, int y0, bool alignRight, Color col, bool withDot, float t)
        {
            TextFormatFlags fl = TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix | TextFormatFlags.SingleLine;
            Size ts = TextRenderer.MeasureText(g, text, _fBadge, new Size(2000, 100), fl);
            int padX = (int)(12 * K);
            int dot = withDot ? (int)(10 * K) : 0;
            int gap = withDot ? (int)(6 * K) : 0;
            int w = ts.Width + padX * 2 + dot + gap;
            int h = ts.Height + (int)(10 * K);
            int x0 = alignRight ? anchorX - w : anchorX;
            Rectangle pill = new Rectangle(x0, y0, w, h);

            using (GraphicsPath p = Fx.Chamfer(pill, Math.Max(4, (int)(7 * K))))
            {
                using (SolidBrush b = new SolidBrush(Color.FromArgb(170, 3, 8, 22)))
                    g.FillPath(b, p);
                using (Pen pen = new Pen(Color.FromArgb(160, col), 1f))
                    g.DrawPath(pen, p);
            }

            int textX = pill.X + padX;
            if (withDot)
            {
                float cx = pill.X + padX + dot / 2f;
                float cy = pill.Y + pill.Height / 2f;
                float rip = (t * 0.9f) % 1f;
                float rr = dot / 2f + rip * dot;
                using (Pen rp = new Pen(Color.FromArgb((int)(150 * (1f - rip)), col), 1.5f))
                    g.DrawEllipse(rp, cx - rr, cy - rr, rr * 2f, rr * 2f);
                using (SolidBrush db = new SolidBrush(col))
                    g.FillEllipse(db, cx - dot / 2f, cy - dot / 2f, dot, dot);
                textX += dot + gap;
            }
            TextRenderer.DrawText(g, text, _fBadge, new Point(textX, pill.Y + (pill.Height - ts.Height) / 2), Color.White, fl);
        }

        // Linha neon (ciano → violeta → magenta) correndo na base do cabeçalho: um único pincel.
        private void DrawLine(Graphics g, Rectangle r, float t)
        {
            int lh = Math.Max(2, (int)(3 * K));
            Rectangle lr = new Rectangle(0, r.Height - lh, r.Width, lh);
            Rectangle br = new Rectangle(0, 0, Math.Max(8, r.Width), lh + 1);
            using (LinearGradientBrush b = new LinearGradientBrush(br, Theme.Accent, Theme.Accent, LinearGradientMode.Horizontal))
            {
                ColorBlend cb = new ColorBlend(4);
                cb.Colors = new Color[] { Theme.Accent, Theme.Gold, Color.FromArgb(255, 70, 190), Theme.Accent };
                cb.Positions = new float[] { 0f, 0.4f, 0.75f, 1f };
                b.InterpolationColors = cb;
                b.WrapMode = WrapMode.Tile;
                b.TranslateTransform((t * 70f) % Math.Max(8, r.Width), 0f);
                g.FillRectangle(b, lr);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _timer.Dispose();
                if (_src != null) _src.Dispose();
                if (_static != null) _static.Dispose();
                if (_fBadge != null) _fBadge.Dispose();
            }
            base.Dispose(disposing);
        }
    }

    // ---------------------------------------------------------------------------------------------
    // "Cartão" de navegador: mostra qual está passando na compartilhada (brilha) e qual é a reserva.
    // ---------------------------------------------------------------------------------------------
    internal class BrowserChip : Control
    {
        public string Caption = "NAVEGADOR 1";
        public string BrowserName = "(escolha)";
        public string Initial = "?";
        public Color Tint = Theme.Accent;
        public float K = 1f;
        public event EventHandler Picked;

        private bool _active;
        private bool _over;
        private float _on, _hv;
        private readonly Timer _t = new Timer();
        private readonly Stopwatch _sw = Stopwatch.StartNew();
        private Font _fCap, _fName, _fSub;
        private float _fk = -1f;

        public BrowserChip()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
            Cursor = Cursors.Hand;
            _t.Interval = 50;
            _t.Tick += delegate
            {
                if (!Visible || !IsHandleCreated) return;
                float to = _active ? 1f : 0f;
                float ho = _over ? 1f : 0f;
                bool moving = Math.Abs(to - _on) > 0.004f || Math.Abs(ho - _hv) > 0.004f;
                _on += (to - _on) * 0.22f;
                _hv += (ho - _hv) * 0.25f;
                if (!moving) { _on = to; _hv = ho; }
                if ((moving || _active) && !Fx.Busy) Invalidate();
                if (!moving && !_active) _t.Stop();
            };
        }

        public bool Active
        {
            get { return _active; }
            set
            {
                if (_active == value) return;
                _active = value;
                if (!_t.Enabled) _t.Start();
                Invalidate();
            }
        }

        protected override void OnMouseEnter(EventArgs e) { base.OnMouseEnter(e); _over = true; if (!_t.Enabled) _t.Start(); }
        protected override void OnMouseLeave(EventArgs e) { base.OnMouseLeave(e); _over = false; if (!_t.Enabled) _t.Start(); }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            base.OnMouseUp(e);
            if (e.Button == MouseButtons.Left && ClientRectangle.Contains(e.Location) && Picked != null)
                Picked(this, EventArgs.Empty);
        }

        private void EnsureFonts()
        {
            if (_fCap != null && Math.Abs(_fk - K) < 0.01f) return;
            if (_fCap != null) _fCap.Dispose();
            if (_fName != null) _fName.Dispose();
            if (_fSub != null) _fSub.Dispose();
            _fCap = new Font("Segoe UI", 7.5f * K, FontStyle.Bold);
            _fName = new Font(Fx.TechName(), 13.5f * K);
            _fSub = new Font("Segoe UI", 8.5f * K);
            _fk = K;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            g.Clear(Theme.Card);
            if (Width < 40 || Height < 30) return;
            EnsureFonts();

            float pulse = 0.5f + 0.5f * (float)Math.Sin(_sw.Elapsed.TotalSeconds * 3.0);
            Rectangle r = new Rectangle(1, 1, Width - 3, Height - 3);
            Color a = Fx.Mix(Color.FromArgb(14, 22, 42), Color.FromArgb(0, 120, 150), _on);
            Color b = Fx.Mix(Color.FromArgb(10, 16, 32), Color.FromArgb(70, 50, 160), _on);

            using (GraphicsPath p = Fx.Chamfer(r, 14))
            {
                using (LinearGradientBrush br = new LinearGradientBrush(r, a, b, 25f))
                    g.FillPath(br, p);
                if (_on > 0.02f)
                {
                    using (Pen gp = new Pen(Color.FromArgb((int)(70 * _on * pulse), Theme.Accent), 6f))
                        g.DrawPath(gp, p);
                }
                Color border = Fx.Mix(Theme.Edge, Theme.Accent,
                    Math.Max(_on * (0.55f + 0.45f * pulse), _hv * 0.6f));
                using (Pen pen = new Pen(border, 1.5f + _on * 1.5f))
                    g.DrawPath(pen, p);
            }

            Color main = Fx.Mix(Theme.Text, Color.White, _on);
            Color sub = Fx.Mix(Theme.Muted, Color.FromArgb(190, 245, 255), _on);
            TextFormatFlags fl = TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix |
                                 TextFormatFlags.SingleLine | TextFormatFlags.EndEllipsis;

            int ic = (int)(Height * 0.46f);
            int ix = (int)(14 * K);
            int iy = (Height - ic) / 2;
            using (SolidBrush ib = new SolidBrush(Tint))
                g.FillEllipse(ib, ix, iy, ic, ic);
            using (Pen ip = new Pen(Color.FromArgb(190, 255, 255, 255), 2f))
                g.DrawEllipse(ip, ix + 1, iy + 1, ic - 2, ic - 2);
            Size isz = TextRenderer.MeasureText(g, Initial, _fName, new Size(200, 100), fl);
            TextRenderer.DrawText(g, Initial, _fName, new Point(ix + (ic - isz.Width) / 2, iy + (ic - isz.Height) / 2), Color.White, fl);

            int tx = ix + ic + (int)(12 * K);
            int tw = Math.Max(10, Width - tx - (int)(10 * K));
            Size capS = TextRenderer.MeasureText(g, "Ag", _fCap, new Size(200, 100), fl);
            Size nameS = TextRenderer.MeasureText(g, "Ag", _fName, new Size(200, 100), fl);
            Size subS = TextRenderer.MeasureText(g, "Ag", _fSub, new Size(200, 100), fl);
            int y = Math.Max(2, (Height - (capS.Height + nameS.Height + subS.Height + (int)(6 * K))) / 2);

            TextRenderer.DrawText(g, Caption, _fCap, new Rectangle(tx, y, tw, capS.Height), sub, fl);
            y += capS.Height + (int)(2 * K);
            TextRenderer.DrawText(g, BrowserName, _fName, new Rectangle(tx, y, tw, nameS.Height), main, fl);
            y += nameS.Height + (int)(4 * K);
            string state = _active ? "● PASSANDO TELA AGORA" : "○ reserva (clique para passar)";
            TextRenderer.DrawText(g, state, _fSub, new Rectangle(tx, y, tw, subS.Height), sub, fl);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _t.Dispose();
                if (_fCap != null) _fCap.Dispose();
                if (_fName != null) _fName.Dispose();
                if (_fSub != null) _fSub.Dispose();
            }
            base.Dispose(disposing);
        }
    }

    // ---------------------------------------------------------------------------------------------
    // Aviso que sobe do rodapé do painel, fica uns segundos e some.
    // ---------------------------------------------------------------------------------------------
    internal class Toast : Control
    {
        private string _text = "";
        private Color _col = Theme.Good;
        private DateTime _start = DateTime.MinValue;
        private int _baseTop;
        public int BottomInset;   // altura do rodapé, para o aviso não ficar por cima dele
        private readonly Timer _t = new Timer();
        private readonly Font _f = new Font(Fx.TechName(), 10.5f);

        public Toast()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
            Visible = false;
            Height = 46;
            _t.Interval = 25;
            _t.Tick += delegate
            {
                double s = (DateTime.UtcNow - _start).TotalSeconds;
                const double inT = 0.28;
                const double hold = 2.8;
                const double outT = 0.35;
                float k;
                if (s < inT) k = Fx.EaseOut((float)(s / inT));
                else if (s < hold) k = 1f;
                else if (s < hold + outT) k = 1f - Fx.EaseOut((float)((s - hold) / outT));
                else { _t.Stop(); Visible = false; return; }
                Top = _baseTop + (int)((1f - k) * 70f);
                Invalidate();
            };
        }

        public void ShowText(string text, Color col)
        {
            _text = text;
            _col = col;
            Size ts = TextRenderer.MeasureText(text, _f);
            int maxW = Parent != null ? Math.Max(200, Parent.ClientSize.Width - 24) : 600;
            Width = Math.Min(maxW, ts.Width + 70);
            if (Parent != null) Place(Parent.ClientSize.Width, Parent.ClientSize.Height);
            _start = DateTime.UtcNow;
            Top = _baseTop + 70;
            Visible = true;
            BringToFront();
            _t.Start();
            Invalidate();
        }

        public void Place(int clientW, int clientH)
        {
            Left = Math.Max(4, (clientW - Width) / 2);
            _baseTop = clientH - BottomInset - Height - 18;
        }

        protected override void OnSizeChanged(EventArgs e)
        {
            base.OnSizeChanged(e);
            if (Width < 10 || Height < 10) return;
            using (GraphicsPath p = Fx.Chamfer(new Rectangle(0, 0, Width, Height), 12))
            {
                Region old = Region;
                Region = new Region(p);
                if (old != null) old.Dispose();
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            Rectangle r = new Rectangle(0, 0, Width - 1, Height - 1);
            using (LinearGradientBrush b = new LinearGradientBrush(r, Fx.Mix(Color.FromArgb(24, 24, 38), _col, 0.22f), Color.FromArgb(18, 18, 30), 0f))
                g.FillRectangle(b, r);
            using (GraphicsPath p = Fx.Chamfer(r, 12))
            using (Pen pen = new Pen(_col, 1.6f))
                g.DrawPath(pen, p);
            using (SolidBrush db = new SolidBrush(_col))
                g.FillEllipse(db, 22, Height / 2 - 5, 10, 10);
            TextFormatFlags fl = TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix | TextFormatFlags.SingleLine | TextFormatFlags.EndEllipsis | TextFormatFlags.VerticalCenter;
            TextRenderer.DrawText(g, _text, _f, new Rectangle(40, 0, Width - 56, Height), Color.White, fl);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _t.Dispose();
                _f.Dispose();
            }
            base.Dispose(disposing);
        }
    }
    // ---------------------------------------------------------------------------------------------
    // Área de rolagem própria: um painel comprido que sobe/desce dentro do corpo.
    // WS_EX_COMPOSITED = desenha tudo em memória e só depois mostra (sem piscar ao rolar).
    // ---------------------------------------------------------------------------------------------
    internal class CanvasPanel : Panel
    {
        public CanvasPanel()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
            BackColor = Theme.Bg;
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x02000000;   // WS_EX_COMPOSITED
                return cp;
            }
        }
    }

    // Barra de rolagem fina, no estilo do painel.
    internal class SlimScroll : Control
    {
        public int Max;     // altura total do conteúdo
        public int Page;    // altura visível
        private int _value;
        private bool _drag, _over;
        private int _dragOff;
        public event EventHandler Scrolled;

        public SlimScroll()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
            BackColor = Theme.Bg;
            Width = 12;
            Cursor = Cursors.Hand;
        }

        public int MaxValue { get { return Math.Max(0, Max - Page); } }

        public int Value
        {
            get { return _value; }
            set
            {
                int v = Math.Max(0, Math.Min(value, MaxValue));
                if (v == _value) return;
                _value = v;
                Invalidate();
                if (Scrolled != null) Scrolled(this, EventArgs.Empty);
            }
        }

        // Reposiciona sem disparar o evento (usado quando o conteúdo muda de tamanho).
        public void Sync()
        {
            _value = Math.Max(0, Math.Min(_value, MaxValue));
            Invalidate();
        }

        private Rectangle Thumb()
        {
            if (Max <= Page || Max <= 0 || Height < 20) return Rectangle.Empty;
            int th = Math.Max(30, (int)((long)Height * Page / Max));
            int range = Math.Max(0, Height - th);
            int ty = MaxValue == 0 ? 0 : (int)((long)range * _value / MaxValue);
            return new Rectangle(2, ty, Math.Max(4, Width - 4), th);
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            Rectangle t = Thumb();
            if (t.IsEmpty) return;
            if (t.Contains(e.Location))
            {
                _drag = true;
                _dragOff = e.Y - t.Y;
            }
            else
            {
                Value = _value + (e.Y < t.Y ? -Page : Page);
            }
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            if (_drag)
            {
                Rectangle t = Thumb();
                int range = Height - t.Height;
                if (range > 0) Value = (int)((long)(e.Y - _dragOff) * MaxValue / range);
            }
            else
            {
                bool o = Thumb().Contains(e.Location);
                if (o != _over) { _over = o; Invalidate(); }
            }
        }

        protected override void OnMouseUp(MouseEventArgs e) { base.OnMouseUp(e); _drag = false; }
        protected override void OnMouseLeave(EventArgs e) { base.OnMouseLeave(e); _over = false; Invalidate(); }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Theme.Bg);
            Rectangle t = Thumb();
            if (t.IsEmpty) return;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            using (Pen tr = new Pen(Color.FromArgb(60, Theme.Edge), 1f))
                g.DrawLine(tr, Width / 2, 0, Width / 2, Height);
            using (GraphicsPath p = Fx.Chamfer(t, 4))
            {
                Color a = _drag || _over ? Theme.Accent : Fx.Mix(Theme.Edge, Theme.Accent, 0.5f);
                using (LinearGradientBrush b = new LinearGradientBrush(t, a, Fx.Mix(a, Theme.Gold, 0.6f), 90f))
                    g.FillPath(b, p);
            }
        }
    }
}
