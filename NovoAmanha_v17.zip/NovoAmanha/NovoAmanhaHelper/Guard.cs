using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Security;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace NovoAmanha
{
    // Registro de erros (arquivo erros.log em %AppData%\NovoAmanhaHelper).
    internal static class ErrorLog
    {
        public static void Write(Exception ex)
        {
            Write(ex == null ? "(erro sem detalhes)" : ex.ToString());
        }

        private static readonly object Sync = new object();

        public static void Write(string text)
        {
            try
            {
                lock (Sync)
                {
                    string dir = Path.Combine(
                        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "NovoAmanhaHelper");
                    Directory.CreateDirectory(dir);
                    string path = Path.Combine(dir, "erros.log");
                    FileInfo fi = new FileInfo(path);
                    if (fi.Exists && fi.Length > 200000)
                    {
                        // guarda o log antigo em vez de apagar tudo
                        string old = Path.Combine(dir, "erros_antigo.log");
                        if (File.Exists(old)) File.Delete(old);
                        File.Move(path, old);
                    }
                    File.AppendAllText(path, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "  " + text + "\r\n");
                }
            }
            catch { }
        }
    }

    // Grava arquivos de configuração sem risco de ficarem pela metade (queda de energia, fechar à força):
    // escreve num arquivo temporário e só então troca pelo definitivo.
    internal static class SafeFile
    {
        public static void WriteAllLines(string path, string[] lines)
        {
            string tmp = path + ".tmp";
            File.WriteAllLines(tmp, lines);
            if (File.Exists(path)) File.Replace(tmp, path, null);
            else File.Move(tmp, path);
        }
    }

    // Proteções para a tela nunca ficar "presa" se o painel fechar, travar ou for encerrado à força.
    internal static class Guard
    {
        private static int _errCount;
        private static DateTime _errStart = DateTime.MinValue;

        // Mostra de novo todas as barras de tarefas secundárias (o painel esconde elas na compartilhada).
        public static void SweepTaskbars()
        {
            try
            {
                IntPtr h = IntPtr.Zero;
                int guard = 0;
                while ((h = Native.FindWindowEx(IntPtr.Zero, h, "Shell_SecondaryTrayWnd", null)) != IntPtr.Zero && guard++ < 20)
                    Native.ShowWindow(h, Native.SW_SHOWNA);
            }
            catch { }
        }

        // Esconde as barras de tarefas secundárias que estão nas telas dadas (só nas compartilhadas:
        // a de outro monitor qualquer continua aparecendo). Devolve true se escondeu alguma.
        public static bool HideTaskbarsOn(List<Screen> shared, List<IntPtr> remember)
        {
            bool any = false;
            try
            {
                if (shared == null || shared.Count == 0) return false;
                IntPtr h = IntPtr.Zero;
                int guard = 0;
                while ((h = Native.FindWindowEx(IntPtr.Zero, h, "Shell_SecondaryTrayWnd", null)) != IntPtr.Zero && guard++ < 20)
                {
                    if (!Native.IsWindowVisible(h)) continue;
                    RECT r;
                    if (!Native.GetWindowRect(h, out r)) continue;
                    if (!Engine.OnShared(r, shared)) continue;
                    Native.SetWindowPos(h, IntPtr.Zero, 0, 0, 0, 0,
                        Native.SWP_NOMOVE | Native.SWP_NOSIZE | Native.SWP_NOZORDER | Native.SWP_NOACTIVATE | 0x0080);
                    Native.ShowWindow(h, Native.SW_HIDE);
                    if (remember != null && !remember.Contains(h)) remember.Add(h);
                    any = true;
                }
            }
            catch { }
            return any;
        }

        // Processo-vigia: fica escondido esperando o painel terminar (por qualquer motivo) e então arruma a tela
        // e devolve o som dos navegadores que o painel tinha silenciado.
        public static void Run(string pidText)
        {
            int pid;
            if (!int.TryParse(pidText, out pid)) return;
            try
            {
                using (Process p = Process.GetProcessById(pid))
                    p.WaitForExit();
            }
            catch { }
            try { BrowserAudio.RestoreSaved(Engine.BrowserProcs); }
            catch { }
            for (int i = 0; i < 4; i++)
            {
                SweepTaskbars();
                Thread.Sleep(400);
            }
        }

        public static void StartWatchdog()
        {
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo(Application.ExecutablePath,
                    "--guard " + Process.GetCurrentProcess().Id);
                psi.UseShellExecute = false;
                psi.CreateNoWindow = true;
                psi.WindowStyle = ProcessWindowStyle.Hidden;
                Process.Start(psi);
            }
            catch (Exception ex) { ErrorLog.Write(ex); }
        }

        // Erro na interface: registra e segue em frente. Se repetir demais, desliga tudo por segurança.
        public static void OnUiException(Engine engine, Exception ex)
        {
            ErrorLog.Write(ex);
            DateTime now = DateTime.UtcNow;
            if ((now - _errStart).TotalSeconds > 10.0)
            {
                _errStart = now;
                _errCount = 0;
            }
            _errCount++;
            if (_errCount >= 6)
            {
                _errCount = 0;
                try { engine.ReleaseAll(); }
                catch { }
                SweepTaskbars();
            }
        }
    }
    // Tarefa agendada do Windows: a cada vez que o usuário entra no notebook, abre o painel com "--boot"
    // (que pergunta se está na igreja). Roda com privilégio total e também na bateria.
    internal static class BootTask
    {
        private const string TaskName = "NovoAmanhaHelper-Pergunta";

        // true se a última tarefa criada roda com privilégio máximo (sem pedir permissão ao ligar o notebook).
        public static bool Elevated;

        // Pastas que o usuário comum não consegue alterar. Só nelas é seguro rodar com privilégio máximo
        // sem pedir permissão: em Downloads/Desktop, qualquer programa do usuário poderia trocar o .exe.
        private static bool IsProtectedLocation(string exe)
        {
            try
            {
                string full = Path.GetFullPath(exe);
                string[] roots = new string[]
                {
                    Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
                    Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),
                    Environment.GetFolderPath(Environment.SpecialFolder.Windows)
                };
                foreach (string r in roots)
                {
                    if (string.IsNullOrEmpty(r)) continue;
                    string root = r.TrimEnd('\\') + "\\";
                    if (full.StartsWith(root, StringComparison.OrdinalIgnoreCase)) return true;
                }
            }
            catch { }
            return false;
        }

        private static bool Run(string args)
        {
            try
            {
                string exe = Path.Combine(Environment.SystemDirectory, "schtasks.exe");
                ProcessStartInfo psi = new ProcessStartInfo(exe, args);
                psi.UseShellExecute = false;
                psi.CreateNoWindow = true;
                psi.WindowStyle = ProcessWindowStyle.Hidden;
                using (Process p = Process.Start(psi))
                {
                    if (!p.WaitForExit(20000)) return false;
                    return p.ExitCode == 0;
                }
            }
            catch (Exception ex)
            {
                ErrorLog.Write(ex);
                return false;
            }
        }

        public static bool Install()
        {
            string tmp = Path.Combine(Path.GetTempPath(), "nah_" + Guid.NewGuid().ToString("N") + ".xml");
            try
            {
                string user = SecurityElement.Escape(WindowsIdentity.GetCurrent().Name);
                string exe = SecurityElement.Escape(Application.ExecutablePath);
                Elevated = IsProtectedLocation(Application.ExecutablePath);
                string level = Elevated ? "HighestAvailable" : "LeastPrivilege";
                string xml =
                    "<?xml version=\"1.0\" encoding=\"UTF-16\"?>\r\n" +
                    "<Task version=\"1.2\" xmlns=\"http://schemas.microsoft.com/windows/2004/02/mit/task\">\r\n" +
                    "  <RegistrationInfo><Description>Novo Amanha Helper: pergunta se esta na igreja ao ligar o notebook</Description></RegistrationInfo>\r\n" +
                    "  <Triggers><LogonTrigger><Enabled>true</Enabled><UserId>" + user + "</UserId><Delay>PT6S</Delay></LogonTrigger></Triggers>\r\n" +
                    "  <Principals><Principal id=\"Author\"><UserId>" + user + "</UserId><LogonType>InteractiveToken</LogonType><RunLevel>" + level + "</RunLevel></Principal></Principals>\r\n" +
                    "  <Settings><MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy><DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>" +
                    "<StopIfGoingOnBatteries>false</StopIfGoingOnBatteries><AllowHardTerminate>true</AllowHardTerminate><StartWhenAvailable>true</StartWhenAvailable>" +
                    "<ExecutionTimeLimit>PT0S</ExecutionTimeLimit><Enabled>true</Enabled></Settings>\r\n" +
                    "  <Actions Context=\"Author\"><Exec><Command>" + exe + "</Command><Arguments>--boot</Arguments></Exec></Actions>\r\n" +
                    "</Task>";
                File.WriteAllText(tmp, xml, Encoding.Unicode);
                return Run("/Create /TN \"" + TaskName + "\" /XML \"" + tmp + "\" /F");
            }
            catch (Exception ex)
            {
                ErrorLog.Write(ex);
                return false;
            }
            finally
            {
                try { File.Delete(tmp); } catch { }
            }
        }

        public static bool Remove()
        {
            return Run("/Delete /TN \"" + TaskName + "\" /F");
        }
    }
}
