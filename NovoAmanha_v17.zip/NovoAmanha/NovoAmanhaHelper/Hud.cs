using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace NovoAmanha
{
    // Retrato do que está aparecendo na tela compartilhada agora.
    internal struct ShareSnapshot
    {
        public int Kind;        // 0 sem tela compartilhada, 1 vazia (fundo), 2 tela preta, 3 YouTube, 4 navegador, 5 outro programa
        public string Title;
        public string Detail;
        public string Browser;
    }

    // Uma linha extra do texto fixo (atalhos combinados, troca de navegador...).
    internal struct HudLine
    {
        public string Text;
        public Color Col;

        public HudLine(string text, Color col)
        {
            Text = text;
            Col = col;
        }
    }

    internal delegate HudLine[] HudLinesProvider();

    // Texto fixo no canto superior esquerdo do notebook (como o contador de FPS dos jogos).
    // Fica sempre por cima, não rouba o foco e NUNCA pega clique:
    //  - janela "transparente ao mouse" (WS_EX_TRANSPARENT + LAYERED);
    //  - WM_NCHITTEST devolve HTTRANSPARENT;
    //  - quando o mouse chega perto, ele some por completo (região vazia = nada para clicar).
    internal class HudForm : Form
    {
        private readonly Engine _engine;
        private readonly Settings _settings;
        private readonly HudLinesProvider _provider;
        private readonly Timer _data = new Timer();
        private readonly Timer _anim = new Timer();
        private readonly Stopwatch _sw = Stopwatch.StartNew();
        private readonly Font _fTitle = new Font(Fx.TechName(), 12f);
        private readonly Font _fBro = new Font(Fx.TechName(), 10.5f);
        private readonly Font _fSub = new Font("Segoe UI", 8.5f);
        private readonly Font _fSmall = new Font("Segoe UI", 8.5f);

        private string _title = "", _sub = "", _bro = "", _sig = "";
        private Color _col = Theme.Muted;
        private Color _broCol = Theme.Text;
        private HudLine[] _extra = new HudLine[0];
        private int _hT, _hS, _hB;
        private int[] _hX = new int[0];
        private int _kind = -1;
        private double _flashAt = -10.0;
        private int _tick;
        private Region _shape;
        private Region _empty = new Region(new Rectangle(0, 0, 0, 0));
        private bool _ghost;

        public HudForm(Engine engine, Settings settings, HudLinesProvider provider)
        {
            _engine = engine;
            _settings = settings;
            _provider = provider;

            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.Manual;
            ShowInTaskbar = false;
            TopMost = true;
            BackColor = Color.FromArgb(6, 10, 22);
            Opacity = 0.94;
            DoubleBuffered = true;
            Text = "NovoAmanha.Hud";
            Size = new Size(320, 90);

            _data.Interval = 500;
            _data.Tick += delegate
            {
                Pull();
                _tick++;
                if (_tick % 3 == 0) Reassert();
            };
            _anim.Interval = 80;
            _anim.Tick += delegate
            {
                HoverCheck();
                if (Visible && !_ghost && !Fx.Busy) Invalidate();
            };

            Pull();
            Reassert();
        }

        protected override bool ShowWithoutActivation { get { return true; } }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= Native.WS_EX_NOACTIVATE | Native.WS_EX_TOOLWINDOW | Native.WS_EX_LAYERED |
                              Native.WS_EX_TRANSPARENT | Native.WS_EX_TOPMOST;
                return cp;
            }
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x0084)            // WM_NCHITTEST -> HTTRANSPARENT: o clique passa para o que está atrás
            {
                m.Result = (IntPtr)(-1);
                return;
            }
            if (m.Msg == 0x0021)            // WM_MOUSEACTIVATE -> MA_NOACTIVATE: nunca rouba o foco
            {
                m.Result = (IntPtr)3;
                return;
            }
            base.WndProc(ref m);
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            try { Native.SetWindowDisplayAffinity(Handle, Native.WDA_EXCLUDEFROMCAPTURE); }
            catch { }
        }

        public void SetShown(bool on)
        {
            if (on)
            {
                if (!Visible) Show();
                _data.Start();
                _anim.Start();
                Reassert();
            }
            else
            {
                _data.Stop();
                _anim.Stop();
                if (Visible) Hide();
            }
        }

        // Canto superior esquerdo da tela principal; reafirma "sempre por cima" de tempos em tempos.
        private void Reassert()
        {
            try
            {
                Rectangle b = Screen.PrimaryScreen.Bounds;
                Point want = new Point(b.Left + 12, b.Top + 12);
                if (Location != want) Location = want;
                if (IsHandleCreated && Visible)
                    Native.SetWindowPos(Handle, Native.HWND_TOPMOST, want.X, want.Y, 0, 0,
                        Native.SWP_NOSIZE | Native.SWP_NOACTIVATE);
            }
            catch { }
        }

        // Mouse chegou perto: o texto some por completo (sem região = nada a clicar), volta quando sair.
        private void HoverCheck()
        {
            try
            {
                if (!Visible) return;
                Rectangle b = Bounds;
                b.Inflate(10, 10);
                bool over = b.Contains(Cursor.Position);
                if (over == _ghost) return;
                _ghost = over;
                ApplyRegion();
                if (!_ghost) Invalidate();
            }
            catch { }
        }

        private void ApplyRegion()
        {
            try
            {
                if (_ghost) Region = _empty;
                else if (_shape != null) Region = _shape;
            }
            catch { }
        }

        private static string Trim(string s, int max)
        {
            if (s == null) return "";
            s = s.Trim();
            return s.Length <= max ? s : s.Substring(0, Math.Max(1, max - 1)) + "…";
        }

        private void Pull()
        {
            try
            {
                ShareSnapshot s = _engine.Snapshot();
                bool yt = s.Kind == 3;
                string title = yt ? "YOUTUBE NA COMPARTILHADA: SIM" : "YOUTUBE NA COMPARTILHADA: NÃO";
                Color col = yt ? Color.FromArgb(255, 92, 110) : Color.FromArgb(120, 200, 255);

                string sub;
                switch (s.Kind)
                {
                    case 0: sub = "sem tela compartilhada (Win+P → Estender)"; break;
                    case 1: sub = "aparecendo o fundo (papel de parede)"; break;
                    case 2: sub = "aparecendo tela preta"; break;
                    case 3: sub = Trim(s.Detail, 60); break;
                    case 4: sub = "navegador, sem YouTube"; break;
                    default: sub = "programa: " + Trim(s.Title, 36); break;
                }

                string bro;
                Color bcol = Theme.Text;
                string active = _engine.SwapOn ? BrowserCatalog.ShortName(_engine.SwapActive) : "";
                if (s.Browser != null && s.Browser.Length > 0 && (s.Kind == 3 || s.Kind == 4))
                {
                    bro = "NAVEGADOR PASSANDO: " + s.Browser;
                    bcol = Theme.Accent;
                }
                else if (active.Length > 0)
                {
                    bro = "NAVEGADOR LIBERADO: " + active;
                    bcol = Theme.Gold;
                }
                else
                {
                    bro = "NAVEGADOR PASSANDO: nenhum";
                    bcol = Theme.Muted;
                }

                HudLine[] extra = new HudLine[0];
                if (_provider != null)
                {
                    try { extra = _provider() ?? extra; }
                    catch (Exception ex) { ErrorLog.Write(ex); }
                }

                string sig = title + "|" + sub + "|" + bro + "|" + col.ToArgb() + "|" + bcol.ToArgb();
                foreach (HudLine l in extra) sig += "|" + l.Text + l.Col.ToArgb();

                if (s.Kind != _kind)
                {
                    _kind = s.Kind;
                    _flashAt = _sw.Elapsed.TotalSeconds;
                }
                if (sig != _sig)
                {
                    _sig = sig;
                    _title = title;
                    _sub = sub;
                    _bro = bro;
                    _col = col;
                    _broCol = bcol;
                    _extra = extra;
                    Relayout();
                    Invalidate();
                }
            }
            catch (Exception ex) { ErrorLog.Write(ex); }
        }

        private static Size Measure(string text, Font f)
        {
            if (text == null || text.Length == 0) return Size.Empty;
            return TextRenderer.MeasureText(text, f, new Size(3000, 200),
                TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix | TextFormatFlags.SingleLine);
        }

        private void Relayout()
        {
            Size sT = Measure(_title, _fTitle);
            Size sS = Measure(_sub, _fSub);
            Size sB = Measure(_bro, _fBro);
            _hT = sT.Height;
            _hS = sS.Height;
            _hB = sB.Height;
            int w = Math.Max(sT.Width, Math.Max(sS.Width, sB.Width));
            int h = 11 + _hT + (_hS > 0 ? 2 + _hS : 0) + 4 + _hB;

            _hX = new int[_extra.Length];
            if (_extra.Length > 0)
            {
                h += 9;
                for (int i = 0; i < _extra.Length; i++)
                {
                    Size s = Measure(_extra[i].Text, _fSmall);
                    _hX[i] = s.Height;
                    if (s.Width > w) w = s.Width;
                    h += s.Height + 3;
                }
            }
            h += 10;
            w += 40 + 20;
            if (w < 240) w = 240;

            if (w != Width || h != Height)
            {
                Size = new Size(w, h);
                using (GraphicsPath p = Fx.Chamfer(new Rectangle(0, 0, Width, Height), 12))
                {
                    Region old = _shape;
                    _shape = new Region(p);
                    if (!_ghost) Region = _shape;
                    if (old != null) old.Dispose();
                }
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            double t = _sw.Elapsed.TotalSeconds;
            float pulse = 0.5f + 0.5f * (float)Math.Sin(t * 3.0);
            float flash = (float)Math.Max(0.0, 1.0 - (t - _flashAt) / 0.9);
            if (Width < 40 || Height < 30) return;

            Rectangle r = new Rectangle(0, 0, Width - 1, Height - 1);
            using (GraphicsPath p = Fx.Chamfer(r, 12))
            {
                using (LinearGradientBrush b = new LinearGradientBrush(r, Color.FromArgb(6, 12, 28), Color.FromArgb(22, 14, 46), 25f))
                    g.FillPath(b, p);
                int ba = (int)(150 + 30 * pulse + 105 * flash);
                if (ba > 255) ba = 255;
                using (Pen pen = new Pen(Color.FromArgb(ba, _col), 1.2f + 1.5f * flash))
                    g.DrawPath(pen, p);
            }
            // barra de destaque à esquerda e "colchetes" nos cantos (visual HUD)
            using (SolidBrush bar = new SolidBrush(_col))
                g.FillRectangle(bar, 0, 16, 3, Height - 32);
            using (Pen br = new Pen(Color.FromArgb(200, Theme.Accent), 1.5f))
            {
                g.DrawLine(br, Width - 13, 1, Width - 2, 1);
                g.DrawLine(br, Width - 2, 1, Width - 2, 12);
                g.DrawLine(br, 1, Height - 2, 12, Height - 2);
                g.DrawLine(br, 1, Height - 13, 1, Height - 2);
            }

            TextFormatFlags fl = TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix | TextFormatFlags.SingleLine;

            // bolinha pulsante com onda
            float cx = 22f;
            float cy = 11f + _hT / 2f;
            float rip = (float)((t * 0.9) % 1.0);
            float rr = 4f + rip * 8f;
            using (Pen rp = new Pen(Color.FromArgb((int)(150 * (1f - rip)), _col), 1.5f))
                g.DrawEllipse(rp, cx - rr, cy - rr, rr * 2f, rr * 2f);
            using (SolidBrush db = new SolidBrush(_col))
                g.FillEllipse(db, cx - 4.5f, cy - 4.5f, 9f, 9f);

            int y = 11;
            TextRenderer.DrawText(g, _title, _fTitle, new Point(40, y), _col, fl);
            y += _hT;
            if (_hS > 0)
            {
                y += 2;
                TextRenderer.DrawText(g, _sub, _fSub, new Point(40, y), Color.FromArgb(205, 215, 235), fl);
                y += _hS;
            }
            y += 4;
            TextRenderer.DrawText(g, _bro, _fBro, new Point(40, y), _broCol, fl);
            y += _hB;

            if (_extra.Length > 0)
            {
                y += 4;
                using (Pen sep = new Pen(Color.FromArgb(70, 120, 160, 220), 1f))
                    g.DrawLine(sep, 40, y, Width - 16, y);
                y += 5;
                for (int i = 0; i < _extra.Length; i++)
                {
                    TextRenderer.DrawText(g, _extra[i].Text, _fSmall, new Point(40, y), _extra[i].Col, fl);
                    y += _hX[i] + 3;
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _data.Dispose();
                _anim.Dispose();
                _fTitle.Dispose();
                _fBro.Dispose();
                _fSub.Dispose();
                _fSmall.Dispose();
                if (_empty != null) _empty.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
