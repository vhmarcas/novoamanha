using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Reflection;
using System.Security.Principal;
using System.Text;
using System.Windows.Forms;

namespace NovoAmanha
{
    // Painel sem tremida ao redimensionar.
    internal class BufferedPanel : Panel
    {
        public BufferedPanel()
        {
            DoubleBuffered = true;
            ResizeRedraw = true;
        }
    }

    internal class MainForm : Form
    {
        private const int N = Settings.Count;
        private const float BaseW = 880f;
        private const float BaseH = 604f;

        private readonly Settings _settings;
        private readonly Engine _engine;
        private readonly ToggleSwitch[] _toggles = new ToggleSwitch[N];
        private readonly Button[] _keyButtons = new Button[N];
        private readonly RoundedPanel[] _cards = new RoundedPanel[N];
        private readonly Label[] _cardTitles = new Label[N];
        private readonly Label[] _cardDescs = new Label[N];
        private readonly Label[] _cardKeyLabels = new Label[N];
        private readonly Label[] _cardStatus = new Label[N];
        private const int CB = Settings.Combos;
        private const int IDX_SWAP = N + CB;      // atalho que troca o navegador ativo
        private const int IDX_REL = N + CB + 1;    // atalho de emergência (liberar tudo)
        private const int TOTAL = N + CB + 2;      // atalhos: recursos, combinados, troca, emergência
        private readonly bool[] _hkOk = new bool[TOTAL];
        private readonly RoundedPanel[] _cbCards = new RoundedPanel[CB];
        private readonly Label[] _cbTitles = new Label[CB];
        private readonly CheckBox[][] _cbChecks = new CheckBox[CB][];
        private readonly Label[] _cbKeyLabels = new Label[CB];
        private readonly Button[] _cbKeyButtons = new Button[CB];
        private static readonly string[] ShortNames = new string[]
        {
            "Só navegadores", "Tela preta", "Navegador sem barras", "Só o YouTube"
        };
        private readonly BannerPanel _header = new BannerPanel();
        private readonly BufferedPanel _body = new BufferedPanel();
        private readonly CanvasPanel _canvas = new CanvasPanel();      // conteúdo comprido que sobe/desce
        private readonly SlimScroll _bar = new SlimScroll();
        private readonly Panel _footer = new Panel();
        private FxButton _btnSaveSize, _btnDefSize;
        private readonly Label _lblSize = new Label();
        private CheckBox _askBoot;
        private int _contentH;
        private float _scrollPos, _scrollTarget;
        private bool _smoothSet;
        private readonly Timer _scrollTimer = new Timer();
        private readonly Timer _busyTimer = new Timer();
        private WheelFilter _wheel;
        private bool _shareBusy;
        private readonly Label _lblScreens = new Label();
        private readonly Label _lblProtect = new Label();
        private readonly Label _lblMeet = new Label();
        private readonly Label _lblHint = new Label();
        private Button _pinBtn;
        private Button _extrasBtn;
        private ClockService _clock;
        private BackdropService _backdropSvc;
        private readonly Label _lblDevTitle = new Label();
        private readonly Label _lblDevHelp = new Label();
        private Button _btnRefresh;
        private Button _btnCopy;
        private readonly ListView _devList = new ListView();
        private ListViewGroup _grpScreens, _grpShare, _grpUsb, _grpBt;
        private string _shareSig = "";
        private readonly List<string> _checkedIds = new List<string>();   // itens marcados (sobrevivem à atualização da lista)
        private DateTime _lastShareScan = DateTime.MinValue;
        private readonly Timer _refreshTimer = new Timer();
        private bool _populating;
        private bool _scanning;
        private bool _scanAgain;
        private readonly Timer _guard = new Timer();
        private int _capturing = -1;
        private string _protectText = "";
        private bool _protectOk;
        private uint _affinity;          // proteção aplicada (0 = nenhuma)
        private bool _built;
        private bool _layouting;
        private float _k = 1f;           // fator de escala (textos e botões)
        private float _fontK = -1f;
        private Font _fCardTitle, _fBody, _fSmall, _fBtn, _fKey;

        private static readonly string[] Titles = new string[]
        {
            "Só navegadores na tela compartilhada",
            "Tela preta na compartilhada",
            "Navegador sem barras (só o conteúdo)",
            "Só o YouTube na tela compartilhada"
        };

        private static readonly string[] Descs = new string[]
        {
            "Na TV/projetor aparecem apenas Firefox, Edge e Chrome. O resto fica só no notebook.",
            "A TV/projetor fica toda preta. No notebook tudo continua visível e funcionando.",
            "Esconde abas, barra de pesquisa e rodapé do navegador na tela compartilhada (tela cheia).",
            "Navegue no YouTube à vontade no notebook. Ao abrir um vídeo, ele é pausado aqui e abre sozinho em tela cheia de verdade numa janela própria da TV/projetor (nada do que você clicar no notebook aparece lá). Precisa da leitura de abas ativada no build."
        };

        public MainForm(Settings settings, Engine engine)
        {
            _settings = settings;
            _engine = engine;
            Engine.SetFreeApps(settings.FreeApps);

            Text = "Novo Amanhã Helper";
            AutoScaleMode = AutoScaleMode.None;
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.Sizable;   // painel redimensionável
            MaximizeBox = true;
            MinimizeBox = true;
            MinimumSize = new Size(440, 400);
            BackColor = Theme.Bg;
            Font = new Font("Segoe UI", 9.5f);
            Icon = MakeIcon();

            Rectangle wa = Screen.PrimaryScreen.WorkingArea;
            int cw0 = _settings.WinW >= 440 ? _settings.WinW : 880;
            int ch0 = _settings.WinH >= 400 ? _settings.WinH : 604;
            ClientSize = new Size(Math.Min(cw0, wa.Width - 20), Math.Min(ch0, wa.Height - 40));
            StartPosition = FormStartPosition.Manual;
            Location = new Point(wa.Left + (wa.Width - Width) / 2, wa.Top + (wa.Height - Height) / 2);

            BuildUi();

            _engine.Changed += delegate { UpdateStatus(); };
            _toggles[0].CheckedChanged += delegate { _engine.BrowsersOnly = _toggles[0].Checked; };
            _toggles[1].CheckedChanged += delegate { _engine.Black = _toggles[1].Checked; };
            _toggles[2].CheckedChanged += delegate { _engine.Fullscreen = _toggles[2].Checked; };
            _toggles[3].CheckedChanged += delegate { _engine.YouTube = _toggles[3].Checked; };

            _guard.Interval = 400;
            _guard.Tick += delegate { KeepOnPrimary(); EnsureProtection(); RetryHotkeys(); _engine.EnsureExtended(); RefreshSharing(); UpdateStatus(); };
            _guard.Start();
        }

        // ---------- interface ----------

        private void BuildUi()
        {
            _header.Dock = DockStyle.Top;
            _header.Height = 105;

            _body.Dock = DockStyle.Fill;
            _body.AutoScroll = false;
            _body.BackColor = Theme.Bg;
            _body.Controls.Add(_canvas);
            _body.Controls.Add(_bar);
            _bar.Visible = false;
            _bar.Scrolled += delegate { OnBarScrolled(); };

            _scrollTimer.Interval = 15;
            _scrollTimer.Tick += delegate
            {
                try { ScrollTick(); }
                catch (Exception ex) { ErrorLog.Write(ex); _scrollTimer.Stop(); Fx.Busy = false; }
            };
            _busyTimer.Interval = 220;
            _busyTimer.Tick += delegate { _busyTimer.Stop(); if (!_scrollTimer.Enabled) Fx.Busy = false; };

            BuildFooter();
            Controls.Add(_body);
            Controls.Add(_footer);
            Controls.Add(_header);
            _body.BringToFront();   // o corpo ocupa o que sobra entre o cabeçalho e o rodapé

            for (int i = 0; i < N; i++) AddCard(i);
            for (int c = 0; c < CB; c++) AddCombo(c);
            BuildSafety();
            BuildSwap();
            for (int i = 0; i < TOTAL; i++) _hkOk[i] = true;

            _lblScreens.AutoSize = false;
            _lblScreens.ForeColor = Theme.Muted;
            _canvas.Controls.Add(_lblScreens);

            _lblProtect.AutoSize = false;
            _lblProtect.ForeColor = Theme.Muted;
            _canvas.Controls.Add(_lblProtect);

            _lblMeet.AutoSize = false;
            _lblMeet.ForeColor = Theme.Muted;
            _lblMeet.Text = "● Google Meet: procurando...";
            _canvas.Controls.Add(_lblMeet);

            _lblHint.AutoSize = false;
            _lblHint.ForeColor = Theme.Muted;
            _canvas.Controls.Add(_lblHint);

            _pinBtn = MakeButton("Fixar na barra de tarefas", Color.FromArgb(0, 104, 136), Color.White);
            _pinBtn.Click += delegate { OfferPin(); };
            _canvas.Controls.Add(_pinBtn);

            _extrasBtn = MakeButton("Relógio e fundo da tela...", Color.FromArgb(70, 46, 140), Color.White);
            _extrasBtn.Click += delegate { OpenExtras(); };
            _canvas.Controls.Add(_extrasBtn);

            _lblDevTitle.AutoSize = false;
            _lblDevTitle.ForeColor = Theme.Text;
            _lblDevTitle.Text = "Dispositivos conectados";
            _canvas.Controls.Add(_lblDevTitle);

            _lblDevHelp.AutoSize = false;
            _lblDevHelp.ForeColor = Theme.Muted;
            _lblDevHelp.Text = "Toque num item para marcar ou desmarcar (pode marcar vários). " +
                "As telas marcadas viram as telas do compartilhamento; sem nenhuma tela marcada, uso todas as extras. " +
                "Os outros itens (apps, USB, Bluetooth) só ficam marcados para a sua referência.";
            _canvas.Controls.Add(_lblDevHelp);

            _btnRefresh = MakeButton("Atualizar lista", Color.FromArgb(14, 26, 50), Theme.Text);
            _btnRefresh.Click += delegate { RefreshDevices(true); };
            _canvas.Controls.Add(_btnRefresh);

            _btnCopy = MakeButton("Copiar diagnóstico", Color.FromArgb(14, 26, 50), Theme.Text);
            _btnCopy.Click += delegate { CopyReport(); };
            _canvas.Controls.Add(_btnCopy);

            _grpScreens = new ListViewGroup("Telas (compartilhamento de tela)", HorizontalAlignment.Left);
            _grpShare = new ListViewGroup("Compartilhamento de tela (Meet, Zoom...)", HorizontalAlignment.Left);
            _grpUsb = new ListViewGroup("Entradas do notebook (USB)", HorizontalAlignment.Left);
            _grpBt = new ListViewGroup("Bluetooth", HorizontalAlignment.Left);
            _devList.Groups.Add(_grpScreens);
            _devList.Groups.Add(_grpShare);
            _devList.Groups.Add(_grpUsb);
            _devList.Groups.Add(_grpBt);
            _devList.View = View.Details;
            _devList.HeaderStyle = ColumnHeaderStyle.None;
            _devList.Columns.Add("Dispositivo", 300);
            _devList.CheckBoxes = true;
            _devList.FullRowSelect = true;
            _devList.MultiSelect = false;
            _devList.ShowGroups = true;
            _devList.BorderStyle = BorderStyle.None;
            _devList.BackColor = Theme.Card;
            _devList.ForeColor = Theme.Text;
            _devList.HideSelection = false;
            _devList.MouseUp += OnDevMouseUp;
            _devList.ItemCheck += OnDevItemCheck;
            _devList.ItemChecked += OnDevItemChecked;
            _canvas.Controls.Add(_devList);

            _refreshTimer.Interval = 1500;
            _refreshTimer.Tick += delegate { _refreshTimer.Stop(); RefreshDevices(false); };

            _toast = new Toast();
            Controls.Add(_toast);
            _toast.BringToFront();

            _anim.Interval = 80;
            _anim.Tick += delegate
            {
                try { AnimTick(); }
                catch (Exception ex) { ErrorLog.Write(ex); }
            };
            _anim.Start();

            RefreshKeyLabels();
            _built = true;
            LayoutUi();
        }

        private void AddCard(int index)
        {
            RoundedPanel card = new RoundedPanel();
            _canvas.Controls.Add(card);
            _cards[index] = card;

            Label t = new Label();
            t.AutoSize = false;
            t.Text = Titles[index];
            t.ForeColor = Theme.Text;
            t.BackColor = Theme.Card;
            t.TextAlign = ContentAlignment.MiddleLeft;
            card.Controls.Add(t);
            _cardTitles[index] = t;

            ToggleSwitch toggle = new ToggleSwitch();
            toggle.BackColor = Theme.Card;
            card.Controls.Add(toggle);
            _toggles[index] = toggle;

            Label d = new Label();
            d.AutoSize = false;
            d.Text = Descs[index];
            d.ForeColor = Theme.Muted;
            d.BackColor = Theme.Card;
            card.Controls.Add(d);
            _cardDescs[index] = d;

            Label k = new Label();
            k.AutoSize = false;
            k.Text = "Atalho:";
            k.ForeColor = Theme.Muted;
            k.BackColor = Theme.Card;
            k.TextAlign = ContentAlignment.MiddleLeft;
            card.Controls.Add(k);
            _cardKeyLabels[index] = k;

            FxButton keyBtn = new FxButton();
            keyBtn.FlatStyle = FlatStyle.Flat;
            keyBtn.FlatAppearance.BorderColor = Theme.Edge;
            keyBtn.BackColor = Color.FromArgb(14, 26, 50);
            keyBtn.ForeColor = Theme.Gold;
            keyBtn.Cursor = Cursors.Hand;
            int idx = index;
            keyBtn.Click += delegate { BeginCapture(idx); };
            card.Controls.Add(keyBtn);
            _keyButtons[index] = keyBtn;

            Label st = new Label();
            st.AutoSize = false;
            st.ForeColor = Theme.Muted;
            st.BackColor = Theme.Card;
            st.Visible = false;
            card.Controls.Add(st);
            _cardStatus[index] = st;
        }

        private void AddCombo(int c)
        {
            RoundedPanel card = new RoundedPanel();
            _canvas.Controls.Add(card);
            _cbCards[c] = card;

            Label t = new Label();
            t.AutoSize = false;
            t.Text = "Atalho combinado " + (c + 1) + ": liga/desliga vários recursos de uma vez";
            t.ForeColor = Theme.Text;
            t.BackColor = Theme.Card;
            t.TextAlign = ContentAlignment.MiddleLeft;
            card.Controls.Add(t);
            _cbTitles[c] = t;

            _cbChecks[c] = new CheckBox[N];
            for (int i = 0; i < N; i++)
            {
                CheckBox cb = new CheckBox();
                cb.AutoSize = false;
                cb.Text = ShortNames[i];
                cb.ForeColor = Theme.Text;
                cb.BackColor = Theme.Card;
                cb.Checked = (_settings.ComboMask[c] & (1 << i)) != 0;
                int cc = c, ii = i;
                cb.CheckedChanged += delegate
                {
                    int m = _settings.ComboMask[cc];
                    if (_cbChecks[cc][ii].Checked) m |= (1 << ii); else m &= ~(1 << ii);
                    _settings.ComboMask[cc] = m;
                    _settings.Save();
                };
                card.Controls.Add(cb);
                _cbChecks[c][i] = cb;
            }

            Label k = new Label();
            k.AutoSize = false;
            k.Text = "Atalho:";
            k.ForeColor = Theme.Muted;
            k.BackColor = Theme.Card;
            k.TextAlign = ContentAlignment.MiddleLeft;
            card.Controls.Add(k);
            _cbKeyLabels[c] = k;

            FxButton kb = new FxButton();
            kb.FlatStyle = FlatStyle.Flat;
            kb.FlatAppearance.BorderColor = Theme.Edge;
            kb.BackColor = Color.FromArgb(14, 26, 50);
            kb.ForeColor = Theme.Gold;
            kb.Cursor = Cursors.Hand;
            int idx = N + c;
            kb.Click += delegate { BeginCapture(idx); };
            card.Controls.Add(kb);
            _cbKeyButtons[c] = kb;
        }

        private int LayoutCombo(int c, int left, int top, int cw, int ip)
        {
            int inner = cw - 2 * ip;
            Label t = _cbTitles[c];
            Size ts = Measure(t.Text, _fCardTitle, inner);
            t.SetBounds(ip, ip, inner, ts.Height + S(4));
            int y = ip + ts.Height + S(4) + S(8);

            int x = ip, rowH = 0;
            for (int i = 0; i < N; i++)
            {
                CheckBox cb = _cbChecks[c][i];
                Size ms = Measure(cb.Text, _fBody, 100000);
                int w = ms.Width + S(34);
                int h = Math.Max(S(26), ms.Height + S(8));
                if (x + w > cw - ip && x > ip) { x = ip; y += rowH + S(4); rowH = 0; }
                cb.SetBounds(x, y, w, h);
                x += w + S(10);
                if (h > rowH) rowH = h;
            }
            y += rowH + S(10);

            Label kl = _cbKeyLabels[c];
            Size ks = Measure(kl.Text, _fBody, 100000);
            int klw = ks.Width + S(10);
            Button kb = _cbKeyButtons[c];
            int bw = inner - klw - S(6);
            Size bs = Measure(kb.Text, _fKey, bw - S(16));
            int bh = Math.Max(S(34), bs.Height + S(14));
            kl.SetBounds(ip, y, klw, bh);
            kb.SetBounds(ip + klw + S(6), y, bw, bh);
            y += bh + ip;

            _cbCards[c].Radius = S(18);
            _cbCards[c].SetBounds(left, top, cw, y);
            return y;
        }

        // Liga tudo do combo; se tudo já está ligado, desliga tudo.
        private void RunCombo(int c)
        {
            int mask = _settings.ComboMask[c];
            if (mask == 0) return;
            bool allOn = true;
            for (int i = 0; i < N; i++)
                if ((mask & (1 << i)) != 0 && !_toggles[i].Checked) allOn = false;
            for (int i = 0; i < N; i++)
                if ((mask & (1 << i)) != 0) _toggles[i].Checked = !allOn;
        }

        private HotkeyDef GetKey(int i)
        {
            if (i < N) return _settings.Hotkeys[i];
            if (i < N + CB) return _settings.ComboKeys[i - N];
            if (i == IDX_SWAP) return _settings.SwapKey;
            return _settings.ReleaseKey;
        }

        private void SetKey(int i, HotkeyDef d)
        {
            if (i < N) _settings.Hotkeys[i] = d;
            else if (i < N + CB) _settings.ComboKeys[i - N] = d;
            else if (i == IDX_SWAP) _settings.SwapKey = d;
            else _settings.ReleaseKey = d;
        }

        private static FxButton MakeButton(string text, Color back, Color fore)
        {
            FxButton b = new FxButton();
            b.Text = text;
            b.Base = back;
            b.ForeColor = fore;
            b.Backdrop = Theme.Bg;
            return b;
        }

        // ---------- layout adaptável ----------

        private int S(int v)
        {
            return (int)Math.Round(v * _k);
        }

        private static Size Measure(string text, Font f, int width)
        {
            if (width < 10) width = 10;
            Size s = TextRenderer.MeasureText(text, f, new Size(width, 0),
                TextFormatFlags.WordBreak | TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix);
            return new Size(s.Width, s.Height);
        }

        protected override void OnSizeChanged(EventArgs e)
        {
            base.OnSizeChanged(e);
            if (_built) LayoutUi();
        }

        protected override void OnResizeBegin(EventArgs e)
        {
            base.OnResizeBegin(e);
            Fx.Busy = true;
        }

        protected override void OnResizeEnd(EventArgs e)
        {
            base.OnResizeEnd(e);
            Fx.Busy = false;
            if (_built) LayoutUi();
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            try
            {
                _wheel = new WheelFilter(this);
                Application.AddMessageFilter(_wheel);
            }
            catch (Exception ex) { ErrorLog.Write(ex); }
            SyncBootTask(false);
            LayoutUi();
            RefreshDevices(false);
            try
            {
                if (_hud == null)
                {
                    _hud = new HudForm(_engine, _settings, HudLines);
                    _hud.SetShown(_settings.HudOn);
                }
            }
            catch (Exception ex) { ErrorLog.Write(ex); }
            try
            {
                if (_clock == null)
                {
                    BackdropStore.Apply(_settings);
                    _clock = new ClockService(_settings);
                    _clock.Start();
                    _backdropSvc = new BackdropService(_engine);
                    _backdropSvc.Start();
                }
            }
            catch (Exception ex) { ErrorLog.Write(ex); }
        }

        // ---------- relógio e fundo da tela ----------

        private void OpenExtras()
        {
            try
            {
                Dictionary<string, string> names = new Dictionary<string, string>();
                foreach (ListViewItem it in _devList.Items)
                {
                    DeviceInfo d = it.Tag as DeviceInfo;
                    if (d == null || d.Group != Devices.GroupScreens || !d.Selectable || d.Key.Length == 0) continue;
                    string cur;
                    if (names.TryGetValue(d.Key, out cur))
                    {
                        if (cur.IndexOf(d.Name, StringComparison.Ordinal) < 0) names[d.Key] = cur + " + " + d.Name;
                    }
                    else names[d.Key] = d.Name;
                }
                using (ExtrasForm f = new ExtrasForm(_settings, names, ExtrasChanged))
                    f.ShowDialog(this);
            }
            catch (Exception ex) { ErrorLog.Write(ex); }
        }

        private void ExtrasChanged()
        {
            BackdropStore.Apply(_settings);
            if (_clock != null) _clock.Apply();
            if (_backdropSvc != null) _backdropSvc.Poke();
            _engine.NotifyScreensChanged();
        }

        private void ApplyFonts()
        {
            if (_fCardTitle != null && Math.Abs(_fontK - _k) < 0.005f) return;

            Font[] old = new Font[] { _fCardTitle, _fBody, _fSmall, _fBtn, _fKey };
            _fCardTitle = new Font(Fx.TechName(), 10.5f * _k);
            _fBody = new Font("Segoe UI", 9.5f * _k);
            _fSmall = new Font("Segoe UI", 8.5f * _k);
            _fBtn = new Font(Fx.TechName(), 9.5f * _k);
            _fKey = new Font("Segoe UI", 9.5f * _k);
            _fontK = _k;

            for (int i = 0; i < N; i++)
            {
                _cardTitles[i].Font = _fCardTitle;
                _cardDescs[i].Font = _fBody;
                _cardKeyLabels[i].Font = _fBody;
                _keyButtons[i].Font = _fKey;
                _cardStatus[i].Font = _fSmall;
            }
            for (int c = 0; c < CB; c++)
            {
                _cbTitles[c].Font = _fCardTitle;
                _cbKeyLabels[c].Font = _fBody;
                _cbKeyButtons[c].Font = _fKey;
                for (int i = 0; i < N; i++) _cbChecks[c][i].Font = _fBody;
            }
            _swTitle.Font = _fCardTitle;
            _swDesc.Font = _fBody;
            _swLblA.Font = _fBody;
            _swLblB.Font = _fBody;
            _cmbA.Font = _fBody;
            _cmbB.Font = _fBody;
            _swKeyLbl.Font = _fBody;
            _swKeyBtn.Font = _fKey;
            _swStatus.Font = _fSmall;
            _sfTitle.Font = _fCardTitle;
            _sfDesc.Font = _fBody;
            _btnRelease.Font = _fBtn;
            _hudCheck.Font = _fBody;
            _askBoot.Font = _fBody;
            _relKeyLbl.Font = _fBody;
            _relKeyBtn.Font = _fKey;
            _lblScreens.Font = _fBody;
            _lblProtect.Font = _fBody;
            _lblMeet.Font = _fBody;
            _lblHint.Font = _fSmall;
            _pinBtn.Font = _fBtn;
            _extrasBtn.Font = _fBtn;
            _lblDevTitle.Font = _fCardTitle;
            _lblDevHelp.Font = _fSmall;
            _btnRefresh.Font = _fBtn;
            _btnCopy.Font = _fBtn;
            _btnSaveSize.Font = _fBtn;
            _btnDefSize.Font = _fBtn;
            _lblSize.Font = _fSmall;
            _devList.Font = _fBody;

            foreach (Font f in old) if (f != null) f.Dispose();
        }

        private void LayoutUi()
        {
            if (!_built || _layouting) return;
            _layouting = true;
            try
            {
                int W = ClientSize.Width;
                int H = ClientSize.Height;
                if (W < 60 || H < 60) return;   // minimizado

                float k = Math.Min(W / BaseW, H / BaseH);
                k = Math.Max(0.8f, Math.Min(2.2f, k));
                _k = (float)(Math.Round(k * 20.0) / 20.0);

                SuspendLayout();
                ApplyFonts();
                _header.Height = HeaderHeight(W, H);
                _header.K = _k;

                LayoutFooter(W);
                int viewH = Math.Max(10, H - _header.Height - _footer.Height);
                int barW = Math.Max(8, S(11));
                int need = Arrange(W);
                bool showBar = need > viewH;
                if (showBar) need = Arrange(W - barW);
                _contentH = need;
                int cvW = showBar ? W - barW : W;

                _bar.Visible = showBar;
                _bar.Max = need;
                _bar.Page = viewH;
                _bar.SetBounds(W - barW, 0, barW, viewH);
                _bar.Sync();

                float maxScroll = Math.Max(0, need - viewH);
                if (_scrollTarget > maxScroll) _scrollTarget = maxScroll;
                if (_scrollPos > maxScroll) _scrollPos = maxScroll;
                _canvas.SetBounds(0, -(int)Math.Round(_scrollPos), cvW, Math.Max(need, viewH));
                ApplyScroll();
                if (_toast != null) _toast.BottomInset = _footer.Height;
                UpdateSizeLabel();
                _header.Invalidate();
                ResumeLayout(true);
            }
            finally
            {
                _layouting = false;
            }
        }

        // Posiciona tudo para a largura W e devolve a altura necessária.
        private int Arrange(int W)
        {
            int pad = S(20);
            int gap = S(16);
            int ip = S(16);

            int twoColW = (W - 2 * pad - gap) / 2;
            int cols = twoColW >= S(330) ? 2 : 1;
            int cw = cols == 2 ? twoColW : W - 2 * pad;

            int y = pad;
            y += LayoutSafety(pad, y, W - 2 * pad, ip) + gap;
            for (int row = 0; row * cols < N; row++)
            {
                int rowH = 0;
                for (int c = 0; c < cols; c++)
                {
                    int idx = row * cols + c;
                    if (idx >= N) break;
                    int h = LayoutCard(idx, pad + c * (cw + gap), y, cw, ip);
                    if (h > rowH) rowH = h;
                }
                for (int c = 0; c < cols; c++)
                {
                    int idx = row * cols + c;
                    if (idx >= N) break;
                    _cards[idx].Height = rowH;
                }
                y += rowH + gap;
            }

            Size xs = Measure(_extrasBtn.Text, _fBtn, 100000);
            int xbw = Math.Min(W - 2 * pad, Math.Max(S(300), xs.Width + S(40)));
            int xbh = Math.Max(S(42), xs.Height + S(20));
            _extrasBtn.SetBounds(pad, y, xbw, xbh);
            y += xbh + gap;

            for (int c = 0; c < CB; c++)
            {
                int ch = LayoutCombo(c, pad, y, W - 2 * pad, ip);
                y += ch + gap;
            }

            int lw = W - 2 * pad;
            y = PlaceLabel(_lblScreens, _fBody, pad, y, lw) + S(4);
            y = PlaceLabel(_lblProtect, _fBody, pad, y, lw) + S(4);
            y = PlaceLabel(_lblMeet, _fBody, pad, y, lw) + S(4);
            y = PlaceLabel(_lblHint, _fSmall, pad, y, lw) + S(12);

            Size bs = Measure(_pinBtn.Text, _fBtn, 100000);
            int pbw = Math.Min(lw, Math.Max(S(240), bs.Width + S(40)));
            int pbh = Math.Max(S(38), bs.Height + S(18));
            _pinBtn.SetBounds(pad, y, pbw, pbh);
            y += pbh + gap + S(4);

            y = PlaceLabel(_lblDevTitle, _fCardTitle, pad, y, lw) + S(2);
            y = PlaceLabel(_lblDevHelp, _fSmall, pad, y, lw) + S(8);

            Size rs = Measure(_btnRefresh.Text, _fBtn, 100000);
            Size cs = Measure(_btnCopy.Text, _fBtn, 100000);
            int rbw = Math.Max(S(170), rs.Width + S(40));
            int cbw = Math.Max(S(190), cs.Width + S(40));
            int rbh = Math.Max(S(36), Math.Max(rs.Height, cs.Height) + S(16));
            if (rbw + S(10) + cbw <= lw)
            {
                _btnRefresh.SetBounds(pad, y, rbw, rbh);
                _btnCopy.SetBounds(pad + rbw + S(10), y, cbw, rbh);
                y += rbh + S(10);
            }
            else
            {
                rbw = Math.Min(lw, rbw);
                cbw = Math.Min(lw, cbw);
                _btnRefresh.SetBounds(pad, y, rbw, rbh);
                y += rbh + S(8);
                _btnCopy.SetBounds(pad, y, cbw, rbh);
                y += rbh + S(10);
            }

            int lh = S(220);
            _devList.SetBounds(pad, y, lw, lh);
            if (_devList.Columns.Count > 0) _devList.Columns[0].Width = Math.Max(60, lw - S(30));
            y += lh + pad;
            return y;
        }

        private int PlaceLabel(Label l, Font f, int x, int y, int w)
        {
            Size s = Measure(l.Text.Length == 0 ? " " : l.Text, f, w);
            int h = s.Height + S(4);
            l.SetBounds(x, y, w, h);
            return y + h;
        }

        private int LayoutCard(int i, int left, int top, int cw, int ip)
        {
            ToggleSwitch tg = _toggles[i];
            tg.Size = new Size(S(54), S(28));
            tg.Location = new Point(cw - ip - tg.Width, ip);

            int tw = cw - 3 * ip - tg.Width;
            Size ts = Measure(Titles[i], _fCardTitle, tw);
            int th = Math.Max(ts.Height + S(4), tg.Height);
            _cardTitles[i].SetBounds(ip, ip, tw, th);

            int y = ip + th + S(8);
            int dw = cw - 2 * ip;
            Size ds = Measure(Descs[i], _fBody, dw);
            _cardDescs[i].SetBounds(ip, y, dw, ds.Height + S(4));
            y += ds.Height + S(4) + S(10);

            Label kl = _cardKeyLabels[i];
            Size ks = Measure(kl.Text, _fBody, 100000);
            int klw = ks.Width + S(10);
            Button kb = _keyButtons[i];
            int bw = dw - klw - S(6);
            Size bs = Measure(kb.Text, _fKey, bw - S(16));
            int bh = Math.Max(S(34), bs.Height + S(14));
            kl.SetBounds(ip, y, klw, bh);
            kb.SetBounds(ip + klw + S(6), y, bw, bh);
            y += bh;

            Label sl = _cardStatus[i];
            if (sl.Text.Length > 0)
            {
                y += S(8);
                Size ss = Measure(sl.Text, _fSmall, dw);
                sl.SetBounds(ip, y, dw, ss.Height + S(4));
                sl.Visible = true;
                y += ss.Height + S(4);
            }
            else
            {
                sl.Visible = false;
            }
            y += ip;

            _cards[i].Radius = S(18);
            _cards[i].SetBounds(left, top, cw, y);
            return y;
        }

        private void PaintHeader(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            Rectangle r = _header.ClientRectangle;
            if (r.Width < 2 || r.Height < 2) return;
            using (LinearGradientBrush br = new LinearGradientBrush(r,
                Color.FromArgb(255, 120, 60), Color.FromArgb(120, 60, 170), 15f))
                g.FillRectangle(br, r);
            int sd = (int)(r.Height * 1.24);
            using (SolidBrush sun = new SolidBrush(Color.FromArgb(70, 255, 215, 120)))
                g.FillEllipse(sun, r.Right - sd, (int)(r.Height * 0.29), sd, sd);
            using (Font f1 = new Font("Segoe UI Semibold", 21f * _k))
            using (Font f2 = new Font("Segoe UI", 9.5f * _k))
            {
                g.DrawString("Novo Amanhã Helper", f1, Brushes.White, S(22), S(20));
                g.DrawString("Painel invisível para telas compartilhadas", f2, Brushes.White, S(25), S(66));
            }
        }

        private static Icon MakeIcon()
        {
            try
            {
                Bitmap banner = Fx.LoadBanner();
                if (banner != null)
                {
                    // recorta o sol (com os raios) do banner
                    int size = (int)(banner.Width * 0.31f);
                    int cx = banner.Width / 2;
                    int cy = (int)(banner.Height * 0.32f);
                    Rectangle srcRect = new Rectangle(cx - size / 2, Math.Max(0, cy - size / 2), size, size);
                    Bitmap icoBmp = new Bitmap(48, 48);
                    using (Graphics ig = Graphics.FromImage(icoBmp))
                    {
                        ig.InterpolationMode = InterpolationMode.HighQualityBicubic;
                        ig.DrawImage(banner, new Rectangle(0, 0, 48, 48), srcRect, GraphicsUnit.Pixel);
                    }
                    banner.Dispose();
                    return Icon.FromHandle(icoBmp.GetHicon());
                }
            }
            catch { }

            Bitmap bmp = new Bitmap(32, 32);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                using (LinearGradientBrush br = new LinearGradientBrush(new Rectangle(0, 0, 32, 32),
                    Color.FromArgb(255, 138, 61), Color.FromArgb(120, 60, 170), 45f))
                    g.FillEllipse(br, 1, 1, 30, 30);
                using (SolidBrush w = new SolidBrush(Color.FromArgb(255, 235, 170)))
                    g.FillPie(w, 6, 10, 20, 20, 180, 180);
            }
            return Icon.FromHandle(bmp.GetHicon());
        }

        // ---------- proteção: painel nunca aparece nas telas compartilhadas ----------

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            ApplyProtection();
            RegisterAll();
            UpdateStatus();
        }

        private void ApplyProtection()
        {
            if (!IsHandleCreated) return;

            if (Native.SetWindowDisplayAffinity(Handle, Native.WDA_EXCLUDEFROMCAPTURE))
            {
                _affinity = Native.WDA_EXCLUDEFROMCAPTURE;
                _protectOk = true;
                _protectText = "Painel protegido: não aparece em compartilhamentos";
            }
            else if (Native.SetWindowDisplayAffinity(Handle, Native.WDA_MONITOR))
            {
                _affinity = Native.WDA_MONITOR;
                _protectOk = true;
                _protectText = "Painel protegido (aparece preto em compartilhamentos)";
            }
            else
            {
                _affinity = 0;
                _protectOk = false;
                _protectText = "Não foi possível proteger o painel neste Windows";
            }
        }

        // Confere de tempos em tempos (e depois de redimensionar/maximizar) se a proteção continua ligada.
        private void EnsureProtection()
        {
            try
            {
                if (!IsHandleCreated) return;
                uint cur;
                if (_affinity == 0 || !Native.GetWindowDisplayAffinity(Handle, out cur) || cur != _affinity)
                    ApplyProtection();
            }
            catch { }
        }

        // O painel fica sempre na tela principal (o notebook), nunca na TV/projetor.
        private void KeepOnPrimary()
        {
            try
            {
                if (WindowState == FormWindowState.Minimized) return;
                Rectangle wa = Screen.PrimaryScreen.WorkingArea;

                if (WindowState == FormWindowState.Maximized)
                {
                    if (Screen.FromHandle(Handle).Primary) return;
                    WindowState = FormWindowState.Normal;
                }
                else
                {
                    Rectangle core = Rectangle.Inflate(Bounds, -10, -10);
                    bool onOther = false;
                    foreach (Screen s in Screen.AllScreens)
                        if (!s.Primary && s.Bounds.IntersectsWith(core)) onOther = true;
                    if (!onOther) return;
                }

                int w = Math.Min(Width, wa.Width);
                int h = Math.Min(Height, wa.Height);
                Bounds = new Rectangle(wa.Left + (wa.Width - w) / 2, wa.Top + (wa.Height - h) / 2, w, h);
            }
            catch { }
        }

        private bool SetLabel(Label l, string text, Color color)
        {
            l.ForeColor = color;
            if (l.Text == text) return false;
            l.Text = text;
            return true;
        }

        private void UpdateStatus()
        {
            bool changed = false;
            List<Screen> shared = Engine.SharedScreens();
            if (shared.Count == 0)
            {
                changed |= SetLabel(_lblScreens, "● Nenhuma tela compartilhada detectada. " +
                    (_engine.ExtendMessage.Length > 0 ? _engine.ExtendMessage : Engine.Diagnose()), Theme.Warn);
                if (_capturing < 0 && !_hintLocked)
                    changed |= SetLabel(_lblHint,
                        "Conecte a TV/projetor e use Win+P → Estender (o modo Duplicar não funciona).", Theme.Muted);
            }
            else
            {
                changed |= SetLabel(_lblScreens,
                    "● Tela compartilhada: " + shared[0].Bounds.Width + "x" + shared[0].Bounds.Height +
                    (shared.Count > 1 ? "  (+" + (shared.Count - 1) + ")" : ""), Theme.Good);
                if (_capturing < 0 && !_hintLocked)
                    changed |= SetLabel(_lblHint,
                        "Os atalhos funcionam com o painel aberto ou minimizado. No Google Meet, compartilhe a tela da TV/projetor, não a do notebook.", Theme.Muted);
            }
            changed |= SetLabel(_lblProtect, "● " + _protectText, _protectOk ? Theme.Good : Theme.Warn);
            changed |= UpdateSwapUi();
            UpdateBadge();

            for (int i = 0; i < N; i++)
            {
                string txt = _engine.StatusOf(i);
                if (!_hkOk[i])
                {
                    string warn = "Atalho indisponível (em uso por outro programa). Use o interruptor ou troque o atalho.";
                    txt = txt.Length > 0 ? txt + " " + warn : warn;
                }
                changed |= SetLabel(_cardStatus[i], txt, StatusColor(txt));
            }
            if (changed) LayoutUi();
        }

        private static Color StatusColor(string t)
        {
            if (t.IndexOf("Atenção", StringComparison.Ordinal) >= 0 ||
                t.IndexOf("Não consegui", StringComparison.Ordinal) >= 0 ||
                t.IndexOf("indisponível", StringComparison.Ordinal) >= 0 ||
                t.StartsWith("Só existe", StringComparison.Ordinal)) return Theme.Warn;
            if (t.StartsWith("Aguardando", StringComparison.Ordinal) ||
                t.StartsWith("Levando", StringComparison.Ordinal) ||
                t.StartsWith("Abrindo", StringComparison.Ordinal) ||
                t.StartsWith("Entrando", StringComparison.Ordinal) ||
                t.StartsWith("YouTube na tela", StringComparison.Ordinal)) return Theme.Muted;
            return Theme.Good;
        }

        private bool _hintLocked;

        private void SetHint(string text, Color color)
        {
            _hintLocked = true;
            SetLabel(_lblHint, text, color);
            LayoutUi();
        }

        // ---------- lista de dispositivos ----------

        private void ScheduleRefresh()
        {
            _refreshTimer.Stop();
            _refreshTimer.Start();
        }

        private void RefreshDevices(bool manual)
        {
            if (manual) _engine.ResetExtend();
            if (_scanning) { _scanAgain = true; return; }
            _scanning = true;
            _btnRefresh.Enabled = false;
            if (SetLabel(_lblDevTitle, "Dispositivos conectados — procurando...", Theme.Text)) LayoutUi();

            System.Threading.Thread t = new System.Threading.Thread(new System.Threading.ThreadStart(delegate
            {
                List<DeviceInfo> found = Devices.Scan();
                try { BeginInvoke(new MethodInvoker(delegate { FinishScan(found); })); }
                catch { }
            }));
            t.IsBackground = true;
            t.Start();
        }

        private void FinishScan(List<DeviceInfo> found)
        {
            _scanning = false;
            _btnRefresh.Enabled = true;
            ApplyDevices(found);
            if (_scanAgain)
            {
                _scanAgain = false;
                RefreshDevices(false);
            }
        }

        private void ApplyDevices(List<DeviceInfo> found)
        {
            string[] keep = Engine.SelectedScreens;
            _populating = true;
            try
            {
                _devList.BeginUpdate();
                _devList.Items.Clear();
                foreach (DeviceInfo d in found) AddDeviceItem(d, keep);
                if (found.Count == 0)
                {
                    ListViewItem none = new ListViewItem("Nenhum dispositivo encontrado");
                    none.Group = _grpScreens;
                    none.ForeColor = Theme.Muted;
                    _devList.Items.Add(none);
                }
                _devList.EndUpdate();
            }
            finally
            {
                _populating = false;
            }
            _shareSig = ShareSig(found);
            UpdateMeetLabel(found);
            _lastShareScan = DateTime.UtcNow;
            UpdateSelectionFromList();
            UpdateDeviceCount();
        }

        private void AddDeviceItem(DeviceInfo d, string[] keep)
        {
            ListViewItem it = new ListViewItem(d.Text);
            it.Tag = d;
            it.Group = d.Group == Devices.GroupScreens ? _grpScreens :
                       d.Group == Devices.GroupSharing ? _grpShare :
                       d.Group == Devices.GroupBluetooth ? _grpBt : _grpUsb;
            it.ForeColor = d.Selectable ? Theme.Text : Theme.Muted;
            _devList.Items.Add(it);
            bool on = _checkedIds.Contains(IdOf(d)) ||
                      (d.Selectable && keep != null && Array.IndexOf(keep, d.Key) >= 0);
            if (on) it.Checked = true;
        }

        private static string IdOf(DeviceInfo d)
        {
            return d.Group + "|" + d.Name + "|" + d.Key;
        }

        private void UpdateDeviceCount()
        {
            int n = 0, c = 0;
            foreach (ListViewItem it in _devList.Items)
            {
                if (it.Tag is DeviceInfo)
                {
                    n++;
                    if (it.Checked) c++;
                }
            }
            string title = "Dispositivos conectados (" + n + ")" + (c > 0 ? " — " + c + " marcado(s)" : "");
            if (SetLabel(_lblDevTitle, title, Theme.Text)) LayoutUi();
        }

        private void UpdateMeetLabel(List<DeviceInfo> list)
        {
            string meet = "";
            string call = "";
            foreach (DeviceInfo d in list)
            {
                if (d.Group != Devices.GroupSharing) continue;
                if (d.Name == "Google Meet")
                {
                    if (meet.Length == 0) meet = d.Source + (d.Note.Length > 0 ? ", " + d.Note : "");
                }
                else if (d.Name == "Microfone em uso" || d.Name == "Câmera em uso" || d.Name == "Compartilhando a tela")
                {
                    if (call.Length == 0) call = d.Name.ToLowerInvariant() + " (" + d.Source + ")";
                }
            }

            string text;
            Color col;
            if (meet.Length > 0)
            {
                text = "● Google Meet detectado (" + meet + ")";
                col = Theme.Good;
                if (Engine.SharedScreens().Count == 0 && Screen.AllScreens.Length == 1)
                {
                    text += ". Atenção: com 1 tela só, compartilhar a tela inteira mostra TUDO; os interruptores não conseguem filtrar. Use uma 2ª tela (projetor/TV ou monitor virtual).";
                    col = Theme.Warn;
                }
            }
            else if (call.Length > 0)
            {
                text = "● Chamada provável: " + call + ", mas não achei a aba do Meet. Use \"Copiar diagnóstico\" para eu ver as abas.";
                col = Theme.Warn;
            }
            else
            {
                text = "● Google Meet não detectado. Abra a chamada no Chrome, Edge ou Firefox.";
                col = Theme.Muted;
            }
            if (SetLabel(_lblMeet, text, col)) LayoutUi();
        }

        private static string ShareSig(List<DeviceInfo> list)
        {
            StringBuilder sb = new StringBuilder();
            foreach (DeviceInfo d in list)
                if (d.Group == Devices.GroupSharing) sb.Append(d.Text).Append('|');
            return sb.ToString();
        }

        // Meet/Zoom/Teams abrem e fecham a qualquer hora: confere só esse grupo a cada ~3 s.
        // A leitura das janelas abertas roda em segundo plano (antes travava a interface a cada poucos segundos).
        private void RefreshSharing()
        {
            if (!IsHandleCreated || _scanning || _shareBusy || Fx.Busy) return;
            if ((DateTime.UtcNow - _lastShareScan).TotalSeconds < 5.0) return;
            _lastShareScan = DateTime.UtcNow;
            _shareBusy = true;
            System.Threading.ThreadPool.QueueUserWorkItem(delegate
            {
                List<DeviceInfo> res = null;
                try { res = Devices.ScanSharing(); }
                catch { }
                try { BeginInvoke(new MethodInvoker(delegate { _shareBusy = false; if (res != null) ApplyShare(res); })); }
                catch { _shareBusy = false; }
            });
        }

        private void ApplyShare(List<DeviceInfo> now)
        {
            string sig = ShareSig(now);
            if (sig == _shareSig) return;
            _shareSig = sig;
            UpdateMeetLabel(now);

            _populating = true;
            try
            {
                _devList.BeginUpdate();
                for (int i = _devList.Items.Count - 1; i >= 0; i--)
                {
                    DeviceInfo old = _devList.Items[i].Tag as DeviceInfo;
                    if (old != null && old.Group == Devices.GroupSharing) _devList.Items.RemoveAt(i);
                }
                foreach (DeviceInfo d in now) AddDeviceItem(d, null);
                _devList.EndUpdate();
            }
            finally
            {
                _populating = false;
            }
            UpdateDeviceCount();
        }

        // Só telas extras podem ser marcadas; os outros aparelhos são só informação.
        private void OnDevItemCheck(object sender, ItemCheckEventArgs e)
        {
            if (_populating) return;
            DeviceInfo d = _devList.Items[e.Index].Tag as DeviceInfo;
            if (d == null) e.NewValue = e.CurrentValue;
        }

        private void OnDevItemChecked(object sender, ItemCheckedEventArgs e)
        {
            if (_populating) return;
            DeviceInfo me = e.Item.Tag as DeviceInfo;
            if (me != null && me.Selectable && me.Key.Length > 0)
            {
                // TV e projetor espelhados são a mesma tela do Windows: marcar um marca o outro
                _populating = true;
                try
                {
                    foreach (ListViewItem it in _devList.Items)
                    {
                        DeviceInfo o = it.Tag as DeviceInfo;
                        if (o != null && o != me && o.Selectable && o.Key == me.Key && it.Checked != e.Item.Checked)
                            it.Checked = e.Item.Checked;
                    }
                }
                finally { _populating = false; }
            }
            UpdateSelectionFromList();
            UpdateDeviceCount();
        }

        // Clicar em qualquer ponto da linha marca/desmarca (o ListView padrão só marca ao clicar na caixinha).
        private void OnDevMouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left) return;
            ListViewHitTestInfo hit = _devList.HitTest(e.X, e.Y);
            if (hit.Item == null || hit.Location == ListViewHitTestLocations.StateImage) return;
            hit.Item.Checked = !hit.Item.Checked;
        }

        private void UpdateSelectionFromList()
        {
            List<string> keys = new List<string>();
            _checkedIds.Clear();
            foreach (ListViewItem it in _devList.CheckedItems)
            {
                DeviceInfo d = it.Tag as DeviceInfo;
                if (d == null) continue;
                _checkedIds.Add(IdOf(d));
                if (d.Selectable && d.Key.Length > 0) keys.Add(d.Key);
            }
            Engine.SelectedScreens = keys.ToArray();
            _engine.NotifyScreensChanged();
        }

        // ---------- diagnóstico (para colar na conversa quando algo não funciona) ----------

        private string BuildReport()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Novo Amanhã Helper — diagnóstico");
            sb.AppendLine("Data: " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            sb.AppendLine("Windows: " + Environment.OSVersion.VersionString +
                (Environment.Is64BitOperatingSystem ? " (64 bits)" : " (32 bits)"));

            bool admin = false;
            try
            {
                using (WindowsIdentity id = WindowsIdentity.GetCurrent())
                    admin = new WindowsPrincipal(id).IsInRole(WindowsBuiltInRole.Administrator);
            }
            catch { }
            sb.AppendLine("Administrador: " + (admin ? "sim" : "não"));

            Screen[] all = Screen.AllScreens;
            sb.AppendLine("Telas vistas pelo Windows: " + all.Length +
                " | saídas de vídeo ativas: " + Engine.ActivePaths() +
                " | modo Duplicar: " + (Engine.IsDuplicateMode() ? "sim" : "não"));
            for (int i = 0; i < all.Length; i++)
                sb.AppendLine("  " + (i + 1) + ") " + all[i].DeviceName + " " +
                    all[i].Bounds.Width + "x" + all[i].Bounds.Height +
                    " em (" + all[i].Bounds.X + "," + all[i].Bounds.Y + ")" +
                    (all[i].Primary ? " [principal]" : ""));

            sb.AppendLine("Telas do compartilhamento em uso: " + Engine.SharedScreens().Count);
            string[] sel = Engine.SelectedScreens;
            sb.AppendLine("Telas marcadas na lista: " +
                (sel == null || sel.Length == 0 ? "nenhuma (automático)" : string.Join(", ", sel)));
            sb.AppendLine("Proteção do painel: " + _protectText);

            for (int i = 0; i < N; i++)
                sb.AppendLine("Recurso " + (i + 1) + " (" + Titles[i] + "): " +
                    (_toggles[i].Checked ? "LIGADO" : "desligado") +
                    " | atalho " + _settings.Hotkeys[i].ToString() + (_hkOk[i] ? "" : " [INDISPONÍVEL]") +
                    " | " + _cardStatus[i].Text);

            sb.AppendLine("Último erro interno: " + (_engine.LastError.Length > 0 ? _engine.LastError : "nenhum"));
            sb.AppendLine("Dispositivos listados:");
            foreach (ListViewItem it in _devList.Items)
            {
                DeviceInfo d = it.Tag as DeviceInfo;
                if (d != null) sb.AppendLine("  [" + d.Group + "] " + d.Text);
            }
            sb.AppendLine();
            sb.Append(MeetDetector.Dump());
            return sb.ToString();
        }

        private void CopyReport()
        {
            string text = BuildReport();
            string path = "";
            try
            {
                string dir = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "NovoAmanhaHelper");
                Directory.CreateDirectory(dir);
                path = Path.Combine(dir, "diagnostico.txt");
                File.WriteAllText(path, text, Encoding.UTF8);
            }
            catch { path = ""; }

            bool copied = false;
            try { Clipboard.SetText(text); copied = true; }
            catch { }

            string msg;
            if (copied)
                msg = "Diagnóstico copiado! Cole na conversa com Ctrl+V." +
                      (path.Length > 0 ? "\r\n\r\nTambém salvei em:\r\n" + path : "");
            else
                msg = "Não consegui copiar." +
                      (path.Length > 0 ? "\r\n\r\nO diagnóstico foi salvo em:\r\n" + path : "");
            ProtectedDialog.Show(this, msg, false);
        }

        // ---------- segurança, troca de navegadores e animações ----------

        private Toast _toast;
        private readonly Timer _anim = new Timer();
        private HudForm _hud;

        private RoundedPanel _sfCard;
        private Label _sfTitle, _sfDesc, _relKeyLbl;
        private FxButton _btnRelease, _relKeyBtn;
        private CheckBox _hudCheck;

        private List<BrowserInfo> _browsers = new List<BrowserInfo>();
        private RoundedPanel _swCard;
        private Label _swTitle, _swDesc, _swLblA, _swLblB, _swKeyLbl, _swStatus;
        private ToggleSwitch _swToggle;
        private ComboBox _cmbA, _cmbB;
        private BrowserChip _chipA, _chipB;
        private FxButton _swKeyBtn;
        private bool _swLoading;

        private Label NewLabel(Control parent, string text, Color fore)
        {
            Label l = new Label();
            l.AutoSize = false;
            l.Text = text;
            l.ForeColor = fore;
            l.BackColor = Theme.Card;
            l.TextAlign = ContentAlignment.MiddleLeft;
            parent.Controls.Add(l);
            return l;
        }

        private ComboBox NewCombo()
        {
            ComboBox c = new ComboBox();
            c.DropDownStyle = ComboBoxStyle.DropDownList;
            c.FlatStyle = FlatStyle.Flat;
            c.BackColor = Color.FromArgb(14, 26, 50);
            c.ForeColor = Theme.Text;
            foreach (BrowserInfo bi in _browsers) c.Items.Add(bi);
            _swCard.Controls.Add(c);
            return c;
        }

        private void ToastShow(string text, Color col)
        {
            if (_toast != null) _toast.ShowText(text, col);
        }

        private int HeaderHeight(int W, int H)
        {
            int h = (int)(W / 3.45f);              // mostra a parte de baixo do banner (a logo "Novo Amanhã")
            h = Math.Min(h, (int)(H * 0.40f));
            return Math.Max(S(96), Math.Min(h, S(300)));
        }

        private bool AnyActive()
        {
            for (int i = 0; i < N; i++)
                if (_toggles[i].Checked) return true;
            return _swToggle != null && _swToggle.Checked;
        }

        // Linha "Atalho: [botão]"; devolve a altura usada.
        private int LayoutKeyRow(Label kl, Button kb, int x, int y, int inner)
        {
            Size ks = Measure(kl.Text, _fBody, 100000);
            int klw = ks.Width + S(10);
            int bw = inner - klw - S(6);
            Size bs = Measure(kb.Text, _fKey, bw - S(16));
            int bh = Math.Max(S(34), bs.Height + S(14));
            kl.SetBounds(x, y, klw, bh);
            kb.SetBounds(x + klw + S(6), y, bw, bh);
            return bh;
        }

        // ----- segurança -----

        private void BuildSafety()
        {
            _sfCard = new RoundedPanel();
            _canvas.Controls.Add(_sfCard);
            _sfTitle = NewLabel(_sfCard, "Segurança: o painel só mexe na tela enquanto está aberto", Theme.Text);
            _sfDesc = NewLabel(_sfCard,
                "Fechou o painel (ou ele travou)? Tudo volta ao normal sozinho: janelas, barra de tarefas e tela preta. " +
                "Se alguém não souber usar, é só apertar LIBERAR TUDO.", Theme.Muted);
            _sfDesc.TextAlign = ContentAlignment.TopLeft;

            _btnRelease = new FxButton();
            _btnRelease.Text = "LIBERAR TUDO  (desliga tudo e devolve a tela)";
            _btnRelease.Base = Color.FromArgb(190, 48, 62);
            _btnRelease.Edge = Color.FromArgb(230, 90, 100);
            _btnRelease.Hot = Color.FromArgb(255, 130, 130);
            _btnRelease.ForeColor = Color.White;
            _btnRelease.Click += delegate { ReleaseAll(); };
            _sfCard.Controls.Add(_btnRelease);

            _hudCheck = new CheckBox();
            _hudCheck.AutoSize = false;
            _hudCheck.Text = "Mostrar o texto fixo no canto da tela (o que está na compartilhada)";
            _hudCheck.ForeColor = Theme.Text;
            _hudCheck.BackColor = Theme.Card;
            _hudCheck.Checked = _settings.HudOn;
            _hudCheck.CheckedChanged += delegate
            {
                _settings.HudOn = _hudCheck.Checked;
                _settings.Save();
                if (_hud != null) _hud.SetShown(_settings.HudOn);
            };
            _sfCard.Controls.Add(_hudCheck);

            _askBoot = new CheckBox();
            _askBoot.AutoSize = false;
            _askBoot.Text = "Ao ligar o notebook, perguntar se estou na igreja e abrir o painel";
            _askBoot.ForeColor = Theme.Text;
            _askBoot.BackColor = Theme.Card;
            _askBoot.Checked = _settings.AskAtBoot;
            _askBoot.CheckedChanged += delegate
            {
                _settings.AskAtBoot = _askBoot.Checked;
                _settings.Save();
                SyncBootTask(true);
            };
            _sfCard.Controls.Add(_askBoot);

            _relKeyLbl = NewLabel(_sfCard, "Atalho de emergência:", Theme.Muted);
            _relKeyBtn = new FxButton();
            _relKeyBtn.ForeColor = Theme.Gold;
            int ridx = IDX_REL;
            _relKeyBtn.Click += delegate { BeginCapture(ridx); };
            _sfCard.Controls.Add(_relKeyBtn);
        }

        private int LayoutSafety(int left, int top, int cw, int ip)
        {
            int inner = cw - 2 * ip;
            Size ts = Measure(_sfTitle.Text, _fCardTitle, inner);
            _sfTitle.SetBounds(ip, ip, inner, ts.Height + S(4));
            int y = ip + ts.Height + S(4) + S(6);

            Size ds = Measure(_sfDesc.Text, _fBody, inner);
            _sfDesc.SetBounds(ip, y, inner, ds.Height + S(4));
            y += ds.Height + S(4) + S(12);

            Size bs = Measure(_btnRelease.Text, _fBtn, inner - S(24));
            int bh = Math.Max(S(46), bs.Height + S(22));
            _btnRelease.SetBounds(ip, y, inner, bh);
            y += bh + S(12);

            Size cs = Measure(_hudCheck.Text, _fBody, inner - S(30));
            int chh = Math.Max(S(26), cs.Height + S(8));
            _hudCheck.SetBounds(ip, y, inner, chh);
            y += chh + S(6);

            Size acs = Measure(_askBoot.Text, _fBody, inner - S(30));
            int ach = Math.Max(S(26), acs.Height + S(8));
            _askBoot.SetBounds(ip, y, inner, ach);
            y += ach + S(10);

            y += LayoutKeyRow(_relKeyLbl, _relKeyBtn, ip, y, inner);
            y += ip;
            _sfCard.Radius = S(18);
            _sfCard.SetBounds(left, top, cw, y);
            return y;
        }

        // Desliga todos os recursos e devolve janelas e barras de tarefas.
        private void ReleaseAll()
        {
            try
            {
                for (int i = 0; i < N; i++) _toggles[i].Checked = false;
                if (_swToggle != null) _swToggle.Checked = false;
                _engine.ReleaseAll();
                ToastShow("Tudo liberado: a tela compartilhada voltou ao normal.", Theme.Good);
            }
            catch (Exception ex) { ErrorLog.Write(ex); }
        }

        // ----- troca de navegadores -----

        private BrowserInfo FindBrowser(string proc)
        {
            if (string.IsNullOrEmpty(proc)) return null;
            foreach (BrowserInfo bi in _browsers)
                if (string.Equals(bi.Proc, proc, StringComparison.OrdinalIgnoreCase)) return bi;
            return null;
        }

        private string DefaultBrowser(string prefer, string not)
        {
            foreach (BrowserInfo bi in _browsers)
                if (bi.Proc == prefer && bi.Proc != not) return bi.Proc;
            foreach (BrowserInfo bi in _browsers)
                if (bi.Proc != not) return bi.Proc;
            return "";
        }

        private void SelectCombo(ComboBox c, string proc)
        {
            c.SelectedIndex = -1;
            for (int i = 0; i < c.Items.Count; i++)
            {
                BrowserInfo bi = c.Items[i] as BrowserInfo;
                if (bi != null && string.Equals(bi.Proc, proc, StringComparison.OrdinalIgnoreCase))
                {
                    c.SelectedIndex = i;
                    break;
                }
            }
        }

        private string ActiveProc()
        {
            string a = _settings.BrowserA ?? "";
            string b = _settings.BrowserB ?? "";
            string p = _settings.ActiveSlot == 1 ? b : a;
            if (p.Length == 0) p = a.Length > 0 ? a : b;
            return p;
        }

        private static void ChipFill(BrowserChip chip, string proc)
        {
            string n = BrowserCatalog.ShortName(proc);
            chip.BrowserName = n.Length > 0 ? n : "(escolha)";
            chip.Initial = n.Length > 0 ? n.Substring(0, 1).ToUpperInvariant() : "?";
            chip.Tint = n.Length > 0 ? BrowserCatalog.TintOf(proc) : Color.Gray;
            chip.Invalidate();
        }

        private void UpdateChips()
        {
            ChipFill(_chipA, _settings.BrowserA);
            ChipFill(_chipB, _settings.BrowserB);
            _chipA.Active = _settings.ActiveSlot != 1;
            _chipB.Active = _settings.ActiveSlot == 1;
        }

        private void LoadBrowserChoice()
        {
            string a = _settings.BrowserA ?? "";
            string b = _settings.BrowserB ?? "";
            if (FindBrowser(a) == null) a = "";
            if (FindBrowser(b) == null || b == a) b = "";
            if (a.Length == 0) a = DefaultBrowser("firefox", b);
            if (b.Length == 0) b = DefaultBrowser("msedge", a);
            if (b == a) b = "";

            _swLoading = true;
            SelectCombo(_cmbA, a);
            SelectCombo(_cmbB, b);
            _swLoading = false;

            _settings.BrowserA = a;
            _settings.BrowserB = b;
            if (_settings.ActiveSlot != 1) _settings.ActiveSlot = 0;
            UpdateChips();
            _engine.SwapTo(ActiveProc());
        }

        private void BuildSwap()
        {
            _browsers = BrowserCatalog.Detect();

            _swCard = new RoundedPanel();
            _canvas.Controls.Add(_swCard);
            _swTitle = NewLabel(_swCard, "Troca de navegador: um passa na TV, o outro você prepara", Theme.Text);

            _swToggle = new ToggleSwitch();
            _swToggle.BackColor = Theme.Card;
            _swCard.Controls.Add(_swToggle);

            _swDesc = NewLabel(_swCard,
                "Escolha 2 navegadores. Só o ATIVO aparece na tela compartilhada; o outro fica só no notebook, " +
                "e você prepara o próximo louvor nele sem ninguém ver. O som também: só o ativo toca, o outro fica mudo. " +
                "Aperte o atalho (ou clique no cartão) para trocar quem passa." +
                (_browsers.Count < 2 ? " Só achei " + _browsers.Count + " navegador(es) instalado(s) neste notebook." : ""),
                Theme.Muted);
            _swDesc.TextAlign = ContentAlignment.TopLeft;

            _swLblA = NewLabel(_swCard, "Navegador 1:", Theme.Muted);
            _swLblB = NewLabel(_swCard, "Navegador 2:", Theme.Muted);
            _cmbA = NewCombo();
            _cmbB = NewCombo();

            _chipA = new BrowserChip();
            _chipA.Caption = "NAVEGADOR 1";
            _swCard.Controls.Add(_chipA);
            _chipB = new BrowserChip();
            _chipB.Caption = "NAVEGADOR 2";
            _swCard.Controls.Add(_chipB);

            _swKeyLbl = NewLabel(_swCard, "Atalho para trocar:", Theme.Muted);
            _swKeyBtn = new FxButton();
            _swKeyBtn.ForeColor = Theme.Gold;
            int sidx = IDX_SWAP;
            _swKeyBtn.Click += delegate { BeginCapture(sidx); };
            _swCard.Controls.Add(_swKeyBtn);

            _swStatus = NewLabel(_swCard, "", Theme.Good);
            _swStatus.TextAlign = ContentAlignment.TopLeft;
            _swStatus.Visible = false;

            LoadBrowserChoice();

            _cmbA.SelectedIndexChanged += delegate { OnBrowserPicked(true); };
            _cmbB.SelectedIndexChanged += delegate { OnBrowserPicked(false); };
            _chipA.Picked += delegate { SetActive(0); };
            _chipB.Picked += delegate { SetActive(1); };
            _swToggle.CheckedChanged += delegate
            {
                try
                {
                    _engine.SwapTo(ActiveProc());
                    _engine.Swap = _swToggle.Checked;
                    if (_swToggle.Checked)
                        ToastShow("Troca ligada: passando só o " + BrowserCatalog.ShortName(ActiveProc()), Theme.Gold);
                }
                catch (Exception ex) { ErrorLog.Write(ex); }
            };

            // Recurso aposentado: dá para minimizar o navegador e deixar a compartilhada em tela cheia.
            _swCard.Visible = false;
        }

        private void OnBrowserPicked(bool isA)
        {
            if (_swLoading) return;
            BrowserInfo ba = _cmbA.SelectedItem as BrowserInfo;
            BrowserInfo bb = _cmbB.SelectedItem as BrowserInfo;
            if (ba != null && bb != null && ba.Proc == bb.Proc)
            {
                ToastShow("Escolha 2 navegadores diferentes.", Theme.Warn);
                BrowserInfo other = null;
                foreach (BrowserInfo bi in _browsers)
                    if (bi.Proc != ba.Proc) { other = bi; break; }
                _swLoading = true;
                if (isA) SelectCombo(_cmbB, other == null ? "" : other.Proc);
                else SelectCombo(_cmbA, other == null ? "" : other.Proc);
                _swLoading = false;
                ba = _cmbA.SelectedItem as BrowserInfo;
                bb = _cmbB.SelectedItem as BrowserInfo;
            }
            _settings.BrowserA = ba == null ? "" : ba.Proc;
            _settings.BrowserB = bb == null ? "" : bb.Proc;
            _settings.Save();
            UpdateChips();
            _engine.SwapTo(ActiveProc());
        }

        // Escolhe qual navegador passa na compartilhada (0 = navegador 1, 1 = navegador 2).
        private void SetActive(int slot)
        {
            string target = slot == 1 ? _settings.BrowserB : _settings.BrowserA;
            if (string.IsNullOrEmpty(target))
            {
                ToastShow("Escolha o navegador " + (slot + 1) + " primeiro.", Theme.Warn);
                return;
            }
            _settings.ActiveSlot = slot;
            _settings.Save();
            UpdateChips();
            _engine.SwapTo(target);
            string name = BrowserCatalog.ShortName(target);
            if (_swToggle.Checked) ToastShow("Agora passando: " + name, Theme.Gold);
            else ToastShow("Navegador ativo: " + name + " (ligue a troca para valer)", Theme.Warn);
        }

        private void SwapBrowserHotkey()
        {
            if (string.IsNullOrEmpty(_settings.BrowserA) || string.IsNullOrEmpty(_settings.BrowserB))
            {
                ToastShow("Escolha os 2 navegadores primeiro.", Theme.Warn);
                return;
            }
            SetActive(_settings.ActiveSlot == 1 ? 0 : 1);
        }

        private int LayoutSwap(int left, int top, int cw, int ip)
        {
            int inner = cw - 2 * ip;
            ToggleSwitch tg = _swToggle;
            tg.Size = new Size(S(54), S(28));
            tg.Location = new Point(cw - ip - tg.Width, ip);
            int tw = cw - 3 * ip - tg.Width;
            Size ts = Measure(_swTitle.Text, _fCardTitle, tw);
            int th = Math.Max(ts.Height + S(4), tg.Height);
            _swTitle.SetBounds(ip, ip, tw, th);
            int y = ip + th + S(8);

            Size ds = Measure(_swDesc.Text, _fBody, inner);
            _swDesc.SetBounds(ip, y, inner, ds.Height + S(4));
            y += ds.Height + S(4) + S(12);

            int lblW = S(112);
            int rowH = Math.Max(_cmbA.Height, S(28));
            int cmbW = Math.Max(S(80), inner - lblW - S(6));
            _swLblA.SetBounds(ip, y, lblW, rowH);
            _cmbA.SetBounds(ip + lblW + S(6), y, cmbW, rowH);
            y += rowH + S(8);
            _swLblB.SetBounds(ip, y, lblW, rowH);
            _cmbB.SetBounds(ip + lblW + S(6), y, cmbW, rowH);
            y += rowH + S(14);

            int chH = S(88);
            _chipA.K = _k;
            _chipB.K = _k;
            if (inner >= S(380))
            {
                int half = (inner - S(12)) / 2;
                _chipA.SetBounds(ip, y, half, chH);
                _chipB.SetBounds(ip + half + S(12), y, inner - half - S(12), chH);
                y += chH + S(12);
            }
            else
            {
                _chipA.SetBounds(ip, y, inner, chH);
                y += chH + S(8);
                _chipB.SetBounds(ip, y, inner, chH);
                y += chH + S(12);
            }

            y += LayoutKeyRow(_swKeyLbl, _swKeyBtn, ip, y, inner);

            Label sl = _swStatus;
            if (sl.Text.Length > 0)
            {
                y += S(8);
                Size ss = Measure(sl.Text, _fSmall, inner);
                sl.SetBounds(ip, y, inner, ss.Height + S(4));
                sl.Visible = true;
                y += ss.Height + S(4);
            }
            else
            {
                sl.Visible = false;
            }
            y += ip;

            _swCard.Radius = S(18);
            _swCard.SetBounds(left, top, cw, y);
            return y;
        }

        private bool UpdateSwapUi()
        {
            if (_swStatus == null || _swToggle == null) return false;
            string t = "";
            Color c = Theme.Good;
            if (_swToggle.Checked)
            {
                t = "Passando só o " + BrowserCatalog.ShortName(ActiveProc()) + ". O outro navegador fica só no notebook.";
                if (_engine.SwapNote.Length > 0)
                {
                    t += " " + _engine.SwapNote;
                    c = Theme.Warn;
                }
            }
            return SetLabel(_swStatus, t, c);
        }

        // Selo "PAINEL ONLINE" do cabeçalho.
        private void UpdateBadge()
        {
            int on = 0;
            for (int i = 0; i < N; i++)
                if (_toggles[i].Checked) on++;
            if (_swToggle != null && _swToggle.Checked) on++;
            _header.BadgeText = on > 0 ? "PAINEL ONLINE · FILTRANDO A COMPARTILHADA" : "PAINEL ONLINE · TELA LIVRE";
            _header.BadgeColor = on > 0 ? Theme.Gold : Theme.Good;
            _header.RightText = on > 0 ? on + (on == 1 ? " recurso ativo" : " recursos ativos") : "nada sendo filtrado";
        }

        // Animação dos cartões (borda que brilha quando o recurso está ligado).
        private void AnimTick()
        {
            if (WindowState == FormWindowState.Minimized || !Visible || Fx.Busy) return;
            for (int i = 0; i < N; i++)
            {
                RoundedPanel c = _cards[i];
                if (_toggles[i].Checked)
                {
                    c.Glow = true;
                    c.Phase += 0.016f;
                    c.Invalidate();
                }
                else if (c.Glow)
                {
                    c.Glow = false;
                    c.Invalidate();
                }
            }
            if (_swCard != null && _swToggle != null)
            {
                if (_swToggle.Checked)
                {
                    _swCard.Glow = true;
                    _swCard.Phase += 0.016f;
                    _swCard.Invalidate();
                }
                else if (_swCard.Glow)
                {
                    _swCard.Glow = false;
                    _swCard.Invalidate();
                }
            }
            if (_btnRelease != null) _btnRelease.Pulse = AnyActive();
        }

        // ---------- rolagem própria (suave, sem piscar) ----------

        private int ViewH()
        {
            return Math.Max(10, ClientSize.Height - _header.Height - _footer.Height);
        }

        private void ApplyScroll()
        {
            int p = (int)Math.Round(_scrollPos);
            if (_canvas.Top != -p) _canvas.Top = -p;
            _smoothSet = true;
            try { _bar.Value = p; }
            finally { _smoothSet = false; }
        }

        private void ScrollBy(float delta)
        {
            float max = Math.Max(0, _contentH - ViewH());
            _scrollTarget = Math.Max(0f, Math.Min(max, _scrollTarget + delta));
            if (!_scrollTimer.Enabled)
            {
                Fx.Busy = true;
                _scrollTimer.Start();
            }
        }

        private void ScrollTick()
        {
            float d = _scrollTarget - _scrollPos;
            if (Math.Abs(d) < 0.6f)
            {
                _scrollPos = _scrollTarget;
                ApplyScroll();
                _scrollTimer.Stop();
                Fx.Busy = false;
                return;
            }
            _scrollPos += d * 0.30f;
            ApplyScroll();
        }

        // Barra arrastada com o mouse.
        private void OnBarScrolled()
        {
            if (_smoothSet) return;
            _scrollPos = _scrollTarget = _bar.Value;
            if (_canvas.Top != -_bar.Value) _canvas.Top = -_bar.Value;
            Fx.Busy = true;
            _busyTimer.Stop();
            _busyTimer.Start();
        }

        private bool DevListScrolls()
        {
            return _devList.Items.Count * S(20) > _devList.ClientSize.Height;
        }

        // Roda do mouse: rola o painel inteiro (a lista de dispositivos só rola sozinha se tiver muitos itens).
        internal bool HandleWheel(IntPtr hwnd, IntPtr wParam)
        {
            try
            {
                if (!Visible || WindowState == FormWindowState.Minimized || !_bar.Visible) return false;
                Control c = Control.FromChildHandle(hwnd);
                if (c == null || c.FindForm() != this) return false;
                if (c == _devList && DevListScrolls()) return false;
                int delta = (short)((wParam.ToInt64() >> 16) & 0xFFFF);
                ScrollBy(-(delta / 120f) * S(96));
                return true;
            }
            catch { return false; }
        }

        // ---------- rodapé: salvar tamanho da janela ----------

        private void BuildFooter()
        {
            _footer.BackColor = Theme.Bg;
            _footer.Dock = DockStyle.Bottom;
            _footer.Height = 48;
            _footer.Paint += delegate(object sender, PaintEventArgs pe)
            {
                using (Pen pen = new Pen(Color.FromArgb(120, Theme.Accent), 1f))
                    pe.Graphics.DrawLine(pen, 0, 0, _footer.Width, 0);
            };

            _btnSaveSize = MakeButton("Salvar tamanho da janela", Color.FromArgb(0, 104, 136), Color.White);
            _btnSaveSize.Click += delegate { SaveWindowSize(); };
            _footer.Controls.Add(_btnSaveSize);

            _btnDefSize = MakeButton("Tamanho padrão", Color.FromArgb(14, 26, 50), Theme.Text);
            _btnDefSize.Click += delegate { ResetWindowSize(); };
            _footer.Controls.Add(_btnDefSize);

            _lblSize.AutoSize = false;
            _lblSize.ForeColor = Theme.Muted;
            _lblSize.BackColor = Theme.Bg;
            _lblSize.TextAlign = ContentAlignment.MiddleLeft;
            _footer.Controls.Add(_lblSize);
        }

        private void LayoutFooter(int W)
        {
            Size s1 = Measure(_btnSaveSize.Text, _fBtn, 100000);
            Size s2 = Measure(_btnDefSize.Text, _fBtn, 100000);
            int bh = Math.Max(S(34), Math.Max(s1.Height, s2.Height) + S(14));
            _footer.Height = bh + S(16);
            int pad = S(20);
            int w1 = s1.Width + S(40);
            int w2 = s2.Width + S(40);
            _btnSaveSize.SetBounds(pad, S(8), w1, bh);
            _btnDefSize.SetBounds(pad + w1 + S(8), S(8), w2, bh);
            int lx = pad + w1 + S(8) + w2 + S(14);
            int lw = W - lx - pad;
            _lblSize.SetBounds(lx, S(8), Math.Max(10, lw), bh);
            _lblSize.Visible = lw > S(90);
        }

        private void UpdateSizeLabel()
        {
            string saved = _settings.WinW > 0 ? "Salvo: " + _settings.WinW + "×" + _settings.WinH : "Nenhum tamanho salvo";
            string t = saved + "   |   agora: " + ClientSize.Width + "×" + ClientSize.Height;
            if (_lblSize.Text != t) _lblSize.Text = t;
        }

        private void SaveWindowSize()
        {
            if (WindowState != FormWindowState.Normal)
            {
                ToastShow("Deixe a janela em tamanho normal (não maximizada) e clique de novo.", Theme.Warn);
                return;
            }
            _settings.WinW = ClientSize.Width;
            _settings.WinH = ClientSize.Height;
            _settings.Save();
            UpdateSizeLabel();
            ToastShow("Tamanho salvo: " + _settings.WinW + "×" + _settings.WinH + ". Vai abrir assim da próxima vez.", Theme.Good);
        }

        private void ResetWindowSize()
        {
            _settings.WinW = 0;
            _settings.WinH = 0;
            _settings.Save();
            if (WindowState == FormWindowState.Normal)
            {
                Rectangle wa = Screen.PrimaryScreen.WorkingArea;
                ClientSize = new Size(Math.Min(880, wa.Width - 60), Math.Min(604, wa.Height - 60));
            }
            UpdateSizeLabel();
            ToastShow("Voltou ao tamanho padrão.", Theme.Good);
        }

        // ---------- pergunta "está na igreja?" ao ligar o notebook (tarefa agendada) ----------

        private void SyncBootTask(bool announce)
        {
            bool want = _settings.AskAtBoot;
            System.Threading.ThreadPool.QueueUserWorkItem(delegate
            {
                bool ok = want ? BootTask.Install() : BootTask.Remove();
                if (!announce) return;
                try
                {
                    BeginInvoke(new MethodInvoker(delegate
                    {
                        if (want)
                            ToastShow(ok ? (BootTask.Elevated
                                             ? "Ao ligar o notebook, vai perguntar se você está na igreja."
                                             : "Ao ligar, vai perguntar se você está na igreja (o Windows pedirá permissão; para não pedir, deixe o programa em Arquivos de Programas).")
                                         : "Não consegui agendar a pergunta (veja erros.log).",
                                      ok ? Theme.Good : Theme.Warn);
                        else
                            ToastShow("Pergunta ao ligar o notebook desativada.", Theme.Good);
                    }));
                }
                catch { }
            });
        }

        // ---------- linhas extras do texto fixo no canto da tela ----------

        private HudLine[] HudLines()
        {
            List<HudLine> list = new List<HudLine>();
            for (int c = 0; c < CB; c++)
            {
                int mask = _settings.ComboMask[c];
                if (mask == 0) continue;
                int on = 0, total = 0;
                string names = "";
                for (int i = 0; i < N; i++)
                {
                    if ((mask & (1 << i)) == 0) continue;
                    total++;
                    if (_toggles[i].Checked) on++;
                    names += (names.Length > 0 ? " + " : "") + ShortNames[i];
                }
                string state;
                Color col;
                if (on == total) { state = "PASSANDO TELA"; col = Theme.Good; }
                else if (on == 0) { state = "PASSANDO O FUNDO"; col = Color.FromArgb(120, 200, 255); }
                else { state = "PARCIAL (" + on + " de " + total + ")"; col = Theme.Warn; }
                list.Add(new HudLine(_settings.ComboKeys[c].ToString() + "   " + names + "  →  " + state, col));
            }
            return list.ToArray();
        }

        // ---------- atalhos globais ----------

        private void RegisterAll()
        {
            for (int i = 0; i < TOTAL; i++)
            {
                if (i == IDX_SWAP) { _hkOk[i] = true; continue; }   // troca de navegador aposentada
                _hkOk[i] = Native.RegisterHotKey(Handle, i + 1, GetKey(i).Mods | Native.MOD_NOREPEAT, GetKey(i).Vk);
            }
        }

        // Se outro programa estava usando o atalho e largou, pega de volta sozinho.
        private void RetryHotkeys()
        {
            if (!IsHandleCreated) return;
            for (int i = 0; i < TOTAL; i++)
                if (i != IDX_SWAP && !_hkOk[i] && _capturing != i)
                    _hkOk[i] = Native.RegisterHotKey(Handle, i + 1, GetKey(i).Mods | Native.MOD_NOREPEAT, GetKey(i).Vk);
        }

        private void RefreshKeyLabels()
        {
            for (int i = 0; i < N; i++)
                _keyButtons[i].Text = _capturing == i
                    ? "Pressione a combinação... (Esc cancela)"
                    : _settings.Hotkeys[i].ToString() + "   (clique para mudar)";
            for (int c = 0; c < CB; c++)
                _cbKeyButtons[c].Text = _capturing == N + c
                    ? "Pressione a combinação... (Esc cancela)"
                    : _settings.ComboKeys[c].ToString() + "   (clique para mudar)" +
                      (_hkOk[N + c] ? "" : "   [em uso por outro programa]");
            _swKeyBtn.Text = _capturing == IDX_SWAP
                ? "Pressione a combinação... (Esc cancela)"
                : _settings.SwapKey.ToString() + "   (clique para mudar)" +
                  (_hkOk[IDX_SWAP] ? "" : "   [em uso por outro programa]");
            _relKeyBtn.Text = _capturing == IDX_REL
                ? "Pressione a combinação... (Esc cancela)"
                : _settings.ReleaseKey.ToString() + "   (clique para mudar)" +
                  (_hkOk[IDX_REL] ? "" : "   [em uso por outro programa]");
            if (_built) LayoutUi();
        }

        private void BeginCapture(int index)
        {
            _capturing = index;
            RefreshKeyLabels();
            Focus();
        }

        private void EndCapture()
        {
            _capturing = -1;
            RefreshKeyLabels();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (_capturing >= 0)
            {
                Keys key = keyData & Keys.KeyCode;
                if (key == Keys.Escape) { EndCapture(); return true; }
                if (key == Keys.ControlKey || key == Keys.ShiftKey || key == Keys.Menu ||
                    key == Keys.LWin || key == Keys.RWin) return true;

                uint mods = 0;
                if ((keyData & Keys.Control) != 0) mods |= Native.MOD_CONTROL;
                if ((keyData & Keys.Alt) != 0) mods |= Native.MOD_ALT;
                if ((keyData & Keys.Shift) != 0) mods |= Native.MOD_SHIFT;
                if (mods == 0)
                {
                    SetHint("Use ao menos Ctrl, Alt ou Shift junto com a tecla.", Theme.Warn);
                    return true;
                }
                AssignHotkey(_capturing, new HotkeyDef(mods, (uint)key));
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void AssignHotkey(int index, HotkeyDef def)
        {
            int id = index + 1;
            HotkeyDef old = GetKey(index);
            Native.UnregisterHotKey(Handle, id);
            if (Native.RegisterHotKey(Handle, id, def.Mods | Native.MOD_NOREPEAT, def.Vk))
            {
                SetKey(index, def);
                _hkOk[index] = true;
                _settings.Save();
                SetHint("Atalho salvo: " + def.ToString(), Theme.Good);
            }
            else
            {
                _hkOk[index] = Native.RegisterHotKey(Handle, id, old.Mods | Native.MOD_NOREPEAT, old.Vk);
                SetHint("Esse atalho já está em uso por outro programa. Escolha outro.", Theme.Warn);
            }
            _capturing = -1;
            RefreshKeyLabels();
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == Native.WM_HOTKEY)
            {
                int id = m.WParam.ToInt32();
                try
                {
                    if (id >= 1 && id <= N) _toggles[id - 1].Checked = !_toggles[id - 1].Checked;
                    else if (id > N && id <= N + CB) RunCombo(id - N - 1);
                    else if (id == IDX_REL + 1) ReleaseAll();
                }
                catch (Exception ex) { ErrorLog.Write(ex); }
                return;
            }
            if (m.Msg == 0x007E || m.Msg == 0x0219)   // WM_DISPLAYCHANGE / WM_DEVICECHANGE
                ScheduleRefresh();
            base.WndProc(ref m);
        }

        // ---------- barra de tarefas ----------

        public void OfferPinFirstRun()
        {
            if (_settings.PinOffered) return;
            _settings.PinOffered = true;
            _settings.Save();
            OfferPin();
        }

        private void OfferPin()
        {
            DialogResult r = ProtectedDialog.Show(this,
                "Quer deixar o Novo Amanhã Helper fixo na barra de tarefas?\r\n\r\n" +
                "O Windows não permite que um programa se fixe sozinho, então vou criar o atalho " +
                "no Menu Iniciar e te mostrar o último passo (2 cliques).", true);
            if (r != DialogResult.Yes) return;

            CreateStartMenuShortcut();
            ProtectedDialog.Show(this,
                "Pronto! Agora, para fixar:\r\n\r\n" +
                "1. Clique com o botão direito no ícone do Novo Amanhã Helper na barra de tarefas (embaixo).\r\n" +
                "2. Escolha \"Fixar na barra de tarefas\".", false);
        }

        private static void CreateStartMenuShortcut()
        {
            try
            {
                string exe = Application.ExecutablePath;
                string dir = Environment.GetFolderPath(Environment.SpecialFolder.Programs);
                string lnkPath = Path.Combine(dir, "Novo Amanhã Helper.lnk");
                Type t = Type.GetTypeFromProgID("WScript.Shell");
                object sh = Activator.CreateInstance(t);
                object lnk = t.InvokeMember("CreateShortcut", BindingFlags.InvokeMethod, null, sh, new object[] { lnkPath });
                Type lt = lnk.GetType();
                lt.InvokeMember("TargetPath", BindingFlags.SetProperty, null, lnk, new object[] { exe });
                lt.InvokeMember("WorkingDirectory", BindingFlags.SetProperty, null, lnk, new object[] { Path.GetDirectoryName(exe) });
                lt.InvokeMember("Description", BindingFlags.SetProperty, null, lnk, new object[] { "Novo Amanhã Helper" });
                lt.InvokeMember("Save", BindingFlags.InvokeMethod, null, lnk, null);
            }
            catch { }
        }

        // ---------- encerramento ----------

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            _guard.Stop();
            _anim.Stop();
            _refreshTimer.Stop();
            _scrollTimer.Stop();
            _busyTimer.Stop();
            Fx.Busy = false;
            try { if (_wheel != null) Application.RemoveMessageFilter(_wheel); }
            catch { }
            try
            {
                if (_hud != null) { _hud.Close(); _hud = null; }
            }
            catch { }
            try
            {
                if (_clock != null) { _clock.Dispose(); _clock = null; }
                if (_backdropSvc != null) { _backdropSvc.Dispose(); _backdropSvc = null; }
            }
            catch { }
            try
            {
                for (int i = 0; i < TOTAL; i++) Native.UnregisterHotKey(Handle, i + 1);
            }
            catch { }
            _engine.Shutdown();
            base.OnFormClosing(e);
        }
    }

    // Manda a roda do mouse para a rolagem própria do painel.
    internal class WheelFilter : IMessageFilter
    {
        private readonly MainForm _f;

        public WheelFilter(MainForm f)
        {
            _f = f;
        }

        public bool PreFilterMessage(ref Message m)
        {
            if (m.Msg != 0x020A) return false;   // WM_MOUSEWHEEL
            return _f.HandleWheel(m.HWnd, m.WParam);
        }
    }
}
