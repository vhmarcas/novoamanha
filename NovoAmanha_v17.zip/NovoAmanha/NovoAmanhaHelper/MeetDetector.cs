using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;

namespace NovoAmanha
{
    // Descobre se há uma chamada do Google Meet (ou outra) em andamento, de três jeitos ao mesmo tempo:
    //  1) título das janelas do navegador (aba ativa);
    //  2) nomes de todas as abas, mesmo em segundo plano (UI Automation, numa thread separada);
    //  3) o Windows avisa quando um programa está usando microfone, câmera ou captura de tela.
    internal static class MeetDetector
    {
        private class BrowserWin
        {
            public IntPtr H;
            public string Browser = "";
            public string Title = "";
            public string Place = "";
            public bool Main;          // janela grande (não é balãozinho/menu)
        }

        private class TabHit
        {
            public string Browser = "";
            public string Tab = "";
            public string Place = "";
            public bool Active;
        }

        private static readonly Dictionary<string, string> Browsers = new Dictionary<string, string>
        {
            { "chrome", "Chrome" }, { "msedge", "Edge" }, { "firefox", "Firefox" },
            { "brave", "Brave" }, { "opera", "Opera" }, { "vivaldi", "Vivaldi" }, { "chromium", "Chromium" }
        };

        private static readonly Regex MeetStart = new Regex(
            @"^(meet|reuni[aã]o)\s*[-\u2013\u2014]",
            RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);

        private static readonly Regex MeetCode = new Regex(
            @"\b[a-z]{3}-[a-z]{4}-[a-z]{3}\b",
            RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);

        private static readonly object Gate = new object();
        private static bool _started;
        private static List<TabHit> _tabs = new List<TabHit>();
        private static string _tabDump = "  (ainda não leu as abas)\r\n";

        public static bool IsMeetTitle(string title)
        {
            if (string.IsNullOrEmpty(title)) return false;
            string s = title.ToLowerInvariant();
            if (s.Contains("meet.google.com") || s.Contains("google meet")) return true;
            if (MeetStart.IsMatch(s)) return true;
            if ((s.Contains("meet") || s.Contains("reunião") || s.Contains("reuniao")) && MeetCode.IsMatch(s)) return true;
            return false;
        }

        // ---------- janelas de navegador ----------

        private static List<BrowserWin> BrowserWindows()
        {
            List<BrowserWin> list = new List<BrowserWin>();
            Dictionary<uint, string> procs = new Dictionary<uint, string>();

            Native.EnumWindows(delegate(IntPtr h, IntPtr lp)
            {
                if (!Native.IsWindowVisible(h)) return true;
                string title = Native.TitleOf(h);
                if (title.Length == 0) return true;

                uint pid;
                Native.GetWindowThreadProcessId(h, out pid);
                string proc;
                if (!procs.TryGetValue(pid, out proc))
                {
                    proc = "";
                    try { proc = Process.GetProcessById((int)pid).ProcessName.ToLowerInvariant(); }
                    catch { }
                    procs[pid] = proc;
                }

                string browser;
                if (!Browsers.TryGetValue(proc, out browser)) return true;

                BrowserWin w = new BrowserWin();
                w.H = h;
                w.Browser = browser;
                w.Title = title;
                RECT r;
                if (Native.GetWindowRect(h, out r))
                {
                    Point c = new Point(r.Left + r.Width / 2, r.Top + r.Height / 2);
                    w.Place = Screen.FromPoint(c).Primary ? "janela no notebook" : "janela na tela compartilhada";
                    w.Main = r.Width > 300 && r.Height > 200;
                }
                list.Add(w);
                return true;
            }, IntPtr.Zero);
            return list;
        }

        // ---------- leitura das abas (thread separada, a cada ~4 s) ----------

        private static void Start()
        {
            lock (Gate)
            {
                if (_started) return;
                _started = true;
            }
            Thread t = new Thread(new ThreadStart(UiaLoop));
            t.IsBackground = true;
            t.Name = "NovoAmanha.Abas";
            t.Start();
        }

        private static void UiaLoop()
        {
            while (true)
            {
                try { ScanTabs(); }
                catch { }
                Thread.Sleep(4000);
            }
        }

        private static void ScanTabs()
        {
            List<TabHit> hits = new List<TabHit>();
            StringBuilder dump = new StringBuilder();

            foreach (BrowserWin w in BrowserWindows())
            {
                if (!w.Main) continue;
                List<string> tabs = TabScanner.TabNames(w.H);
                dump.AppendLine("  [" + w.Browser + "] " + w.Title);
                if (tabs == null)
                {
                    dump.AppendLine("      (não consegui ler as abas desta janela)");
                    continue;
                }
                foreach (string tab in tabs)
                {
                    dump.AppendLine("      aba: " + tab);
                    if (!IsMeetTitle(tab)) continue;
                    string core = tab.Length > 25 ? tab.Substring(0, 25) : tab;
                    TabHit hit = new TabHit();
                    hit.Browser = w.Browser;
                    hit.Tab = tab;
                    hit.Place = w.Place;
                    hit.Active = w.Title.IndexOf(core, StringComparison.OrdinalIgnoreCase) >= 0;
                    hits.Add(hit);
                }
            }

            lock (Gate)
            {
                _tabs = hits;
                _tabDump = dump.Length > 0 ? dump.ToString() : "  (nenhuma janela de navegador aberta)\r\n";
            }
        }

        // ---------- uso de microfone / câmera / captura de tela (o próprio Windows registra) ----------

        private static long ToLong(object v)
        {
            try { return v == null ? 0 : Convert.ToInt64(v); }
            catch { return 0; }
        }

        private static void CheckKeys(RegistryKey parent, List<string> exes)
        {
            foreach (string name in parent.GetSubKeyNames())
            {
                if (name == "NonPackaged") continue;
                try
                {
                    using (RegistryKey k = parent.OpenSubKey(name))
                    {
                        if (k == null) continue;
                        long start = ToLong(k.GetValue("LastUsedTimeStart"));
                        long stop = ToLong(k.GetValue("LastUsedTimeStop"));
                        if (start > 0 && stop == 0)
                        {
                            int i = name.LastIndexOf('#');
                            exes.Add((i >= 0 ? name.Substring(i + 1) : name).ToLowerInvariant());
                        }
                    }
                }
                catch { }
            }
        }

        // Programas que estão usando agora aquele recurso (microphone, webcam, graphicsCaptureProgrammatic...).
        private static List<string> InUse(string capability)
        {
            List<string> exes = new List<string>();
            try
            {
                string path = @"Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\" + capability;
                using (RegistryKey root = Registry.CurrentUser.OpenSubKey(path))
                {
                    if (root == null) return exes;
                    CheckKeys(root, exes);
                    using (RegistryKey np = root.OpenSubKey("NonPackaged"))
                    {
                        if (np != null) CheckKeys(np, exes);
                    }
                }
            }
            catch { }
            return exes;
        }

        private static string Friendly(string exe)
        {
            string e = exe.ToLowerInvariant();
            if (e.EndsWith(".exe", StringComparison.Ordinal)) e = e.Substring(0, e.Length - 4);
            if (e == "chrome") return "Chrome";
            if (e == "msedge") return "Edge";
            if (e == "firefox") return "Firefox";
            if (e == "brave") return "Brave";
            if (e == "opera") return "Opera";
            if (e == "vivaldi") return "Vivaldi";
            if (e == "zoom") return "Zoom";
            if (e == "teams" || e == "ms-teams") return "Teams";
            if (e == "discord") return "Discord";
            if (e.StartsWith("msteams", StringComparison.Ordinal)) return "Teams";
            return e;
        }

        private static void AddUsage(List<DeviceInfo> list, string capability, string name, string note)
        {
            foreach (string exe in InUse(capability))
            {
                string friendly = Friendly(exe);
                bool dup = false;
                foreach (DeviceInfo x in list)
                    if (x.Name == name && x.Source == friendly) dup = true;
                if (dup) continue;

                DeviceInfo d = new DeviceInfo();
                d.Group = Devices.GroupSharing;
                d.Name = name;
                d.Source = friendly;
                d.Note = note;
                list.Add(d);
            }
        }

        private static void AddMeet(List<DeviceInfo> list, Dictionary<string, bool> seen, string browser, string note)
        {
            if (seen.ContainsKey(browser)) return;
            seen[browser] = true;
            DeviceInfo d = new DeviceInfo();
            d.Group = Devices.GroupSharing;
            d.Name = "Google Meet";
            d.Source = browser;
            d.Note = note;
            list.Add(d);
        }

        // ---------- resultado rápido (pode ser chamado a cada poucos segundos) ----------

        public static List<DeviceInfo> Detect()
        {
            Start();
            List<DeviceInfo> list = new List<DeviceInfo>();
            Dictionary<string, bool> seen = new Dictionary<string, bool>();

            foreach (BrowserWin w in BrowserWindows())
            {
                if (!IsMeetTitle(w.Title)) continue;
                AddMeet(list, seen, w.Browser, "aba ativa" + (w.Place.Length > 0 ? ", " + w.Place : ""));
            }

            List<TabHit> hits;
            lock (Gate) { hits = new List<TabHit>(_tabs); }
            foreach (TabHit h in hits)
                AddMeet(list, seen, h.Browser,
                    (h.Active ? "aba ativa" : "aba em segundo plano") + (h.Place.Length > 0 ? ", " + h.Place : ""));

            AddUsage(list, "microphone", "Microfone em uso", "provável chamada em andamento");
            AddUsage(list, "webcam", "Câmera em uso", "provável chamada em andamento");
            AddUsage(list, "graphicsCaptureProgrammatic", "Compartilhando a tela", "captura de tela em uso");
            AddUsage(list, "graphicsCaptureWithoutBorder", "Compartilhando a tela", "captura de tela em uso");
            return list;
        }

        // ---------- texto para o "Copiar diagnóstico" ----------

        private static string JoinOrNone(List<string> items)
        {
            return items.Count == 0 ? "nenhum" : string.Join(", ", items.ToArray());
        }

        public static string Dump()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Detecção do Meet:");
            sb.AppendLine("  Leitura de abas (UI Automation): " + (TabScanner.Available ? "disponível" : "NÃO disponível neste build"));
            sb.AppendLine("  Janelas de navegador agora:");
            foreach (BrowserWin w in BrowserWindows())
                sb.AppendLine("    [" + w.Browser + "] " + w.Title + (w.Place.Length > 0 ? "  (" + w.Place + ")" : ""));
            sb.AppendLine("  Abas lidas na última varredura:");
            lock (Gate) { sb.Append(_tabDump); }
            sb.AppendLine("  Microfone em uso por: " + JoinOrNone(InUse("microphone")));
            sb.AppendLine("  Câmera em uso por: " + JoinOrNone(InUse("webcam")));
            sb.AppendLine("  Captura de tela em uso por: " +
                JoinOrNone(InUse("graphicsCaptureProgrammatic")) + " / " + JoinOrNone(InUse("graphicsCaptureWithoutBorder")));
            return sb.ToString();
        }
    }
}
