using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace NovoAmanha
{
    // ---------------------------------------------------------------------------------------------
    // Fundo personalizado: imagem/cor mostrada na tela compartilhada POR CIMA do papel de parede e dos
    // ícones da área de trabalho, mas por baixo de qualquer janela.
    // ---------------------------------------------------------------------------------------------
    internal static class BackdropStore
    {
        public static bool On;
        public static Color Bg = Color.Black;
        public static int Fit;          // 0 preencher (corta), 1 mostrar inteira, 2 esticar
        public static int Stamp;        // muda sempre que algo do fundo muda (as capas se redesenham)
        private static Bitmap _img;
        private static string _path = "";

        public static void Apply(Settings s)
        {
            On = s.BackOn;
            Bg = Color.FromArgb(255, Color.FromArgb(s.BackColor));
            Fit = s.BackFit;
            string p = s.BackPath ?? "";
            if (p != _path)
            {
                _path = p;
                if (_img != null) { _img.Dispose(); _img = null; }
                if (p.Length > 0)
                {
                    try
                    {
                        // lê pelo memória: não trava o arquivo no disco
                        byte[] data = File.ReadAllBytes(p);
                        using (MemoryStream ms = new MemoryStream(data))
                        using (Image im = Image.FromStream(ms))
                            _img = new Bitmap(im);
                    }
                    catch (Exception ex) { ErrorLog.Write(ex); _img = null; }
                }
            }
            Stamp++;
        }

        public static bool HasImage { get { return _img != null; } }

        public static void Draw(Graphics g, Rectangle r)
        {
            g.Clear(Bg);
            if (_img == null || r.Width < 2 || r.Height < 2) return;
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            g.PixelOffsetMode = PixelOffsetMode.HighQuality;
            if (Fit == 2)
            {
                g.DrawImage(_img, r);
                return;
            }
            float sx = r.Width / (float)_img.Width;
            float sy = r.Height / (float)_img.Height;
            if (Fit == 1)
            {
                float sc = Math.Min(sx, sy);
                int w = (int)(_img.Width * sc);
                int h = (int)(_img.Height * sc);
                g.DrawImage(_img, new Rectangle(r.X + (r.Width - w) / 2, r.Y + (r.Height - h) / 2, w, h));
                return;
            }
            // preencher: cobre a tela toda e corta o que sobra
            float scale = Math.Max(sx, sy);
            float cw = r.Width / scale;
            float ch = r.Height / scale;
            RectangleF src = new RectangleF((_img.Width - cw) / 2f, (_img.Height - ch) / 2f, cw, ch);
            g.DrawImage(_img, r, src.X, src.Y, src.Width, src.Height, GraphicsUnit.Pixel);
        }
    }

    // Põe uma janela logo ACIMA da área de trabalho (papel de parede + ícones) e abaixo de todo o resto.
    internal static class DesktopZ
    {
        private static IntPtr Anchor()
        {
            IntPtr found = IntPtr.Zero;
            Native.EnumWindows(delegate(IntPtr h, IntPtr lp)
            {
                string cls = Native.ClassOf(h);
                if (cls != "Progman" && cls != "WorkerW") return true;
                if (Native.FindWindowEx(h, IntPtr.Zero, "SHELLDLL_DefView", null) == IntPtr.Zero) return true;
                found = h;
                return false;
            }, IntPtr.Zero);
            return found;
        }

        public static void Place(IntPtr h)
        {
            IntPtr a = Anchor();
            Native.SetWindowPos(h, a != IntPtr.Zero ? a : Native.HWND_BOTTOM, 0, 0, 0, 0,
                Native.SWP_NOMOVE | Native.SWP_NOSIZE | Native.SWP_NOACTIVATE);
        }
    }

    // Mantém o fundo personalizado na(s) tela(s) compartilhada(s) quando NENHUM recurso do painel está ativo
    // (com recurso ativo, as capas do próprio painel já mostram o fundo).
    //
    // O fundo SUBSTITUI o papel de parede: fica logo acima dele (e dos ícones da área de trabalho) e abaixo
    // de qualquer janela. Nunca é "sempre por cima". A barra de tarefas da tela compartilhada fica escondida
    // enquanto o fundo estiver ligado, e o relógio (ClockService) fica acima de tudo.
    internal class BackdropService : IDisposable
    {
        private readonly Engine _engine;
        private readonly Timer _t = new Timer();
        private readonly Timer _tb = new Timer();
        private readonly Dictionary<string, CoverForm> _forms = new Dictionary<string, CoverForm>();
        private bool _tbHidden;   // este serviço escondeu as barras de tarefa das telas compartilhadas

        public BackdropService(Engine engine)
        {
            _engine = engine;
            _t.Interval = 500;
            _t.Tick += delegate { Tick(); };
            _tb.Interval = 120;   // o Windows tenta mostrar a barra de volta: escondemos de novo na hora
            _tb.Tick += delegate { FastHideTaskbars(); };
            _tb.Start();
        }

        public void Start()
        {
            _t.Start();
            Tick();
        }

        // Chamado quando o fundo ou as telas mudam.
        public void Poke()
        {
            Tick();
        }

        // Rápido e barato: só esconde a barra de tarefas das telas compartilhadas, se o fundo (ou uma capa do painel) está ligado.
        private void FastHideTaskbars()
        {
            try
            {
                if (!BackdropStore.On && !_engine.HasCovers) return;
                List<Screen> shared = Engine.SharedScreens();
                if (shared.Count == 0) return;
                if (Guard.HideTaskbarsOn(shared, null)) _tbHidden = true;
            }
            catch { }
        }

        private void Clear()
        {
            foreach (CoverForm f in _forms.Values)
            {
                try { f.Close(); f.Dispose(); }
                catch { }
            }
            _forms.Clear();
        }

        private void Tick()
        {
            try
            {
                bool engineHas = _engine.HasCovers;
                if (!BackdropStore.On || engineHas)
                {
                    Clear();
                    if (_tbHidden && !engineHas && !BackdropStore.On) Guard.SweepTaskbars();
                    _tbHidden = false;
                    return;
                }

                List<Screen> shared = Engine.SharedScreens();
                if (shared.Count == 0)
                {
                    Clear();
                    return;
                }

                bool bad = _forms.Count != shared.Count;
                foreach (Screen s in shared)
                    if (!_forms.ContainsKey(s.DeviceName)) bad = true;
                foreach (CoverForm cf in _forms.Values)
                    if (cf.IsDisposed || !cf.Visible) bad = true;

                if (bad)
                {
                    Clear();
                    foreach (Screen s in shared)
                    {
                        CoverForm nf = new CoverForm();
                        nf.Bounds = s.Bounds;
                        nf.TopMost = false;
                        nf.UpdateBackdrop(true);
                        nf.Show();
                        _forms[s.DeviceName] = nf;
                    }
                }

                foreach (Screen s in shared)
                {
                    CoverForm f;
                    if (!_forms.TryGetValue(s.DeviceName, out f)) continue;
                    if (f.Bounds != s.Bounds) f.Bounds = s.Bounds;
                    f.UpdateBackdrop(true);
                    if (f.TopMost) f.TopMost = false;
                    DesktopZ.Place(f.Handle);   // logo acima do papel de parede e dos ícones, abaixo de qualquer janela
                }

                if (Guard.HideTaskbarsOn(shared, null)) _tbHidden = true;
            }
            catch (Exception ex) { ErrorLog.Write(ex); }
        }

        public void Dispose()
        {
            _t.Stop();
            _t.Dispose();
            _tb.Stop();
            _tb.Dispose();
            Clear();
            if (_tbHidden) { Guard.SweepTaskbars(); _tbHidden = false; }
        }
    }

    // ---------------------------------------------------------------------------------------------
    // Relógio: janela transparente com fundo de opacidade ajustável (pixel por pixel). O clique atravessa.
    // ---------------------------------------------------------------------------------------------
    internal class ClockOverlay : Form
    {
        [StructLayout(LayoutKind.Sequential)]
        private struct PT { public int X, Y; }

        [StructLayout(LayoutKind.Sequential)]
        private struct SZ { public int W, H; }

        [StructLayout(LayoutKind.Sequential)]
        private struct BLEND { public byte Op, Flags, Alpha, Format; }

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool UpdateLayeredWindow(IntPtr hwnd, IntPtr hdcDst, ref PT pptDst, ref SZ psize,
            IntPtr hdcSrc, ref PT pptSrc, int crKey, ref BLEND pblend, int dwFlags);

        [DllImport("user32.dll")] private static extern IntPtr GetDC(IntPtr hWnd);
        [DllImport("user32.dll")] private static extern int ReleaseDC(IntPtr hWnd, IntPtr hDC);
        [DllImport("gdi32.dll")] private static extern IntPtr CreateCompatibleDC(IntPtr hdc);
        [DllImport("gdi32.dll")] private static extern bool DeleteDC(IntPtr hdc);
        [DllImport("gdi32.dll")] private static extern IntPtr SelectObject(IntPtr hdc, IntPtr obj);
        [DllImport("gdi32.dll")] private static extern bool DeleteObject(IntPtr obj);

        public string LastKey = "";

        public ClockOverlay()
        {
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.Manual;
            ShowInTaskbar = false;
            TopMost = true;
            Text = "NovoAmanha.Clock";
            Size = new Size(10, 10);
        }

        protected override bool ShowWithoutActivation { get { return true; } }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= Native.WS_EX_NOACTIVATE | Native.WS_EX_TOOLWINDOW | Native.WS_EX_LAYERED |
                              Native.WS_EX_TRANSPARENT | Native.WS_EX_TOPMOST;
                return cp;
            }
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x0084) { m.Result = (IntPtr)(-1); return; }   // WM_NCHITTEST -> o clique atravessa
            if (m.Msg == 0x0021) { m.Result = (IntPtr)3; return; }      // WM_MOUSEACTIVATE -> nunca rouba o foco
            base.WndProc(ref m);
        }

        // Só mexe na ordem das janelas quando alguma outra está acima do relógio (evita trabalho e piscadas).
        // Os relógios das outras telas não contam: cada um fica no topo da sua tela.
        public void KeepOnTop()
        {
            if (!IsHandleCreated) return;
            IntPtr[] mine = Engine.OverlayHandles;
            IntPtr above = Native.GetWindow(Handle, 3);   // GW_HWNDPREV: a janela imediatamente acima
            int guard = 0;
            while (above != IntPtr.Zero && guard++ < 100 && mine != null && Array.IndexOf(mine, above) >= 0)
                above = Native.GetWindow(above, 3);
            if (above == IntPtr.Zero) return;   // já é a mais alta
            Native.SetWindowPos(Handle, Native.HWND_TOPMOST, 0, 0, 0, 0,
                Native.SWP_NOMOVE | Native.SWP_NOSIZE | Native.SWP_NOACTIVATE);
        }

        // Desenha o relógio e posiciona na tela dada.
        public void Render(Settings s, Rectangle scr, string text)
        {
            if (!IsHandleCreated) Show();

            float px = Math.Max(20, Math.Min(500, s.ClockSize));
            int alpha = (int)Math.Round(Math.Max(0, Math.Min(100, s.ClockBgAlpha)) * 2.55);
            Color fore = Color.FromArgb(255, Color.FromArgb(s.ClockColor));
            Color back = Color.FromArgb(alpha, Color.FromArgb(s.ClockBg));

            StringFormat sf = new StringFormat(StringFormat.GenericTypographic);
            sf.FormatFlags |= StringFormatFlags.NoWrap | StringFormatFlags.MeasureTrailingSpaces;
            sf.Alignment = StringAlignment.Center;
            sf.LineAlignment = StringAlignment.Center;

            using (Font f = new Font(Fx.TechName(), px, FontStyle.Bold, GraphicsUnit.Pixel))
            {
                // largura medida com todos os dígitos iguais: o relógio não "dança" de lado a cada segundo
                string template = text;
                char[] arr = template.ToCharArray();
                for (int i = 0; i < arr.Length; i++) if (arr[i] >= '0' && arr[i] <= '9') arr[i] = '0';
                template = new string(arr);

                SizeF m;
                using (Bitmap probe = new Bitmap(1, 1))
                using (Graphics pg = Graphics.FromImage(probe))
                    m = pg.MeasureString(template, f, 100000, sf);

                int padX = (int)(px * 0.30f);
                int padY = (int)(px * 0.16f);
                int w = Math.Min(scr.Width, (int)Math.Ceiling(m.Width) + padX * 2);
                int h = Math.Min(scr.Height, (int)Math.Ceiling(m.Height) + padY * 2);
                if (w < 4) w = 4;
                if (h < 4) h = 4;

                using (Bitmap bmp = new Bitmap(w, h, PixelFormat.Format32bppPArgb))
                {
                    using (Graphics g = Graphics.FromImage(bmp))
                    {
                        g.Clear(Color.Transparent);
                        g.SmoothingMode = SmoothingMode.AntiAlias;
                        g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
                        if (alpha > 0)
                        {
                            int rad = Math.Max(4, (int)(Math.Min(w, h) * 0.20f));
                            using (GraphicsPath gp = RoundRect(new Rectangle(0, 0, w, h), rad))
                            using (SolidBrush bb = new SolidBrush(back))
                                g.FillPath(bb, gp);
                        }
                        using (SolidBrush fb = new SolidBrush(fore))
                            g.DrawString(text, f, fb, new RectangleF(0, 0, w, h), sf);
                    }

                    int margin = (int)(Math.Min(scr.Width, scr.Height) * 0.03);
                    int col = s.ClockPos % 3;
                    int row = s.ClockPos / 3;
                    int x = col == 0 ? scr.Left + margin : col == 1 ? scr.Left + (scr.Width - w) / 2 : scr.Right - margin - w;
                    int y = row == 0 ? scr.Top + margin : row == 1 ? scr.Top + (scr.Height - h) / 2 : scr.Bottom - margin - h;

                    Push(bmp, x, y, w, h);
                }
            }
            sf.Dispose();
        }

        private void Push(Bitmap bmp, int x, int y, int w, int h)
        {
            IntPtr screenDc = GetDC(IntPtr.Zero);
            IntPtr memDc = CreateCompatibleDC(screenDc);
            IntPtr hBmp = IntPtr.Zero;
            IntPtr old = IntPtr.Zero;
            try
            {
                hBmp = bmp.GetHbitmap(Color.FromArgb(0));
                old = SelectObject(memDc, hBmp);
                SZ sz = new SZ();
                sz.W = w;
                sz.H = h;
                PT src = new PT();
                PT dst = new PT();
                dst.X = x;
                dst.Y = y;
                BLEND bl = new BLEND();
                bl.Op = 0;          // AC_SRC_OVER
                bl.Flags = 0;
                bl.Alpha = 255;
                bl.Format = 1;      // AC_SRC_ALPHA
                UpdateLayeredWindow(Handle, screenDc, ref dst, ref sz, memDc, ref src, 0, ref bl, 2);
            }
            finally
            {
                if (old != IntPtr.Zero) SelectObject(memDc, old);
                if (hBmp != IntPtr.Zero) DeleteObject(hBmp);
                DeleteDC(memDc);
                ReleaseDC(IntPtr.Zero, screenDc);
            }
        }

        private static GraphicsPath RoundRect(Rectangle r, int d)
        {
            GraphicsPath p = new GraphicsPath();
            int dd = Math.Max(2, Math.Min(d * 2, Math.Min(r.Width, r.Height)));
            p.AddArc(r.X, r.Y, dd, dd, 180, 90);
            p.AddArc(r.Right - dd, r.Y, dd, dd, 270, 90);
            p.AddArc(r.Right - dd, r.Bottom - dd, dd, dd, 0, 90);
            p.AddArc(r.X, r.Bottom - dd, dd, dd, 90, 90);
            p.CloseFigure();
            return p;
        }
    }

    // Cuida dos relógios: um por tela escolhida; as outras telas ficam de fora.
    internal class ClockService : IDisposable
    {
        private readonly Settings _s;
        private readonly Timer _t = new Timer();
        private readonly Dictionary<string, ClockOverlay> _w = new Dictionary<string, ClockOverlay>();
        private int _force;

        public ClockService(Settings s)
        {
            _s = s;
            _t.Interval = 100;   // verifica a ordem das janelas 10x por segundo: o relógio fica sempre acima de tudo
            _t.Tick += delegate { Tick(); };
        }

        public void Start()
        {
            _t.Start();
            Tick();
        }

        // Chamado quando qualquer opção do relógio muda: redesenha na hora.
        public void Apply()
        {
            _force++;
            Tick();
        }

        public static string Format(Settings s, DateTime now)
        {
            List<string> parts = new List<string>();
            if (s.ClockH) parts.Add(now.Hour.ToString("00"));
            if (s.ClockM) parts.Add(now.Minute.ToString("00"));
            if (s.ClockS) parts.Add(now.Second.ToString("00"));
            return parts.Count == 0 ? "--" : string.Join(":", parts.ToArray());
        }

        private bool Wanted(string deviceName)
        {
            string list = _s.ClockScreens ?? "";
            if (list.Length == 0) return false;
            foreach (string n in list.Split('|'))
                if (n.Length > 0 && n == deviceName) return true;
            return false;
        }

        private void Clear()
        {
            foreach (ClockOverlay o in _w.Values)
            {
                try { o.Close(); o.Dispose(); }
                catch { }
            }
            _w.Clear();
            Engine.OverlayHandles = new IntPtr[0];
        }

        private void Tick()
        {
            try
            {
                if (!_s.ClockOn)
                {
                    if (_w.Count > 0) Clear();
                    return;
                }

                string text = Format(_s, DateTime.Now);
                string sig = text + "|" + _s.ClockColor + "|" + _s.ClockBg + "|" + _s.ClockBgAlpha + "|" +
                             _s.ClockSize + "|" + _s.ClockPos + "|" + _force;

                List<string> keep = new List<string>();
                List<IntPtr> handles = new List<IntPtr>();
                foreach (Screen sc in Screen.AllScreens)
                {
                    if (sc.Primary || !Wanted(sc.DeviceName)) continue;
                    keep.Add(sc.DeviceName);

                    ClockOverlay o;
                    if (!_w.TryGetValue(sc.DeviceName, out o) || o.IsDisposed)
                    {
                        o = new ClockOverlay();
                        _w[sc.DeviceName] = o;
                    }
                    string key = sig + "|" + sc.Bounds.ToString();
                    if (o.LastKey != key || !o.Visible)
                    {
                        o.Render(_s, sc.Bounds, text);
                        o.LastKey = key;
                    }
                    o.KeepOnTop();
                    handles.Add(o.Handle);
                }

                List<string> drop = new List<string>();
                foreach (string k in _w.Keys)
                    if (!keep.Contains(k)) drop.Add(k);
                foreach (string k in drop)
                {
                    try { _w[k].Close(); _w[k].Dispose(); }
                    catch { }
                    _w.Remove(k);
                }
                Engine.OverlayHandles = handles.ToArray();
            }
            catch (Exception ex) { ErrorLog.Write(ex); }
        }

        public void Dispose()
        {
            _t.Stop();
            _t.Dispose();
            Clear();
        }
    }
}
