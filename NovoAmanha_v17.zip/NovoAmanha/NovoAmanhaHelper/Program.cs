using System;
using System.Diagnostics;
using System.Security.Principal;
using System.Threading;
using System.Windows.Forms;

namespace NovoAmanha
{
    internal static class Program
    {
        private static bool IsAdmin()
        {
            try
            {
                using (WindowsIdentity id = WindowsIdentity.GetCurrent())
                    return new WindowsPrincipal(id).IsInRole(WindowsBuiltInRole.Administrator);
            }
            catch { return false; }
        }

        // true se o painel já está rodando (o Mutex de instância única existe).
        private static bool PanelRunning()
        {
            try
            {
                Mutex m = Mutex.OpenExisting("NovoAmanhaHelper.SingleInstance");
                m.Close();
                return true;
            }
            catch (WaitHandleCannotBeOpenedException) { return false; }
            catch (UnauthorizedAccessException) { return true; }
            catch { return false; }
        }

        [STAThread]
        private static void Main(string[] args)
        {
            // Modo vigia: processo escondido que espera o painel terminar e então arruma a tela.
            if (args != null && args.Length >= 2 && args[0] == "--guard")
            {
                Guard.Run(args[1]);
                return;
            }

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);

            // Modo "ao ligar o notebook": pergunta se está na igreja; só abre o painel se responder SIM.
            if (args != null && args.Length >= 1 && args[0] == "--boot")
            {
                if (PanelRunning()) return;
                if (!Settings.Load().AskAtBoot) return;
                if (!BootPrompt.Ask()) return;
            }

            // O programa exige permissão total (administrador) para achar as conexões e mexer em qualquer janela.
            if (!IsAdmin())
            {
                try
                {
                    ProcessStartInfo psi = new ProcessStartInfo(Application.ExecutablePath);
                    psi.UseShellExecute = true;
                    psi.Verb = "runas";
                    Process.Start(psi);
                }
                catch
                {
                    ProtectedDialog.Show(null,
                        "O Novo Amanhã Helper só funciona com permissão de administrador.\r\n\r\n" +
                        "Abra de novo e responda \"Sim\" ao pedido do Windows.", false);
                }
                return;
            }

            bool created;
            using (Mutex mutex = new Mutex(true, "NovoAmanhaHelper.SingleInstance", out created))
            {
                if (!created)
                {
                    ProtectedDialog.Show(null, "O Novo Amanhã Helper já está aberto.", false);
                    return;
                }

                // Sobra de uma vez anterior que fechou à força: mostra de novo as barras de tarefas
                // e devolve o som dos navegadores que ficaram silenciados.
                Guard.SweepTaskbars();
                try { BrowserAudio.RestoreSaved(Engine.BrowserProcs); }
                catch { }

                Settings settings = Settings.Load();
                Engine engine = new Engine();
                Guard.StartWatchdog();

                // Erro na interface: registra e continua. Se for grave, devolve tudo ao normal.
                Application.ThreadException += delegate(object sender, ThreadExceptionEventArgs ev)
                {
                    Guard.OnUiException(engine, ev.Exception);
                };
                AppDomain.CurrentDomain.UnhandledException += delegate(object sender, UnhandledExceptionEventArgs ev)
                {
                    ErrorLog.Write(ev.ExceptionObject as Exception);
                    try { engine.Shutdown(); } catch { }
                    Guard.SweepTaskbars();
                };
                AppDomain.CurrentDomain.ProcessExit += delegate
                {
                    try { engine.Shutdown(); } catch { }
                    Guard.SweepTaskbars();
                };

                MainForm form = new MainForm(settings, engine);
                form.Shown += delegate { form.OfferPinFirstRun(); };
                Application.Run(form);
                engine.Dispose();
                Guard.SweepTaskbars();
            }
        }
    }
}
