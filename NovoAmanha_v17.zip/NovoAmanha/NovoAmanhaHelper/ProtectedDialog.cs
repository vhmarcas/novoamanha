using System;
using System.Drawing;
using System.Windows.Forms;

namespace NovoAmanha
{
    // Caixa de mensagem própria: ao contrário do MessageBox do Windows,
    // ela também fica invisível em qualquer compartilhamento de tela
    // e sempre abre na tela principal.
    internal class ProtectedDialog : Form
    {
        public static DialogResult Show(IWin32Window owner, string text, bool yesNo)
        {
            using (ProtectedDialog d = new ProtectedDialog(text, yesNo))
            {
                return owner == null ? d.ShowDialog() : d.ShowDialog(owner);
            }
        }

        private ProtectedDialog(string text, bool yesNo)
        {
            Text = "Novo Amanhã Helper";
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = false;
            AutoScaleMode = AutoScaleMode.None;
            StartPosition = FormStartPosition.Manual;
            BackColor = Theme.Bg;
            Font = new Font("Segoe UI", 9.5f);

            int pad = 20;
            int textW = 400;
            Size ts = TextRenderer.MeasureText(text, Font, new Size(textW, 0),
                TextFormatFlags.WordBreak | TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix);

            Label l = new Label();
            l.AutoSize = false;
            l.ForeColor = Theme.Text;
            l.BackColor = Theme.Bg;
            l.Text = text;
            l.SetBounds(pad, pad, textW, ts.Height + 6);
            Controls.Add(l);

            int bh = 36, bw = 110;
            int by = pad + ts.Height + 6 + pad;
            ClientSize = new Size(textW + 2 * pad, by + bh + pad);

            if (yesNo)
            {
                Button no = MakeButton("Não", DialogResult.No, Theme.Card);
                no.SetBounds(ClientSize.Width - pad - bw, by, bw, bh);
                Button yes = MakeButton("Sim", DialogResult.Yes, Theme.Accent);
                yes.SetBounds(no.Left - 10 - bw, by, bw, bh);
                Controls.Add(no);
                Controls.Add(yes);
                AcceptButton = yes;
                CancelButton = no;
            }
            else
            {
                Button ok = MakeButton("OK", DialogResult.OK, Theme.Accent);
                ok.SetBounds(ClientSize.Width - pad - bw, by, bw, bh);
                Controls.Add(ok);
                AcceptButton = ok;
                CancelButton = ok;
            }

            Rectangle wa = Screen.PrimaryScreen.WorkingArea;
            Location = new Point(wa.Left + (wa.Width - Width) / 2, wa.Top + (wa.Height - Height) / 2);
        }

        private static Button MakeButton(string text, DialogResult result, Color back)
        {
            Button b = new Button();
            b.Text = text;
            b.DialogResult = result;
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderSize = 0;
            b.BackColor = back;
            b.ForeColor = back == Theme.Accent ? Color.White : Theme.Text;
            b.Cursor = Cursors.Hand;
            b.Font = new Font("Segoe UI Semibold", 9.5f);
            return b;
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            if (!Native.SetWindowDisplayAffinity(Handle, Native.WDA_EXCLUDEFROMCAPTURE))
                Native.SetWindowDisplayAffinity(Handle, Native.WDA_MONITOR);
        }
    }
}
