using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace NovoAmanha
{
    internal struct HotkeyDef
    {
        public uint Mods;
        public uint Vk;

        public HotkeyDef(uint mods, uint vk)
        {
            Mods = mods;
            Vk = vk;
        }

        public override string ToString()
        {
            string s = "";
            if ((Mods & Native.MOD_CONTROL) != 0) s += "Ctrl+";
            if ((Mods & Native.MOD_ALT) != 0) s += "Alt+";
            if ((Mods & Native.MOD_SHIFT) != 0) s += "Shift+";
            if ((Mods & Native.MOD_WIN) != 0) s += "Win+";
            return s + ((Keys)Vk).ToString();
        }
    }

    internal class Settings
    {
        public const int Count = 4; // 0 navegadores, 1 tela preta, 2 sem barras, 3 YouTube

        public HotkeyDef[] Hotkeys = new HotkeyDef[]
        {
            new HotkeyDef(Native.MOD_CONTROL | Native.MOD_ALT, (uint)Keys.B),
            new HotkeyDef(Native.MOD_CONTROL | Native.MOD_ALT, (uint)Keys.P),
            new HotkeyDef(Native.MOD_CONTROL | Native.MOD_ALT, (uint)Keys.F),
            new HotkeyDef(Native.MOD_CONTROL | Native.MOD_ALT, (uint)Keys.Y)
        };
        public const int Combos = 2;   // atalhos combinados (ligam/desligam vários recursos de uma vez)

        // bit i = recurso i (0 navegadores, 1 tela preta, 2 sem barras, 3 YouTube)
        public int[] ComboMask = new int[] { 2 | 8, 0 };
        public HotkeyDef[] ComboKeys = new HotkeyDef[]
        {
            new HotkeyDef(Native.MOD_CONTROL | Native.MOD_ALT, (uint)Keys.K),
            new HotkeyDef(Native.MOD_CONTROL | Native.MOD_ALT, (uint)Keys.J)
        };
        // Troca de navegador (2 navegadores; só o "ativo" aparece na compartilhada)
        public string BrowserA = "";
        public string BrowserB = "";
        public int ActiveSlot = 0;   // 0 = navegador 1, 1 = navegador 2
        public HotkeyDef SwapKey = new HotkeyDef(Native.MOD_CONTROL | Native.MOD_ALT, (uint)Keys.A);
        public HotkeyDef ReleaseKey = new HotkeyDef(Native.MOD_CONTROL | Native.MOD_ALT, (uint)Keys.D0);
        public bool HudOn = true;
        public bool PinOffered = false;
        public bool AskAtBoot = true;   // ao ligar o notebook, perguntar se está na igreja
        public string FreeApps = "holyrics";   // programas liberados: aparecem livremente na compartilhada (nomes separados por vírgula)
        public int WinW = 0;            // tamanho salvo da janela (0 = padrão)

        // Relógio na tela compartilhada
        public bool ClockOn = false;
        public bool ClockH = true, ClockM = true, ClockS = true;   // o que aparece: horas, minutos, segundos
        public int ClockColor = unchecked((int)0xFFFFFFFF);        // cor dos números (ARGB)
        public int ClockBg = unchecked((int)0xFF000000);           // cor do fundo do relógio (preto)
        public int ClockBgAlpha = 70;                              // opacidade do fundo, 0 a 100
        public int ClockSize = 96;                                 // tamanho dos números em pixels
        public int ClockPos = 2;                                   // 0..8 = linha*3 + coluna (2 = canto superior direito)
        public string ClockScreens = "";                           // telas onde aparece (nomes do Windows separados por |)

        // Fundo personalizado por cima do papel de parede e dos ícones
        public bool BackOn = false;
        public string BackPath = "";
        public int BackColor = unchecked((int)0xFF000000);
        public int BackFit = 0;                                    // 0 preencher, 1 mostrar inteira, 2 esticar
        public int WinH = 0;

        private static string FilePath()
        {
            string dir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "NovoAmanhaHelper");
            Directory.CreateDirectory(dir);
            return Path.Combine(dir, "config.ini");
        }

        public static Settings Load()
        {
            Settings s = new Settings();
            try
            {
                string path = FilePath();
                if (!File.Exists(path)) return s;
                Dictionary<string, string> kv = new Dictionary<string, string>();
                foreach (string line in File.ReadAllLines(path))
                {
                    int i = line.IndexOf('=');
                    if (i > 0) kv[line.Substring(0, i).Trim()] = line.Substring(i + 1).Trim();
                }
                for (int n = 0; n < Count; n++)
                {
                    string v;
                    uint a, b;
                    if (kv.TryGetValue("hk" + n + "_mods", out v) && uint.TryParse(v, out a) &&
                        kv.TryGetValue("hk" + n + "_vk", out v) && uint.TryParse(v, out b) && b != 0)
                        s.Hotkeys[n] = new HotkeyDef(a, b);
                }
                for (int n = 0; n < Combos; n++)
                {
                    string v;
                    uint a, b;
                    int m;
                    if (kv.TryGetValue("cb" + n + "_mask", out v) && int.TryParse(v, out m)) s.ComboMask[n] = m & 15;
                    if (kv.TryGetValue("cb" + n + "_mods", out v) && uint.TryParse(v, out a) &&
                        kv.TryGetValue("cb" + n + "_vk", out v) && uint.TryParse(v, out b) && b != 0)
                        s.ComboKeys[n] = new HotkeyDef(a, b);
                }
                string sv;
                int slot;
                uint sm, sk;
                if (kv.TryGetValue("bro_a", out sv)) s.BrowserA = sv;
                if (kv.TryGetValue("bro_b", out sv)) s.BrowserB = sv;
                if (kv.TryGetValue("bro_slot", out sv) && int.TryParse(sv, out slot)) s.ActiveSlot = slot == 1 ? 1 : 0;
                if (kv.TryGetValue("swap_mods", out sv) && uint.TryParse(sv, out sm) &&
                    kv.TryGetValue("swap_vk", out sv) && uint.TryParse(sv, out sk) && sk != 0)
                    s.SwapKey = new HotkeyDef(sm, sk);
                if (kv.TryGetValue("rel_mods", out sv) && uint.TryParse(sv, out sm) &&
                    kv.TryGetValue("rel_vk", out sv) && uint.TryParse(sv, out sk) && sk != 0)
                    s.ReleaseKey = new HotkeyDef(sm, sk);
                if (kv.TryGetValue("hud_on", out sv)) s.HudOn = sv != "0";
                if (kv.TryGetValue("free_apps", out sv)) s.FreeApps = sv;
                if (kv.TryGetValue("ask_boot", out sv)) s.AskAtBoot = sv != "0";
                int wv;
                if (kv.TryGetValue("win_w", out sv) && int.TryParse(sv, out wv)) s.WinW = wv;
                if (kv.TryGetValue("win_h", out sv) && int.TryParse(sv, out wv)) s.WinH = wv;
                int iv;
                if (kv.TryGetValue("clk_on", out sv)) s.ClockOn = sv == "1";
                if (kv.TryGetValue("clk_h", out sv)) s.ClockH = sv != "0";
                if (kv.TryGetValue("clk_m", out sv)) s.ClockM = sv != "0";
                if (kv.TryGetValue("clk_s", out sv)) s.ClockS = sv != "0";
                if (kv.TryGetValue("clk_color", out sv) && int.TryParse(sv, out iv)) s.ClockColor = iv;
                if (kv.TryGetValue("clk_bg", out sv) && int.TryParse(sv, out iv)) s.ClockBg = iv;
                if (kv.TryGetValue("clk_alpha", out sv) && int.TryParse(sv, out iv)) s.ClockBgAlpha = Math.Max(0, Math.Min(100, iv));
                if (kv.TryGetValue("clk_size", out sv) && int.TryParse(sv, out iv)) s.ClockSize = Math.Max(20, Math.Min(500, iv));
                if (kv.TryGetValue("clk_pos", out sv) && int.TryParse(sv, out iv)) s.ClockPos = Math.Max(0, Math.Min(8, iv));
                if (kv.TryGetValue("clk_screens", out sv)) s.ClockScreens = sv;
                if (kv.TryGetValue("back_on", out sv)) s.BackOn = sv == "1";
                if (kv.TryGetValue("back_path", out sv)) s.BackPath = sv;
                if (kv.TryGetValue("back_color", out sv) && int.TryParse(sv, out iv)) s.BackColor = iv;
                if (kv.TryGetValue("back_fit", out sv) && int.TryParse(sv, out iv)) s.BackFit = Math.Max(0, Math.Min(2, iv));
                string pin;
                if (kv.TryGetValue("pin_offered", out pin)) s.PinOffered = (pin == "1");
                // valores absurdos (arquivo corrompido) voltam ao padrão
                if (s.WinW < 0 || s.WinW > 10000) s.WinW = 0;
                if (s.WinH < 0 || s.WinH > 10000) s.WinH = 0;
            }
            catch (Exception ex) { ErrorLog.Write(ex); }
            return s;
        }

        public void Save()
        {
            try
            {
                List<string> lines = new List<string>();
                for (int n = 0; n < Count; n++)
                {
                    lines.Add("hk" + n + "_mods=" + Hotkeys[n].Mods);
                    lines.Add("hk" + n + "_vk=" + Hotkeys[n].Vk);
                }
                for (int n = 0; n < Combos; n++)
                {
                    lines.Add("cb" + n + "_mask=" + ComboMask[n]);
                    lines.Add("cb" + n + "_mods=" + ComboKeys[n].Mods);
                    lines.Add("cb" + n + "_vk=" + ComboKeys[n].Vk);
                }
                lines.Add("bro_a=" + BrowserA);
                lines.Add("bro_b=" + BrowserB);
                lines.Add("bro_slot=" + ActiveSlot);
                lines.Add("swap_mods=" + SwapKey.Mods);
                lines.Add("swap_vk=" + SwapKey.Vk);
                lines.Add("rel_mods=" + ReleaseKey.Mods);
                lines.Add("rel_vk=" + ReleaseKey.Vk);
                lines.Add("hud_on=" + (HudOn ? "1" : "0"));
                lines.Add("free_apps=" + FreeApps);
                lines.Add("ask_boot=" + (AskAtBoot ? "1" : "0"));
                lines.Add("win_w=" + WinW);
                lines.Add("win_h=" + WinH);
                lines.Add("clk_on=" + (ClockOn ? "1" : "0"));
                lines.Add("clk_h=" + (ClockH ? "1" : "0"));
                lines.Add("clk_m=" + (ClockM ? "1" : "0"));
                lines.Add("clk_s=" + (ClockS ? "1" : "0"));
                lines.Add("clk_color=" + ClockColor);
                lines.Add("clk_bg=" + ClockBg);
                lines.Add("clk_alpha=" + ClockBgAlpha);
                lines.Add("clk_size=" + ClockSize);
                lines.Add("clk_pos=" + ClockPos);
                lines.Add("clk_screens=" + ClockScreens);
                lines.Add("back_on=" + (BackOn ? "1" : "0"));
                lines.Add("back_path=" + BackPath);
                lines.Add("back_color=" + BackColor);
                lines.Add("back_fit=" + BackFit);
                lines.Add("pin_offered=" + (PinOffered ? "1" : "0"));
                SafeFile.WriteAllLines(FilePath(), lines.ToArray());
            }
            catch (Exception ex) { ErrorLog.Write(ex); }
        }
    }
}
