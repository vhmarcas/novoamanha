using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace NovoAmanha
{
    // Foto de uma janela de outro programa (para o detector comparar com a foto anterior).
    internal class WinSnap
    {
        public IntPtr H;
        public uint Pid;
        public string Proc = "", Cls = "", Title = "", Scr = "";
        public bool Vis, Iconic, Cloaked, Top, Layered, Transp, ToolW, NoAct, Under, Free;
        public int Alpha = -1;   // -1 = sem transparência de janela; -2 = transparência por pixel; 0..255 = valor
        public RECT R;
    }

    // Detector do Holyrics: vigia as janelas do Holyrics (ou de tudo que aparece na tela compartilhada) a cada 100 ms
    // e escreve cada mudança (apareceu, sumiu, mexeu, ficou transparente, ficou por baixo do fundo...).
    // Serve para descobrir qual atividade do Holyrics faz o versículo aparecer na tela.
    internal class SpyForm : Form
    {
        private class Ev
        {
            public DateTime T;
            public IntPtr H;
            public string Kind = "", Proc = "", Cls = "", Title = "";
            public bool Free;
        }

        private static SpyForm _open;

        private readonly Settings _s;
        private readonly MethodInvoker _changed;
        private readonly Timer _t = new Timer();
        private readonly TextBox _log = new TextBox();
        private readonly CheckBox _chkAll = new CheckBox();
        private readonly Label _status = new Label();
        private Dictionary<IntPtr, WinSnap> _prev = new Dictionary<IntPtr, WinSnap>();
        private bool _first = true;
        private bool _lastAll;
        private readonly List<Ev> _events = new List<Ev>();
        private DateTime _mark = DateTime.MinValue;
        private IntPtr _lastFg = IntPtr.Zero;
        private readonly uint _own;
        private readonly string _file;

        public static void ShowSpy(Settings s, MethodInvoker changed)
        {
            if (_open != null && !_open.IsDisposed)
            {
                _open.Activate();
                return;
            }
            _open = new SpyForm(s, changed);
            _open.Show();
        }

        private SpyForm(Settings s, MethodInvoker changed)
        {
            _s = s;
            _changed = changed;
            _own = (uint)System.Diagnostics.Process.GetCurrentProcess().Id;
            string dir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "NovoAmanhaHelper");
            try { Directory.CreateDirectory(dir); } catch { }
            _file = Path.Combine(dir, "holyrics_log.txt");
            try
            {
                FileInfo fi = new FileInfo(_file);
                if (fi.Exists && fi.Length > 500000) File.Delete(_file);
            }
            catch { }

            Text = "Detector do Holyrics";
            StartPosition = FormStartPosition.CenterScreen;
            TopMost = true;
            ShowInTaskbar = true;
            BackColor = Theme.Bg;
            ForeColor = Theme.Text;
            AutoScaleMode = AutoScaleMode.None;
            ClientSize = new Size(820, 560);
            MinimumSize = new Size(640, 420);

            Label help = new Label();
            help.AutoSize = false;
            help.Font = new Font("Segoe UI", 9.5f);
            help.ForeColor = Theme.Text;
            help.BackColor = Theme.Bg;
            help.Text = "Como usar: deixe esta janela aberta, aperte \"Marcar\", passe um versículo no Holyrics e aperte " +
                        "\"O que mudou?\". O quadro abaixo mostra cada janela do Holyrics que apareceu, sumiu, mexeu ou ficou " +
                        "escondida atrás do fundo. O mesmo texto é salvo em holyrics_log.txt (pasta NovoAmanhaHelper, dentro de AppData\\Roaming).";
            help.SetBounds(12, 8, 796, 56);
            Controls.Add(help);

            int x = 12;
            x = AddButton("Marcar (vou passar um versículo)", x, 70, 230, delegate { Mark(); });
            x = AddButton("O que mudou?", x, 70, 130, delegate { Summary(); });
            x = AddButton("Limpar", x, 70, 80, delegate { _log.Clear(); _events.Clear(); });
            x = AddButton("Abrir o arquivo", x, 70, 120, delegate { OpenFile(); });

            _chkAll.Text = "Vigiar tudo que aparece na compartilhada (não só o Holyrics)";
            _chkAll.Font = new Font("Segoe UI", 9.5f);
            _chkAll.ForeColor = Theme.Text;
            _chkAll.BackColor = Theme.Bg;
            _chkAll.SetBounds(12, 106, 520, 24);
            Controls.Add(_chkAll);

            _status.AutoSize = false;
            _status.Font = new Font("Segoe UI", 9.5f, FontStyle.Bold);
            _status.ForeColor = Theme.Accent;
            _status.BackColor = Theme.Bg;
            _status.SetBounds(540, 106, 270, 24);
            _status.TextAlign = ContentAlignment.MiddleRight;
            Controls.Add(_status);

            _log.Multiline = true;
            _log.ReadOnly = true;
            _log.ScrollBars = ScrollBars.Both;
            _log.WordWrap = false;
            _log.Font = new Font("Consolas", 9.5f);
            _log.BackColor = Color.FromArgb(10, 14, 26);
            _log.ForeColor = Theme.Text;
            _log.BorderStyle = BorderStyle.FixedSingle;
            _log.SetBounds(12, 136, 796, 412);
            _log.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Controls.Add(_log);

            _t.Interval = 100;
            _t.Tick += delegate { Poll(); };
            FormClosed += delegate
            {
                _t.Stop();
                _t.Dispose();
                if (_open == this) _open = null;
            };
            Shown += delegate
            {
                Poll();
                _t.Start();
            };
        }

        private int AddButton(string text, int x, int y, int w, EventHandler click)
        {
            Button b = new Button();
            b.Text = text;
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderColor = Theme.Accent;
            b.FlatAppearance.BorderSize = 1;
            b.Font = new Font("Segoe UI", 9.5f);
            b.ForeColor = Theme.Text;
            b.BackColor = Theme.Card;
            b.Cursor = Cursors.Hand;
            b.SetBounds(x, y, w, 30);
            b.Click += click;
            Controls.Add(b);
            return x + w + 8;
        }

        // ---------- fotos das janelas ----------

        private Dictionary<IntPtr, WinSnap> Take(bool all)
        {
            Dictionary<IntPtr, WinSnap> d = new Dictionary<IntPtr, WinSnap>();
            List<Screen> shared = Engine.SharedScreens();
            Screen[] screens = Screen.AllScreens;
            bool coverSeen = false;   // já passamos por uma capa/fundo do painel (então ela está ACIMA das próximas janelas)

            Native.EnumWindows(delegate(IntPtr h, IntPtr lp)
            {
                uint pid;
                Native.GetWindowThreadProcessId(h, out pid);
                if (pid == _own)
                {
                    if (!coverSeen && Native.IsWindowVisible(h) && Native.TitleOf(h) == "NovoAmanha.Cover") coverSeen = true;
                    return true;
                }
                if (pid == 0) return true;

                bool free = FreeWin.IsFree(h);
                bool vis = Native.IsWindowVisible(h);
                bool iconic = Native.IsIconic(h);
                RECT r;
                if (!Native.GetWindowRect(h, out r)) return true;

                if (!free)
                {
                    if (!all) return true;
                    if (!vis || iconic || r.Width <= 0 || r.Height <= 0 || !Engine.OnShared(r, shared)) return true;
                    string c0 = Native.ClassOf(h);
                    if (c0 == "Progman" || c0 == "WorkerW" || c0 == "Shell_TrayWnd" || c0 == "Shell_SecondaryTrayWnd") return true;
                }

                WinSnap s = new WinSnap();
                s.H = h;
                s.Pid = pid;
                s.Proc = FreeWin.ProcName(pid);
                s.Cls = Native.ClassOf(h);
                s.Title = Native.TitleOf(h);
                s.Vis = vis;
                s.Iconic = iconic;
                s.Free = free;
                s.R = r;
                int ex = Native.GetWindowLong(h, Native.GWL_EXSTYLE);
                s.Top = (ex & Native.WS_EX_TOPMOST) != 0;
                s.Layered = (ex & Native.WS_EX_LAYERED) != 0;
                s.Transp = (ex & Native.WS_EX_TRANSPARENT) != 0;
                s.ToolW = (ex & Native.WS_EX_TOOLWINDOW) != 0;
                s.NoAct = (ex & Native.WS_EX_NOACTIVATE) != 0;
                int cloaked;
                s.Cloaked = Native.DwmGetWindowAttribute(h, Native.DWMWA_CLOAKED, out cloaked, 4) == 0 && cloaked != 0;
                if (s.Layered)
                {
                    uint key, fl;
                    byte al;
                    if (Native.GetLayeredWindowAttributes(h, out key, out al, out fl) && (fl & 2) != 0) s.Alpha = al;
                    else s.Alpha = -2;
                }
                s.Under = coverSeen;

                Point center = new Point(r.Left + r.Width / 2, r.Top + r.Height / 2);
                string scr = "?";
                foreach (Screen sc in screens)
                    if (sc.Bounds.Contains(center))
                    {
                        bool isShared = false;
                        foreach (Screen q in shared) if (q.DeviceName == sc.DeviceName) isShared = true;
                        scr = sc.DeviceName + (isShared ? " (compartilhada)" : sc.Primary ? " (notebook)" : "");
                        break;
                    }
                s.Scr = scr;
                d[h] = s;
                return true;
            }, IntPtr.Zero);
            return d;
        }

        private static string Trunc(string t, int n)
        {
            if (t == null) return "";
            return t.Length <= n ? t : t.Substring(0, n) + "…";
        }

        private static string Rect(RECT r)
        {
            return r.Left + "," + r.Top + " " + r.Width + "x" + r.Height;
        }

        private static string AlphaText(int a)
        {
            if (a == -1) return "sem transparência";
            if (a == -2) return "transparência por pixel";
            return "opacidade " + (a * 100 / 255) + "%";
        }

        private static string Brief(WinSnap s)
        {
            return "[" + s.Proc + "] classe=" + s.Cls + " título=\"" + Trunc(s.Title, 60) + "\"";
        }

        private static string Describe(WinSnap s)
        {
            List<string> st = new List<string>();
            st.Add(s.Vis ? "visível" : "invisível");
            if (s.Iconic) st.Add("minimizada");
            if (s.Cloaked) st.Add("oculta pelo Windows");
            if (s.Top) st.Add("sempre no topo");
            if (s.Layered) st.Add(AlphaText(s.Alpha));
            if (s.Transp) st.Add("clique atravessa");
            if (s.ToolW) st.Add("janela-ferramenta");
            if (s.NoAct) st.Add("sem foco");
            if (s.Vis && s.Under) st.Add("POR BAIXO do fundo");
            return Brief(s) + "  " + Rect(s.R) + "  tela=" + s.Scr + "  (" + string.Join(", ", st.ToArray()) + ")";
        }

        // ---------- comparação ----------

        private void Poll()
        {
            try
            {
                bool all = _chkAll.Checked;
                if (all != _lastAll)
                {
                    _lastAll = all;
                    _first = true;   // mudou o modo: recomeça do estado inicial
                    _prev = new Dictionary<IntPtr, WinSnap>();
                    Line("--- modo: " + (all ? "tudo que aparece na compartilhada" : "só os programas liberados (Holyrics)") + " ---");
                }
                Dictionary<IntPtr, WinSnap> now = Take(all);

                if (_first)
                {
                    _first = false;
                    Line("ESTADO INICIAL (" + now.Count + " janela(s)):");
                    foreach (WinSnap s in now.Values) if (s.Vis) Line("   " + Describe(s));
                    int hidden = 0;
                    foreach (WinSnap s in now.Values) if (!s.Vis) hidden++;
                    if (hidden > 0) Line("   (+ " + hidden + " janela(s) invisível(is) sendo vigiada(s))");
                }
                else Compare(now);

                IntPtr fg = Native.GetForegroundWindow();
                if (fg != _lastFg)
                {
                    _lastFg = fg;
                    WinSnap f;
                    if (now.TryGetValue(fg, out f)) Line("EM PRIMEIRO PLANO  " + Brief(f));
                }

                _prev = now;

                int vis = 0, free = 0;
                foreach (WinSnap s in now.Values)
                {
                    if (!s.Free) continue;
                    free++;
                    if (s.Vis) vis++;
                }
                _status.Text = free == 0 ? "Holyrics não encontrado" : "Holyrics: " + free + " janela(s), " + vis + " visível(is)";
                _status.ForeColor = free == 0 ? Theme.Warn : Theme.Good;
            }
            catch (Exception ex) { ErrorLog.Write(ex); }
        }

        private void Compare(Dictionary<IntPtr, WinSnap> now)
        {
            foreach (KeyValuePair<IntPtr, WinSnap> kv in now)
            {
                WinSnap b = kv.Value;
                WinSnap a;
                if (!_prev.TryGetValue(kv.Key, out a))
                {
                    Rec(b, "NOVA JANELA", Describe(b));
                    continue;
                }
                if (a.Vis != b.Vis) Rec(b, b.Vis ? "APARECEU" : "ESCONDEU", Describe(b));
                if (a.Iconic != b.Iconic) Rec(b, b.Iconic ? "MINIMIZOU" : "RESTAURADA", Brief(b));
                if (a.Cloaked != b.Cloaked) Rec(b, b.Cloaked ? "OCULTADA PELO WINDOWS" : "DESOCULTADA", Brief(b));
                if (a.R.Left != b.R.Left || a.R.Top != b.R.Top || a.R.Width != b.R.Width || a.R.Height != b.R.Height)
                    Rec(b, "MOVEU/MUDOU DE TAMANHO", Brief(b) + "  " + Rect(a.R) + "  ->  " + Rect(b.R));
                if (a.Title != b.Title)
                    Rec(b, "TÍTULO MUDOU", Brief(b) + "  \"" + Trunc(a.Title, 50) + "\"  ->  \"" + Trunc(b.Title, 50) + "\"");
                if (a.Alpha != b.Alpha)
                    Rec(b, "TRANSPARÊNCIA MUDOU", Brief(b) + "  " + AlphaText(a.Alpha) + "  ->  " + AlphaText(b.Alpha));
                if (a.Top != b.Top) Rec(b, b.Top ? "VIROU SEMPRE-NO-TOPO" : "DEIXOU DE SER SEMPRE-NO-TOPO", Brief(b));
                if (a.Scr != b.Scr) Rec(b, "MUDOU DE TELA", Brief(b) + "  " + a.Scr + "  ->  " + b.Scr);
                if (b.Vis && a.Under != b.Under)
                    Rec(b, b.Under ? "FICOU POR BAIXO DO FUNDO (escondida)" : "FICOU POR CIMA DO FUNDO", Brief(b));
            }
            foreach (KeyValuePair<IntPtr, WinSnap> kv in _prev)
                if (!now.ContainsKey(kv.Key))
                    Rec(kv.Value, _lastAll ? "SAIU (fechou, escondeu ou saiu da compartilhada)" : "FECHOU", Describe(kv.Value));
        }

        private void Rec(WinSnap s, string kind, string text)
        {
            Ev e = new Ev();
            e.T = DateTime.Now;
            e.H = s.H;
            e.Kind = kind;
            e.Proc = s.Proc;
            e.Cls = s.Cls;
            e.Title = s.Title;
            e.Free = s.Free;
            _events.Add(e);
            if (_events.Count > 5000) _events.RemoveRange(0, 2500);
            Line(kind + "  " + text);
        }

        private void Line(string text)
        {
            string full = DateTime.Now.ToString("HH:mm:ss.fff") + "  " + text;
            if (_log.TextLength > 200000) _log.Text = _log.Text.Substring(_log.TextLength - 100000);
            _log.AppendText(full + "\r\n");
            try { File.AppendAllText(_file, full + "\r\n", Encoding.UTF8); }
            catch { }
        }

        // ---------- botões ----------

        private void Mark()
        {
            _mark = DateTime.Now;
            Line("========== MARCA: agora passe o versículo no Holyrics ==========");
        }

        private void OpenFile()
        {
            try
            {
                if (!File.Exists(_file)) File.WriteAllText(_file, "", Encoding.UTF8);
                System.Diagnostics.Process.Start(_file);
            }
            catch (Exception ex) { ErrorLog.Write(ex); }
        }

        // Resume o que mudou depois da última marca (ou, sem marca, nos últimos 20 segundos).
        private void Summary()
        {
            DateTime from = _mark != DateTime.MinValue ? _mark : DateTime.Now.AddSeconds(-20);
            Dictionary<IntPtr, List<string>> byWin = new Dictionary<IntPtr, List<string>>();
            Dictionary<IntPtr, Ev> sample = new Dictionary<IntPtr, Ev>();
            List<IntPtr> order = new List<IntPtr>();
            foreach (Ev e in _events)
            {
                if (e.T < from) continue;
                List<string> l;
                if (!byWin.TryGetValue(e.H, out l))
                {
                    l = new List<string>();
                    byWin[e.H] = l;
                    sample[e.H] = e;
                    order.Add(e.H);
                }
                if (!l.Contains(e.Kind)) l.Add(e.Kind);
            }

            Line("---------- RESUMO (desde " + from.ToString("HH:mm:ss") + ") ----------");
            if (order.Count == 0)
            {
                Line("Nenhuma janela mudou. Então o Holyrics desenha o versículo DENTRO de uma janela que já estava aberta");
                Line("(só o conteúdo muda). Nesse caso basta ela ficar sempre acima do fundo — o painel já faz isso para");
                Line("as janelas do Holyrics que aparecem na compartilhada. Se o versículo ainda não aparece, me envie este arquivo.");
                return;
            }

            string toAdd = "";
            foreach (IntPtr h in order)
            {
                Ev e = sample[h];
                Line("• [" + e.Proc + "] classe=" + e.Cls + " título=\"" + Trunc(e.Title, 50) + "\"" + (e.Free ? "" : "   (programa NÃO liberado)"));
                Line("    reagiu com: " + string.Join("; ", byWin[h].ToArray()));
                bool strong = false;
                foreach (string k in byWin[h])
                    if (k == "APARECEU" || k == "NOVA JANELA" || k.StartsWith("TRANSPARÊNCIA") || k.StartsWith("MOVEU")) strong = true;
                if (strong && !e.Free && e.Proc.Length > 0 && e.Proc != "?" && toAdd.Length == 0) toAdd = e.Proc;
            }
            Line("A janela do versículo é provavelmente a que APARECEU / mudou de transparência / mexeu quando você passou o versículo.");
            Line("Se ela aparece como \"POR BAIXO do fundo\", era isso que escondia o versículo.");

            if (toAdd.Length > 0)
            {
                DialogResult dr = MessageBox.Show(this,
                    "Uma janela do programa \"" + toAdd + "\" reagiu quando você passou o versículo, mas ele não está na lista de programas liberados.\r\n\r\n" +
                    "Quer liberar \"" + toAdd + "\" (ele passa a aparecer acima do fundo e nunca é tirado da compartilhada)?",
                    "Detector do Holyrics", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dr == DialogResult.Yes)
                {
                    string cur = _s.FreeApps ?? "";
                    _s.FreeApps = cur.Length == 0 ? toAdd : cur + "," + toAdd;
                    Engine.SetFreeApps(_s.FreeApps);
                    try { _s.Save(); } catch (Exception ex) { ErrorLog.Write(ex); }
                    if (_changed != null) _changed();
                    Line("Programa \"" + toAdd + "\" liberado. Lista agora: " + _s.FreeApps);
                }
            }
        }
    }
}
