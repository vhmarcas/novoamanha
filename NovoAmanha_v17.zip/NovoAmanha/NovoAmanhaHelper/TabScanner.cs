using System;
using System.Collections.Generic;
using System.Drawing;
#if UIA
using System.Windows.Automation;
#endif

namespace NovoAmanha
{
    // Lê os nomes de TODAS as abas de uma janela de navegador (inclusive as que estão em segundo plano),
    // usando o UI Automation do Windows. Só é compilado se o build.bat achar as bibliotecas (define UIA).
    internal static class TabScanner
    {
#if UIA
        public const bool Available = true;

        // Devolve a lista de abas, ou null se o navegador não respondeu.
        public static List<string> TabNames(IntPtr hwnd)
        {
            List<string> names = new List<string>();
            try
            {
                AutomationElement root = AutomationElement.FromHandle(hwnd);
                if (root == null) return null;
                Walk(root, 0, names);
            }
            catch { return null; }
            return names;
        }

        // Elemento do player guardado: ler a posição dele é uma única chamada rápida (bem mais leve
        // do que procurar o player de novo na árvore do navegador a cada vez).
        private static AutomationElement _cacheEl;
        private static IntPtr _cacheH = IntPtr.Zero;
        private static DateTime _cacheAt = DateTime.MinValue;

        private static Rectangle? ReadRect(AutomationElement el)
        {
            try
            {
                System.Windows.Rect r = el.Current.BoundingRectangle;
                if (r.IsEmpty || r.Width < 60 || r.Height < 60) return null;
                return new Rectangle((int)r.X, (int)r.Y, (int)r.Width, (int)r.Height);
            }
            catch { return null; }
        }

        // Retângulo (em pixels da tela) do player do YouTube na página, ou null se não achou.
        public static Rectangle? PlayerRect(IntPtr hwnd)
        {
            try
            {
                // caminho rápido: elemento já conhecido (refeito por completo a cada 3 s por segurança)
                AutomationElement c = _cacheEl;
                if (c != null && _cacheH == hwnd && (DateTime.UtcNow - _cacheAt).TotalSeconds < 3.0)
                {
                    Rectangle? fast = ReadRect(c);
                    if (fast.HasValue) return fast;
                }
                _cacheEl = null;

                AutomationElement root = AutomationElement.FromHandle(hwnd);
                if (root == null) return null;
                string[] ids = new string[] { "movie_player", "shorts-player" };
                foreach (string id in ids)
                {
                    AutomationElement el = root.FindFirst(TreeScope.Descendants,
                        new PropertyCondition(AutomationElement.AutomationIdProperty, id));
                    if (el == null) continue;
                    Rectangle? r = ReadRect(el);
                    if (!r.HasValue) continue;
                    _cacheEl = el;
                    _cacheH = hwnd;
                    _cacheAt = DateTime.UtcNow;
                    return r;
                }
            }
            catch { }
            return null;
        }

        // Endereço da aba ativa (texto da barra de endereços), ou null se não deu para ler.
        public static string AddressBar(IntPtr hwnd)
        {
            try
            {
                AutomationElement root = AutomationElement.FromHandle(hwnd);
                if (root == null) return null;
                return FindAddress(root, 0);
            }
            catch { return null; }
        }

        private static string FindAddress(AutomationElement e, int depth)
        {
            if (depth > 10) return null;
            AutomationElement c = TreeWalker.RawViewWalker.GetFirstChild(e);
            int guard = 0;
            while (c != null && guard < 500)
            {
                guard++;
                ControlType ct = c.Current.ControlType;
                if (ct == ControlType.Edit)
                {
                    object pat;
                    if (c.TryGetCurrentPattern(ValuePattern.Pattern, out pat))
                    {
                        string v = ((ValuePattern)pat).Current.Value;
                        if (!string.IsNullOrEmpty(v)) return v;
                    }
                }
                else if (ct != ControlType.Document)
                {
                    string r = FindAddress(c, depth + 1);
                    if (r != null) return r;
                }
                c = TreeWalker.RawViewWalker.GetNextSibling(c);
            }
            return null;
        }

        // Anda só pela parte "de cima" do navegador (abas, barra de endereço) e não entra no conteúdo da página.
        private static void Walk(AutomationElement e, int depth, List<string> names)
        {
            if (depth > 10 || names.Count > 300) return;
            AutomationElement c = TreeWalker.RawViewWalker.GetFirstChild(e);
            int guard = 0;
            while (c != null && guard < 500)
            {
                guard++;
                ControlType ct = c.Current.ControlType;
                if (ct == ControlType.TabItem)
                    names.Add(c.Current.Name);
                else if (ct != ControlType.Document)
                    Walk(c, depth + 1, names);
                c = TreeWalker.RawViewWalker.GetNextSibling(c);
            }
        }
#else
        public const bool Available = false;

        public static string AddressBar(IntPtr hwnd)
        {
            return null;
        }

        public static Rectangle? PlayerRect(IntPtr hwnd)
        {
            return null;
        }

        public static List<string> TabNames(IntPtr hwnd)
        {
            return null;
        }
#endif
    }
}
