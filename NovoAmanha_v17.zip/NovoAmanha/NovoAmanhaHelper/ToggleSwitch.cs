using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace NovoAmanha
{
    // Interruptor com deslize suave, brilho e reação ao mouse.
    internal class ToggleSwitch : Control
    {
        private bool _checked;
        private float _pos;      // 0 = desligado, 1 = ligado (animado)
        private float _hover;
        private bool _over;
        private readonly Timer _anim = new Timer();
        public event EventHandler CheckedChanged;

        public ToggleSwitch()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.UserPaint | ControlStyles.ResizeRedraw |
                     ControlStyles.SupportsTransparentBackColor, true);
            Size = new Size(54, 28);
            Cursor = Cursors.Hand;
            BackColor = Color.Transparent;
            _anim.Interval = 20;
            _anim.Tick += delegate { Step(); };
        }

        public bool Checked
        {
            get { return _checked; }
            set
            {
                if (_checked == value) return;
                _checked = value;
                _anim.Start();
                Invalidate();
                if (CheckedChanged != null) CheckedChanged(this, EventArgs.Empty);
            }
        }

        private void Step()
        {
            float target = _checked ? 1f : 0f;
            float ht = _over ? 1f : 0f;
            _pos += (target - _pos) * 0.34f;
            _hover += (ht - _hover) * 0.30f;
            bool settled = Math.Abs(target - _pos) < 0.01f && Math.Abs(ht - _hover) < 0.01f;
            if (settled)
            {
                _pos = target;
                _hover = ht;
                _anim.Stop();
            }
            Invalidate();
        }

        protected override void OnMouseEnter(EventArgs e) { base.OnMouseEnter(e); _over = true; _anim.Start(); }
        protected override void OnMouseLeave(EventArgs e) { base.OnMouseLeave(e); _over = false; _anim.Start(); }

        protected override void OnClick(EventArgs e)
        {
            base.OnClick(e);
            Checked = !Checked;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            if (Width < 12 || Height < 8) return;
            Rectangle r = new Rectangle(1, 1, Width - 3, Height - 3);

            using (GraphicsPath p = Pill(r))
            {
                if (_pos > 0.02f)
                {
                    using (Pen glow = new Pen(Color.FromArgb((int)(70 * _pos), Theme.Accent), 5f))
                        g.DrawPath(glow, p);
                }
                Color off = Fx.Mix(Color.FromArgb(70, 72, 90), Color.FromArgb(92, 94, 116), _hover);
                Color a = Fx.Mix(off, Theme.Accent, _pos);
                Color b = Fx.Mix(off, Theme.Gold, _pos);
                using (LinearGradientBrush track = new LinearGradientBrush(r, a, b, 0f))
                    g.FillPath(track, p);
            }

            int d = Height - 8;
            float x = Fx.Lerp(4f, Width - d - 4f, _pos);
            using (SolidBrush shadow = new SolidBrush(Color.FromArgb(60, 0, 0, 0)))
                g.FillEllipse(shadow, x, 5.5f, d, d);
            using (SolidBrush knob = new SolidBrush(Fx.Mix(Color.FromArgb(235, 235, 245), Color.White, _pos)))
                g.FillEllipse(knob, x, 4f, d, d);
        }

        private static GraphicsPath Pill(Rectangle r)
        {
            GraphicsPath p = new GraphicsPath();
            int d = r.Height;
            p.AddArc(r.X, r.Y, d, d, 90, 180);
            p.AddArc(r.Right - d, r.Y, d, d, 270, 180);
            p.CloseFigure();
            return p;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) _anim.Dispose();
            base.Dispose(disposing);
        }
    }

    // Paleta futurista: fundo quase preto azulado, ciano neon, violeta e verde neon.
    internal static class Theme
    {
        public static readonly Color Bg = Color.FromArgb(5, 8, 18);
        public static readonly Color Card = Color.FromArgb(11, 16, 32);
        public static readonly Color Text = Color.FromArgb(222, 236, 255);
        public static readonly Color Muted = Color.FromArgb(120, 140, 176);
        public static readonly Color Accent = Color.FromArgb(0, 226, 255);
        public static readonly Color Gold = Color.FromArgb(168, 120, 255);
        public static readonly Color Good = Color.FromArgb(70, 255, 170);
        public static readonly Color Warn = Color.FromArgb(255, 190, 40);
        public static readonly Color Edge = Color.FromArgb(40, 74, 120);
    }

    // Cartão futurista: canto chanfrado, colchetes nos cantos; com Glow ligado a borda brilha e gira as cores.
    internal class RoundedPanel : Panel
    {
        public int Radius = 18;   // tamanho do chanfro = ~2/3 disto
        public bool Glow;
        public float Phase;

        public RoundedPanel()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
            BackColor = Theme.Bg;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Theme.Bg);
            g.SmoothingMode = SmoothingMode.AntiAlias;
            Rectangle r = new Rectangle(1, 1, Width - 3, Height - 3);
            if (r.Width < 16 || r.Height < 16) return;
            int c = Math.Max(6, Radius * 2 / 3);

            using (GraphicsPath p = Fx.Chamfer(r, c))
            {
                using (LinearGradientBrush b = new LinearGradientBrush(r, Fx.Mix(Theme.Card, Color.White, 0.035f), Theme.Card, 90f))
                    g.FillPath(b, p);

                if (Glow)
                {
                    float breathe = 0.5f + 0.5f * (float)Math.Sin(Phase * 18f);
                    using (Pen soft = new Pen(Color.FromArgb((int)(24 + 34 * breathe), Theme.Accent), 6f))
                        g.DrawPath(soft, p);
                    using (LinearGradientBrush gb = new LinearGradientBrush(r, Theme.Accent, Theme.Gold, 45f))
                    {
                        ColorBlend cb = new ColorBlend(4);
                        cb.Colors = new Color[] { Theme.Accent, Theme.Gold, Color.FromArgb(255, 70, 190), Theme.Accent };
                        cb.Positions = new float[] { 0f, 0.4f, 0.75f, 1f };
                        gb.InterpolationColors = cb;
                        gb.WrapMode = WrapMode.TileFlipXY;
                        gb.RotateTransform(Phase * 360f);
                        using (Pen pen = new Pen(gb, 1.8f))
                            g.DrawPath(pen, p);
                    }
                }
                else
                {
                    using (Pen pen = new Pen(Color.FromArgb(150, Theme.Edge), 1f))
                        g.DrawPath(pen, p);
                }
            }

            // colchetes nos cantos livres + marca de destaque no topo
            int L = Math.Max(10, c);
            Color bc = Glow ? Theme.Accent : Fx.Mix(Theme.Edge, Theme.Accent, 0.45f);
            using (Pen bp = new Pen(bc, 1.6f))
            {
                g.DrawLine(bp, r.Right - L, r.Top, r.Right, r.Top);
                g.DrawLine(bp, r.Right, r.Top, r.Right, r.Top + L);
                g.DrawLine(bp, r.Left, r.Bottom - L, r.Left, r.Bottom);
                g.DrawLine(bp, r.Left, r.Bottom, r.Left + L, r.Bottom);
            }
            using (Pen tp = new Pen(Color.FromArgb(Glow ? 255 : 140, Theme.Accent), 2f))
                g.DrawLine(tp, r.Left + c + 6, r.Top + 1, r.Left + c + 6 + Math.Min(46, r.Width / 4), r.Top + 1);
        }
    }
}
