@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%CSC%" (
  echo Nao encontrei o compilador do .NET Framework 4 neste Windows.
  pause
  exit /b 1
)

for %%I in ("%CSC%") do set "FWDIR=%%~dpI"
set "WPFDIR=%FWDIR%WPF"
set "UIA="
if exist "%WPFDIR%\UIAutomationClient.dll" if exist "%WPFDIR%\UIAutomationTypes.dll" set "UIA=/define:UIA /lib:%WPFDIR% /r:UIAutomationClient.dll /r:UIAutomationTypes.dll"
if defined UIA if exist "%WPFDIR%\WindowsBase.dll" set "UIA=%UIA% /r:WindowsBase.dll"

echo Compilando Novo Amanha Helper...
:compile
if defined UIA (echo Leitura de abas do navegador: ATIVADA) else (echo Leitura de abas do navegador: desligada)
"%CSC%" /nologo /target:winexe /platform:x64 /optimize+ /codepage:65001 %UIA% /out:NovoAmanhaHelper.exe ^
  /win32manifest:app.manifest ^
  /resource:"%~dp0banner.jpg",banner.jpg ^
  /r:System.dll /r:System.Drawing.dll /r:System.Windows.Forms.dll /r:System.Management.dll ^
  Native.cs Settings.cs FreeWin.cs Engine.cs EngineWindows.cs ToggleSwitch.cs ProtectedDialog.cs Devices.cs TabScanner.cs MeetDetector.cs Fx.cs Browsers.cs Hud.cs Guard.cs BootPrompt.cs Audio.cs Overlays.cs SpyForm.cs ExtrasForm.cs MainForm.cs Program.cs > "%~dp0log_compilacao.txt" 2>&1
set "RESULT=%errorlevel%"
if not "%RESULT%"=="0" if defined UIA (
  echo Falhou com a leitura de abas. Tentando de novo sem ela...
  copy /y "%~dp0log_compilacao.txt" "%~dp0log_compilacao_com_abas.txt" >nul
  set "UIA="
  goto compile
)
type "%~dp0log_compilacao.txt"

if not "%RESULT%"=="0" (
  echo.
  echo ERRO na compilacao. Me envie o arquivo log_compilacao.txt desta pasta.
  if /i not "%~1"=="/semabrir" pause
  exit /b 1
)

echo.
echo Pronto! Gerado: %~dp0NovoAmanhaHelper.exe
if /i "%~1"=="/semabrir" goto fim
echo Abrindo...
start "" "%~dp0NovoAmanhaHelper.exe"
:fim
endlocal
exit /b 0
