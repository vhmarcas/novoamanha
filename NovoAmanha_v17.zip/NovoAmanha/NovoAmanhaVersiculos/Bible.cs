using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace Versiculos
{
    // Uma referência: livro (0..65), capítulo (1..), versículo inicial e final (1..)
    internal struct VRef
    {
        public int Book, Chapter, From, To;
    }

    internal class Bible
    {
        public static readonly string[] Names = new string[]
        {
            "Gênesis", "Êxodo", "Levítico", "Números", "Deuteronômio", "Josué", "Juízes", "Rute",
            "1 Samuel", "2 Samuel", "1 Reis", "2 Reis", "1 Crônicas", "2 Crônicas", "Esdras", "Neemias", "Ester",
            "Jó", "Salmos", "Provérbios", "Eclesiastes", "Cantares", "Isaías", "Jeremias", "Lamentações",
            "Ezequiel", "Daniel", "Oseias", "Joel", "Amós", "Obadias", "Jonas", "Miqueias", "Naum", "Habacuque",
            "Sofonias", "Ageu", "Zacarias", "Malaquias",
            "Mateus", "Marcos", "Lucas", "João", "Atos", "Romanos", "1 Coríntios", "2 Coríntios", "Gálatas",
            "Efésios", "Filipenses", "Colossenses", "1 Tessalonicenses", "2 Tessalonicenses", "1 Timóteo",
            "2 Timóteo", "Tito", "Filemom", "Hebreus", "Tiago", "1 Pedro", "2 Pedro", "1 João", "2 João",
            "3 João", "Judas", "Apocalipse"
        };

        // Apelidos extras (sem acento, sem espaço), na mesma ordem dos nomes.
        private static readonly string[] Aliases = new string[]
        {
            "gn|gen", "ex|exo", "lv|lev", "nm|num|nu", "dt|deu|dut", "js|jos", "jz|jui", "rt|rut",
            "1sm|1sa|1sam", "2sm|2sa|2sam", "1rs|1re", "2rs|2re", "1cr|1cro|1cron", "2cr|2cro|2cron", "ed|esd", "ne|nee", "et|est",
            "job|jb", "sl|sal|salmo|ps", "pv|pro|prov", "ec|ecl", "ct|can|cantico|canticos", "is|isa", "jr|jer", "lm|lam",
            "ez|eze|ezeq", "dn|dan", "os|ose", "jl|joe", "am|amo", "ob|oba|abdias", "jn|jon", "mq|miq", "na|nau", "hc|hab",
            "sf|sof", "ag|age", "zc|zac", "ml|mal",
            "mt|mat", "mc|mar|mr", "lc|luc", "jo|joa|joao", "at|ato", "rm|rom", "1co|1cor", "2co|2cor", "gl|gal",
            "ef|efe", "fp|fil|flp", "cl|col", "1ts|1te|1tes", "2ts|2te|2tes", "1tm|1ti|1tim",
            "2tm|2ti|2tim", "tt|tit", "fm|flm|filemon", "hb|heb", "tg|tia", "1pe|1pd|1ped", "2pe|2pd|2ped", "1jo|1joa|1jn|1joao", "2jo|2joa|2jn|2joao",
            "3jo|3joa|3jn|3joao", "jd|jud", "ap|apo"
        };

        private static Dictionary<string, int> _map;
        private static string[] _nameKeys;

        // Data[livro][capítulo-1][versículo-1]
        public readonly List<List<List<string>>> Data = new List<List<List<string>>>();

        public Bible()
        {
            for (int i = 0; i < 66; i++) Data.Add(new List<List<string>>());
        }

        // ---------- texto ----------

        public static string Norm(string s)
        {
            if (s == null) return "";
            string d = s.ToLowerInvariant().Normalize(NormalizationForm.FormD);
            StringBuilder sb = new StringBuilder();
            foreach (char c in d)
                if (CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark) sb.Append(c);
            return sb.ToString();
        }

        private static string Key(string s)
        {
            string n = Norm(s);
            StringBuilder sb = new StringBuilder();
            foreach (char c in n)
                if (char.IsLetterOrDigit(c)) sb.Append(c);
            return sb.ToString();
        }

        private static void BuildMap()
        {
            _map = new Dictionary<string, int>();
            _nameKeys = new string[66];
            // primeiro os apelidos (assim "jo" fica sendo João e não Jó), depois os nomes completos
            for (int i = 0; i < 66; i++)
                foreach (string a in Aliases[i].Split('|')) AddKey(a, i);
            for (int i = 0; i < 66; i++)
            {
                _nameKeys[i] = Key(Names[i]);
                AddKey(Names[i], i);
            }
        }

        private static void AddKey(string alias, int i)
        {
            string k = Key(alias);
            if (k.Length > 0 && !_map.ContainsKey(k)) _map[k] = i;
        }

        // "Jó" (com acento) é o livro de Jó; "Jo" (sem acento) é João. A normalização tira os acentos,
        // então este caso é tratado antes dela.
        private static readonly Regex JoRx = new Regex(@"^\s*[jJ][óÓ](?!\p{L})", RegexOptions.Compiled);

        private static string FixJo(string q)
        {
            if (q == null) return "";
            return JoRx.Replace(q.Normalize(NormalizationForm.FormC), "job");
        }

        public static int FindBook(string token)
        {
            if (_map == null) BuildMap();
            if (token != null && JoRx.IsMatch(token.Normalize(NormalizationForm.FormC)) && token.Trim().Length <= 2) return 17;
            string k = Key(token);
            if (k.Length == 0) return -1;
            int idx;
            if (_map.TryGetValue(k, out idx)) return idx;
            // abreviação parcial: só vale se tiver 2+ letras e identificar UM livro (antes, "j" abria Josué e "ma" abria Malaquias)
            if (k.Length < 2) return -1;
            int found = -1;
            for (int b = 0; b < 66; b++)
            {
                if (!_nameKeys[b].StartsWith(k, StringComparison.Ordinal)) continue;
                if (found >= 0) return -1;
                found = b;
            }
            return found;
        }

        // ---------- consulta ----------

        public int Chapters(int b) { return b < 0 || b >= 66 ? 0 : Data[b].Count; }

        public int Verses(int b, int ch)
        {
            if (b < 0 || b >= 66 || ch < 1 || ch > Data[b].Count) return 0;
            return Data[b][ch - 1].Count;
        }

        public string Verse(int b, int ch, int v)
        {
            if (v < 1 || v > Verses(b, ch)) return "";
            return Data[b][ch - 1][v - 1];
        }

        public bool Has(int b) { return b >= 0 && b < 66 && Data[b].Count > 0; }

        // Ajusta uma referência para existir nesta versão (versões podem ter números de versículo diferentes).
        public bool Clamp(VRef r, out VRef n)
        {
            n = r;
            if (!Has(r.Book)) return false;
            int ch = Math.Max(1, Math.Min(r.Chapter, Data[r.Book].Count));
            int nv = Data[r.Book][ch - 1].Count;
            if (nv == 0) return false;
            n.Chapter = ch;
            n.From = Math.Max(1, Math.Min(r.From, nv));
            n.To = Math.Max(n.From, Math.Min(r.To, nv));
            return true;
        }

        public int TotalVerses()
        {
            int n = 0;
            foreach (List<List<string>> book in Data)
                foreach (List<string> ch in book) n += ch.Count;
            return n;
        }

        public static string RefText(VRef r)
        {
            string s = Names[r.Book] + " " + r.Chapter + ":" + r.From;
            if (r.To > r.From) s += "-" + r.To;
            return s;
        }

        public string TextOf(VRef r)
        {
            StringBuilder sb = new StringBuilder();
            for (int v = r.From; v <= r.To; v++)
            {
                string t = Verse(r.Book, r.Chapter, v);
                if (t.Length == 0) continue;
                if (sb.Length > 0) sb.Append(' ');
                if (r.To > r.From) sb.Append(v).Append(' ');
                sb.Append(t);
            }
            return sb.ToString();
        }

        private static readonly Regex RefRx = new Regex(
            @"^\s*(?:(\d)\s*)?([a-z]+)\s*(?:(\d+)(?:\s*[:.,\s]\s*(\d+)(?:\s*[-–]\s*(\d+))?)?)?\s*$",
            RegexOptions.Compiled);

        private static int Num(string s)
        {
            int v;
            return int.TryParse(s, out v) ? v : int.MaxValue;
        }

        // Entende "Jo 3:16", "joao 3 16", "1 co 13:4-7", "Salmos 23" (sem versículo = versículo 1).
        public bool Parse(string q, out VRef r)
        {
            string problem;
            return ParseEx(q, out r, out problem);
        }

        // Igual ao Parse, mas explica o problema quando o livro foi reconhecido e o número não existe
        // ("João 3 tem 36 versículos"). Capítulo ou versículo inexistente NÃO é mais "arrumado" em silêncio:
        // projetar outro versículo sem avisar seria pior do que não projetar.
        public bool ParseEx(string q, out VRef r, out string problem)
        {
            r = new VRef();
            problem = "";
            Match m = RefRx.Match(Norm(FixJo(q)));
            if (!m.Success) return false;
            int b = FindBook(m.Groups[1].Value + m.Groups[2].Value);
            if (b < 0 || !Has(b)) return false;
            int ch = m.Groups[3].Success ? Num(m.Groups[3].Value) : 1;
            int splitVerse = 0;
            // "jo316" / "jo 316" = João 3:16 (digitação rápida): se o número é maior que os capítulos do livro,
            // separa em capítulo + versículo (prefere o capítulo mais longo que exista).
            if (m.Groups[3].Success && !m.Groups[4].Success && ch > Data[b].Count && m.Groups[3].Value.Length >= 2)
            {
                string dg = m.Groups[3].Value;
                for (int cut = dg.Length - 1; cut >= 1; cut--)
                {
                    int c2 = Num(dg.Substring(0, cut)), v2 = Num(dg.Substring(cut));
                    if (c2 >= 1 && c2 <= Data[b].Count && v2 >= 1 && v2 <= Data[b][c2 - 1].Count)
                    {
                        ch = c2;
                        splitVerse = v2;
                        break;
                    }
                }
            }
            if (ch < 1 || ch > Data[b].Count)
            {
                problem = Names[b] + " tem " + Data[b].Count + " capítulo" + (Data[b].Count == 1 ? "" : "s") + ".";
                return false;
            }
            int nv = Data[b][ch - 1].Count;
            if (nv == 0)
            {
                problem = Names[b] + " " + ch + " não tem versículos nesta versão.";
                return false;
            }
            int from = 1, to = 1;
            if (splitVerse > 0) { from = splitVerse; to = splitVerse; }
            if (m.Groups[4].Success)
            {
                from = Num(m.Groups[4].Value);
                if (from < 1 || from > nv)
                {
                    problem = Names[b] + " " + ch + " tem " + nv + " versículo" + (nv == 1 ? "" : "s") + ".";
                    return false;
                }
                to = from;
                if (m.Groups[5].Success) to = Math.Max(from, Math.Min(Num(m.Groups[5].Value), nv));   // fim do intervalo além do capítulo: vai até o último
            }
            r.Book = b;
            r.Chapter = ch;
            r.From = from;
            r.To = to;
            return true;
        }

        // Um versículo antes (dir < 0) ou depois (dir > 0) da referência, passando de capítulo/livro se preciso.
        public bool Step(VRef r, int dir, out VRef n)
        {
            n = r;
            int b = r.Book, ch = r.Chapter, v;
            if (dir > 0)
            {
                v = r.To + 1;
                if (v > Verses(b, ch))
                {
                    v = 1;
                    ch++;
                    if (ch > Chapters(b))
                    {
                        ch = 1;
                        do { b++; } while (b < 66 && !Has(b));
                        if (b >= 66) return false;
                    }
                }
            }
            else
            {
                v = r.From - 1;
                if (v < 1)
                {
                    ch--;
                    if (ch < 1)
                    {
                        do { b--; } while (b >= 0 && !Has(b));
                        if (b < 0) return false;
                        ch = Chapters(b);
                    }
                    v = Verses(b, ch);
                }
            }
            n.Book = b;
            n.Chapter = ch;
            n.From = v;
            n.To = v;
            return true;
        }

        // ---------- carregar de arquivo ----------

        // Aceita JSON no formato [{"abbrev":"gn","chapters":[["versículo 1", ...], ...]}, ...] (66 livros em ordem)
        // ou texto com uma linha por versículo: "Gênesis 1:1 No princípio..."
        public static Bible LoadFile(string path, out string error)
        {
            error = "";
            try
            {
                string txt = File.ReadAllText(path, Encoding.UTF8).TrimStart('﻿', ' ', '\r', '\n', '\t');
                Bible b = new Bible();
                if (txt.StartsWith("[") || txt.StartsWith("{")) b.LoadJson(txt);
                else b.LoadText(txt);
                if (b.TotalVerses() == 0)
                {
                    error = "Não encontrei nenhum versículo nesse arquivo.";
                    return null;
                }
                return b;
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return null;
            }
        }

        // Formatos aceitos:
        //  1) [{"abbrev":"gn","chapters":[["v1","v2"],...]}, ...]   (66 livros em ordem)
        //  2) {"Gênesis":{"1":{"1":"texto"}}, ...}  ou  {"Gênesis":[["v1","v2"],...], ...}
        //  3) lista plana: [{"book":"Gênesis","chapter":1,"verse":1,"text":"..."}, ...]  (também dentro de "books"/"verses")
        private void LoadJson(string txt)
        {
            object rootObj = MiniJson.Parse(txt);
            Dictionary<string, object> rd = rootObj as Dictionary<string, object>;
            if (rd != null) { LoadJsonObject(rd); return; }
            List<object> root = rootObj as List<object>;
            if (root == null) throw new FormatException("O JSON precisa ser uma lista de livros.");
            LoadJsonList(root);
        }

        private void LoadJsonObject(Dictionary<string, object> rd)
        {
            object o;
            if (rd.TryGetValue("books", out o) && o is List<object>) { LoadJsonList((List<object>)o); return; }
            if (rd.TryGetValue("verses", out o) && o is List<object>) { LoadFlat((List<object>)o); return; }
            foreach (KeyValuePair<string, object> kv in rd)
            {
                int b = FindBook(kv.Key);
                if (b < 0) continue;
                List<object> chl = kv.Value as List<object>;
                Dictionary<string, object> chd = kv.Value as Dictionary<string, object>;
                if (chl != null)
                {
                    foreach (object co in chl) AddChapterObj(b, Data[b].Count + 1, co);
                }
                else if (chd != null)
                {
                    foreach (KeyValuePair<string, object> kv2 in chd) AddChapterObj(b, Num(kv2.Key), kv2.Value);
                }
            }
        }

        private void AddChapterObj(int b, int ch, object co)
        {
            if (ch < 1 || ch > 200) return;
            List<string> list = new List<string>();
            List<object> vl = co as List<object>;
            Dictionary<string, object> vd = co as Dictionary<string, object>;
            if (vl != null)
            {
                foreach (object vo in vl) list.Add(Clean(vo == null ? "" : vo.ToString()));
            }
            else if (vd != null)
            {
                foreach (KeyValuePair<string, object> kv in vd)
                {
                    int v = Num(kv.Key);
                    if (v < 1 || v > 400) continue;
                    while (list.Count < v) list.Add("");
                    list[v - 1] = Clean(kv.Value == null ? "" : kv.Value.ToString());
                }
            }
            while (Data[b].Count < ch) Data[b].Add(new List<string>());
            Data[b][ch - 1] = list;
        }

        private void LoadJsonList(List<object> root)
        {
            if (root.Count > 0)
            {
                Dictionary<string, object> f = root[0] as Dictionary<string, object>;
                if (f != null && f.ContainsKey("verse") && !f.ContainsKey("chapters")) { LoadFlat(root); return; }
            }
            if (root.Count != 66)
                throw new FormatException("Esperava os 66 livros da Bíblia em ordem, mas o arquivo tem " + root.Count +
                                          ". Importe uma versão completa.");
            for (int i = 0; i < root.Count && i < 66; i++)
            {
                List<object> chapters = root[i] as List<object>;
                Dictionary<string, object> d = root[i] as Dictionary<string, object>;
                if (d != null && d.ContainsKey("chapters")) chapters = d["chapters"] as List<object>;
                if (chapters == null) continue;
                foreach (object co in chapters) AddChapterObj(i, Data[i].Count + 1, co);
            }
        }

        private void LoadFlat(List<object> items)
        {
            string[] bookKeys = new string[] { "book_id", "book", "book_name", "bookname", "livro", "name" };
            foreach (object it in items)
            {
                Dictionary<string, object> d = it as Dictionary<string, object>;
                if (d == null) continue;
                int b = -1;
                foreach (string k in bookKeys)
                {
                    object bo;
                    if (!d.TryGetValue(k, out bo) || bo == null) continue;
                    int n;
                    string bs = bo.ToString();
                    if (int.TryParse(bs, out n)) { if (n >= 1 && n <= 66) b = n - 1; }
                    else b = FindBook(bs);
                    if (b >= 0) break;
                }
                object co, vo, to;
                if (b < 0 || !d.TryGetValue("chapter", out co) || !d.TryGetValue("verse", out vo)) continue;
                if (!d.TryGetValue("text", out to)) continue;
                int ch = Num(co.ToString()), v = Num(vo.ToString());
                if (ch < 1 || ch > 200 || v < 1 || v > 400) continue;
                while (Data[b].Count < ch) Data[b].Add(new List<string>());
                List<string> list = Data[b][ch - 1];
                while (list.Count < v) list.Add("");
                list[v - 1] = Clean(to == null ? "" : to.ToString());
            }
        }

        private static string Clean(string s)
        {
            return s.Replace("{", "").Replace("}", "").Trim();
        }

        private void LoadText(string txt)
        {
            Regex rx = new Regex(@"^\s*((?:[123]\s*)?[^\d:]+?)\s+(\d+)[:.](\d+)\s+(.+)$", RegexOptions.Compiled);
            foreach (string line in txt.Split('\n'))
            {
                Match m = rx.Match(line.TrimEnd('\r'));
                if (!m.Success) continue;
                int b = FindBook(m.Groups[1].Value);
                if (b < 0) continue;
                int ch = Num(m.Groups[2].Value), v = Num(m.Groups[3].Value);
                if (ch < 1 || ch > 200 || v < 1 || v > 400) continue;
                while (Data[b].Count < ch) Data[b].Add(new List<string>());
                List<string> list = Data[b][ch - 1];
                while (list.Count < v) list.Add("");
                list[v - 1] = Clean(m.Groups[4].Value);
            }
        }
    }

    // Biblioteca de versões: cada versão é um arquivo SIGLA.json ou SIGLA.txt.
    //  - pasta "biblias" ao lado do programa (versões que acompanham o pacote, ex.: ACF)
    //  - pasta %AppData%\NovoAmanhaVersiculos\biblias (versões que você importou, ex.: NVT, NTLH)
    internal static class BibleLib
    {
        public static string UserDir
        {
            get
            {
                string d = Path.Combine(Config.DataDir, "biblias");
                try { Directory.CreateDirectory(d); }
                catch { }
                return d;
            }
        }

        public static string AppDir
        {
            get { return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "biblias"); }
        }

        public static string SafeSigla(string s)
        {
            StringBuilder sb = new StringBuilder();
            foreach (char c in (s ?? "").ToUpperInvariant())
                if (char.IsLetterOrDigit(c) || c == '-' || c == '_') sb.Append(c);
            if (sb.Length > 12) sb.Length = 12;
            return sb.ToString();
        }

        private static void Collect(string dir, Dictionary<string, string> into)
        {
            try
            {
                if (!Directory.Exists(dir)) return;
                foreach (string f in Directory.GetFiles(dir))
                {
                    string ext = Path.GetExtension(f).ToLowerInvariant();
                    if (ext != ".json" && ext != ".txt") continue;
                    string sg = SafeSigla(Path.GetFileNameWithoutExtension(f));
                    if (sg.Length > 0) into[sg] = f;
                }
            }
            catch { }
        }

        // sigla -> arquivo (as importadas por você vencem as do pacote quando a sigla é igual)
        public static Dictionary<string, string> All()
        {
            Dictionary<string, string> d = new Dictionary<string, string>();
            Collect(AppDir, d);
            Collect(UserDir, d);
            return d;
        }

        public static List<string> Names()
        {
            List<string> l = new List<string>(All().Keys);
            l.Sort(StringComparer.OrdinalIgnoreCase);
            return l;
        }

        public static bool IsUser(string sigla)
        {
            Dictionary<string, string> d = new Dictionary<string, string>();
            Collect(UserDir, d);
            return d.ContainsKey(sigla);
        }

        public static bool Exists(string sigla) { return All().ContainsKey(sigla); }

        public static Bible Load(string sigla, out string error)
        {
            error = "";
            string p;
            if (!All().TryGetValue(sigla, out p)) { error = "Versão não encontrada."; return null; }
            return Bible.LoadFile(p, out error);
        }

        // Confere o arquivo e guarda uma cópia como SIGLA.json/.txt na pasta do usuário.
        public static bool Import(string src, string sigla, out string error)
        {
            Bible b = Bible.LoadFile(src, out error);
            if (b == null) return false;
            try
            {
                string ext = Path.GetExtension(src).ToLowerInvariant() == ".txt" ? ".txt" : ".json";
                foreach (string e in new string[] { ".json", ".txt" })
                {
                    string old = Path.Combine(UserDir, sigla + e);
                    if (File.Exists(old)) File.Delete(old);
                }
                File.Copy(src, Path.Combine(UserDir, sigla + ext), true);
                return true;
            }
            catch (Exception ex) { error = ex.Message; return false; }
        }

        public static bool Remove(string sigla)
        {
            bool any = false;
            try
            {
                foreach (string e in new string[] { ".json", ".txt" })
                {
                    string p = Path.Combine(UserDir, sigla + e);
                    if (File.Exists(p)) { File.Delete(p); any = true; }
                }
            }
            catch { }
            return any;
        }
    }

    // Leitor de JSON mínimo (listas, objetos e textos), sem depender de outras bibliotecas.
    internal static class MiniJson
    {
        private static int _depth;

        public static object Parse(string s)
        {
            int i = 0;
            _depth = 0;
            return Val(s, ref i);
        }

        private static void Ws(string s, ref int i)
        {
            while (i < s.Length && (char.IsWhiteSpace(s[i]) || s[i] == '﻿')) i++;
        }

        // Limite de aninhamento: um arquivo malicioso com milhares de "[" travaria o programa por estouro de pilha.
        private static object Val(string s, ref int i)
        {
            if (++_depth > 64)
            {
                _depth = 0;
                throw new FormatException("JSON aninhado demais.");
            }
            try { return ValInner(s, ref i); }
            finally { if (_depth > 0) _depth--; }
        }

        private static object ValInner(string s, ref int i)
        {
            Ws(s, ref i);
            if (i >= s.Length) throw new FormatException("JSON incompleto.");
            char c = s[i];
            if (c == '[')
            {
                i++;
                List<object> l = new List<object>();
                Ws(s, ref i);
                if (i < s.Length && s[i] == ']') { i++; return l; }
                while (true)
                {
                    l.Add(Val(s, ref i));
                    Ws(s, ref i);
                    if (i >= s.Length) throw new FormatException("JSON incompleto.");
                    if (s[i] == ',') { i++; continue; }
                    if (s[i] == ']') { i++; return l; }
                    throw new FormatException("JSON inválido na posição " + i + ".");
                }
            }
            if (c == '{')
            {
                i++;
                Dictionary<string, object> d = new Dictionary<string, object>();
                Ws(s, ref i);
                if (i < s.Length && s[i] == '}') { i++; return d; }
                while (true)
                {
                    Ws(s, ref i);
                    if (i >= s.Length || s[i] != '"') throw new FormatException("JSON inválido na posição " + i + ".");
                    string key = Str(s, ref i);
                    Ws(s, ref i);
                    if (i >= s.Length || s[i] != ':') throw new FormatException("JSON inválido na posição " + i + ".");
                    i++;
                    d[key] = Val(s, ref i);
                    Ws(s, ref i);
                    if (i >= s.Length) throw new FormatException("JSON incompleto.");
                    if (s[i] == ',') { i++; continue; }
                    if (s[i] == '}') { i++; return d; }
                    throw new FormatException("JSON inválido na posição " + i + ".");
                }
            }
            if (c == '"') return Str(s, ref i);
            int st = i;
            while (i < s.Length && ",]} \t\r\n".IndexOf(s[i]) < 0) i++;
            string tok = s.Substring(st, i - st);
            return tok == "null" ? null : tok;   // antes o null virava o texto "null" e aparecia no projetor
        }

        private static string Str(string s, ref int i)
        {
            i++;   // aspas de abertura
            StringBuilder sb = new StringBuilder();
            while (i < s.Length)
            {
                char c = s[i++];
                if (c == '"') return sb.ToString();
                if (c == '\\' && i < s.Length)
                {
                    char e = s[i++];
                    switch (e)
                    {
                        case 'n': sb.Append('\n'); break;
                        case 't': sb.Append('\t'); break;
                        case 'r': sb.Append('\r'); break;
                        case 'b': sb.Append('\b'); break;
                        case 'f': sb.Append('\f'); break;
                        case 'u':
                            if (i + 4 <= s.Length)
                            {
                                sb.Append((char)Convert.ToInt32(s.Substring(i, 4), 16));
                                i += 4;
                            }
                            break;
                        default: sb.Append(e); break;
                    }
                }
                else sb.Append(c);
            }
            throw new FormatException("Texto sem fim no JSON.");
        }
    }
}
