using System;
using System.Drawing;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Versiculos
{
    // Configurações salvas em %AppData%\NovoAmanhaVersiculos\config.ini
    internal class Config
    {
        public string ScreenName = "";                 // vazio = automática (primeira tela extra)
        public int MaxFont = 130;                      // tamanho máximo da letra (em 1080p)
        public int TextColor = Color.White.ToArgb();
        public int BgColor = Color.Black.ToArgb();
        public string BgPath = "";
        public string FontName = "Georgia";
        public bool Shadow = true;
        public bool ShowRef = true;
        public bool QuickAutoEnter = true;             // atalho rápido: dá Enter sozinho ao completar o versículo
        public string Version = "";                    // (antigo) só usado para migrar a Bíblia importada nas versões anteriores
        public string ActiveBible = "";                // sigla da versão ativa (ex.: NVT, NTLH, ACF)

        // ---- atalhos do teclado (configuráveis) ----
        public static readonly string[] ActionIds = new string[]
            { "project", "next", "prev", "vernext", "verprev", "black" };
        public static readonly string[] ActionNames = new string[]
            { "Projetar / limpar (alterna)", "Próximo versículo", "Versículo anterior",
              "Próxima versão da Bíblia", "Versão anterior da Bíblia", "Tela preta (liga/desliga)" };

        public static Keys DefaultKey(string id)
        {
            switch (id)
            {
                case "project": return Keys.Control | Keys.Space;
                case "next": return Keys.PageDown;
                case "prev": return Keys.PageUp;
                case "vernext": return Keys.F4;
                case "verprev": return Keys.F3;
                case "black": return Keys.F6;
            }
            return Keys.None;
        }

        public Dictionary<string, Keys> KeyMap = new Dictionary<string, Keys>();

        public Keys KeyFor(string id)
        {
            Keys k;
            return KeyMap.TryGetValue(id, out k) ? k : DefaultKey(id);
        }

        public string ActionFor(Keys data)
        {
            foreach (string id in ActionIds) if (KeyFor(id) == data) return id;
            return null;
        }

        public void ResetKeys() { KeyMap.Clear(); }

        public static string KeyText(Keys k)
        {
            try { return new KeysConverter().ConvertToString(k); }
            catch { return k.ToString(); }
        }

        // Teclas soltas (sem Ctrl/Alt/Shift) só valem se não atrapalharem a digitação.
        public static bool KeyAllowed(Keys k)
        {
            Keys code = k & Keys.KeyCode;
            Keys mods = k & Keys.Modifiers;
            if (code == Keys.ControlKey || code == Keys.ShiftKey || code == Keys.Menu || code == Keys.None) return false;
            if (code == Keys.Return || code == Keys.Tab) return false;
            if (mods == Keys.None)
            {
                if (code >= Keys.F1 && code <= Keys.F24) return true;
                return code == Keys.Escape || code == Keys.PageUp || code == Keys.PageDown ||
                       code == Keys.Home || code == Keys.End || code == Keys.Insert || code == Keys.Pause;
            }
            if (mods == Keys.Control &&
                (code == Keys.A || code == Keys.C || code == Keys.V || code == Keys.X || code == Keys.Z || code == Keys.Y))
                return false;
            if (mods == Keys.Control && code == Keys.Space) return true;
            if (mods == Keys.Shift && !(code >= Keys.F1 && code <= Keys.F24)) return false;
            return true;
        }

        public static string DataDir
        {
            get
            {
                string d = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "NovoAmanhaVersiculos");
                try { Directory.CreateDirectory(d); }
                catch { }
                return d;
            }
        }

        private static string FilePath { get { return Path.Combine(DataDir, "config.ini"); } }

        public static Config Load()
        {
            Config c = new Config();
            try
            {
                if (!File.Exists(FilePath)) return c;
                foreach (string line in File.ReadAllLines(FilePath, Encoding.UTF8))
                {
                    int i = line.IndexOf('=');
                    if (i <= 0) continue;
                    string k = line.Substring(0, i).Trim();
                    string v = line.Substring(i + 1);
                    int n;
                    switch (k)
                    {
                        case "screen": c.ScreenName = v; break;
                        case "max_font": if (int.TryParse(v, out n)) c.MaxFont = Math.Max(30, Math.Min(300, n)); break;
                        case "text_color": if (int.TryParse(v, out n)) c.TextColor = n; break;
                        case "bg_color": if (int.TryParse(v, out n)) c.BgColor = n; break;
                        case "bg_path": c.BgPath = v; break;
                        case "font": if (v.Length > 0) c.FontName = v; break;
                        case "shadow": c.Shadow = v == "1"; break;
                        case "show_ref": c.ShowRef = v == "1"; break;
                        case "quick_auto": c.QuickAutoEnter = v != "0"; break;
                        case "version": c.Version = v; break;
                        case "active_bible": c.ActiveBible = v; break;
                        default:
                            if (k.StartsWith("key_") && int.TryParse(v, out n))
                                c.KeyMap[k.Substring(4)] = (Keys)n;
                            break;
                    }
                }
            }
            catch { }
            return c;
        }

        public void Save()
        {
            try
            {
                List<string> lines = new List<string>(new string[]
                {
                    "screen=" + ScreenName,
                    "max_font=" + MaxFont,
                    "text_color=" + TextColor,
                    "bg_color=" + BgColor,
                    "bg_path=" + BgPath,
                    "font=" + FontName,
                    "shadow=" + (Shadow ? "1" : "0"),
                    "show_ref=" + (ShowRef ? "1" : "0"),
                    "quick_auto=" + (QuickAutoEnter ? "1" : "0"),
                    "active_bible=" + ActiveBible
                });
                foreach (KeyValuePair<string, Keys> kv in KeyMap) lines.Add("key_" + kv.Key + "=" + (int)kv.Value);
                string tmp = FilePath + ".tmp";
                File.WriteAllLines(tmp, lines.ToArray(), Encoding.UTF8);
                if (File.Exists(FilePath)) File.Replace(tmp, FilePath, null);
                else File.Move(tmp, FilePath);
            }
            catch (Exception ex)
            {
                try { File.AppendAllText(Path.Combine(DataDir, "erros.log"),
                    DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "  Não consegui salvar a configuração: " + ex.Message + "\r\n"); }
                catch { }
            }
        }
    }
}
