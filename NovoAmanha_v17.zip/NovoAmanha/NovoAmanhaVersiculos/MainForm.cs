using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;

namespace Versiculos
{
    internal static class Theme
    {
        public static readonly Color Bg = Color.FromArgb(5, 8, 18);
        public static readonly Color Card = Color.FromArgb(14, 20, 38);
        public static readonly Color Text = Color.FromArgb(222, 236, 255);
        public static readonly Color Muted = Color.FromArgb(120, 140, 176);
        public static readonly Color Accent = Color.FromArgb(0, 226, 255);
        public static readonly Color Good = Color.FromArgb(70, 255, 170);
        public static readonly Color Warn = Color.FromArgb(255, 190, 40);
        public static readonly Color Edge = Color.FromArgb(40, 74, 120);
    }

    // Grade desenhada à mão: preenche toda a área (sem rolagem), escolhe sozinha colunas/linhas
    // para os quadrados ficarem o maior possível e se adapta a qualquer tamanho de janela.
    internal class GridView : Control
    {
        public string[] Texts = new string[0];
        public string[] Subs;
        public Color[] Colors;
        public int Sel = -1, SelTo = -1;
        public int FixedCols = 0;
        public event Action<int, bool> CellClick;
        public event Action<int> CellDouble;
        private int _cols = 1, _rows = 1, _hot = -1;

        public GridView()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
            BackColor = Theme.Bg;
            TabStop = false;
            Cursor = Cursors.Hand;
        }

        public void SetData(string[] t, string[] s, Color[] c)
        {
            Texts = t ?? new string[0];
            Subs = s;
            Colors = c;
            Sel = -1; SelTo = -1; _hot = -1;
            Relayout();
            Invalidate();
        }

        private void Relayout()
        {
            int n = Texts.Length;
            if (n == 0 || Width < 2 || Height < 2) { _cols = 1; _rows = 1; return; }
            if (FixedCols > 0) { _cols = FixedCols; _rows = (n + _cols - 1) / _cols; return; }
            int best = 1; double bestScore = -1;
            for (int c = 1; c <= n; c++)
            {
                int r = (n + c - 1) / c;
                double cw = (double)Width / c, ch = (double)Height / r;
                double mn = Math.Min(cw, ch), mx = Math.Max(cw, ch);
                double sc = mn * (0.7 + 0.3 * mn / mx);
                if (sc > bestScore) { bestScore = sc; best = c; }
            }
            _cols = best;
            _rows = (n + best - 1) / best;
        }

        protected override void OnResize(EventArgs e) { base.OnResize(e); Relayout(); Invalidate(); }

        private Rectangle CellRect(int i)
        {
            int col = i % _cols, row = i / _cols;
            int x0 = col * Width / _cols, x1 = (col + 1) * Width / _cols;
            int y0 = row * Height / _rows, y1 = (row + 1) * Height / _rows;
            return new Rectangle(x0, y0, x1 - x0, y1 - y0);
        }

        private int Hit(Point p)
        {
            for (int i = 0; i < Texts.Length; i++) if (CellRect(i).Contains(p)) return i;
            return -1;
        }

        private static Color Lighten(Color c, int a)
        {
            return Color.FromArgb(Math.Min(255, c.R + a), Math.Min(255, c.G + a), Math.Min(255, c.B + a));
        }

        private static Color Darken(Color c, float f)
        {
            return Color.FromArgb((int)(c.R * f), (int)(c.G * f), (int)(c.B * f));
        }

        private static GraphicsPath Round(Rectangle r, int rad)
        {
            GraphicsPath p = new GraphicsPath();
            int d = rad * 2;
            p.AddArc(r.X, r.Y, d, d, 180, 90);
            p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            p.CloseFigure();
            return p;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Theme.Bg);
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            int n = Texts.Length;
            int lo = Sel < 0 ? 0 : Math.Min(Sel, SelTo < 0 ? Sel : SelTo);
            int hi = Sel < 0 ? -1 : Math.Max(Sel, SelTo < 0 ? Sel : SelTo);
            using (StringFormat sf = new StringFormat())
            {
                sf.Alignment = StringAlignment.Center;
                sf.LineAlignment = StringAlignment.Center;
                sf.FormatFlags = StringFormatFlags.NoWrap;
                sf.Trimming = StringTrimming.None;
                for (int i = 0; i < n; i++)
                {
                    Rectangle r = CellRect(i);
                    r = new Rectangle(r.X + 1, r.Y + 1, r.Width - 2, r.Height - 2);
                    if (r.Width < 4 || r.Height < 4) continue;
                    bool sel = i >= lo && i <= hi;
                    Color bc = (Colors != null && i < Colors.Length) ? Colors[i] : Theme.Card;
                    if (sel) bc = Lighten(bc, 60); else if (i == _hot) bc = Lighten(bc, 28);
                    int rad = Math.Max(2, Math.Min(7, Math.Min(r.Width, r.Height) / 6));
                    using (GraphicsPath gp = Round(r, rad))
                    {
                        using (LinearGradientBrush lb = new LinearGradientBrush(r, Lighten(bc, 16), Darken(bc, 0.8f), 90f))
                            g.FillPath(lb, gp);
                        using (Pen pen = new Pen(sel ? Color.White : Color.FromArgb(70, 255, 255, 255), sel ? 2f : 1f))
                            g.DrawPath(pen, gp);
                    }
                    string t = Texts[i];
                    bool two = Subs != null && i < Subs.Length && !string.IsNullOrEmpty(Subs[i]);
                    if (two)
                    {
                        float fs = Math.Max(11f, Math.Min(r.Height * 0.52f, r.Width * 0.46f));
                        float ss = Math.Max(9f, Math.Min(r.Height * 0.27f, r.Width * 0.21f));
                        using (Font f0 = new Font("Segoe UI", fs, FontStyle.Bold, GraphicsUnit.Pixel))
                        {
                            float w0 = g.MeasureString(t, f0, 10000, StringFormat.GenericTypographic).Width;
                            if (w0 > r.Width - 6 && w0 > 0) fs = Math.Max(8f, fs * (r.Width - 6) / w0);
                        }
                        using (Font f = new Font("Segoe UI", fs, FontStyle.Bold, GraphicsUnit.Pixel))
                            Outlined(g, t, f, new RectangleF(r.X, r.Y + r.Height * 0.01f, r.Width, r.Height * 0.60f), sf, Math.Max(1f, fs / 16f));
                        string sub = Subs[i];
                        using (Font f0 = new Font("Segoe UI", ss, FontStyle.Bold, GraphicsUnit.Pixel))
                        {
                            float w = g.MeasureString(sub, f0).Width;
                            float k = w > r.Width - 4 ? (r.Width - 4) / w : 1f;
                            using (Font f = new Font("Segoe UI", Math.Max(8f, ss * k), FontStyle.Bold, GraphicsUnit.Pixel))
                                Outlined(g, sub, f, new RectangleF(r.X, r.Y + r.Height * 0.58f, r.Width, r.Height * 0.40f), sf, 1f);
                        }
                    }
                    else
                    {
                        float fs = Math.Max(6f, r.Height * 0.46f);
                        // encolhe até o número caber inteiro no quadradinho (ex.: 119, 150)
                        using (Font f0 = new Font("Segoe UI", fs, FontStyle.Bold, GraphicsUnit.Pixel))
                        {
                            float w = g.MeasureString(t, f0, 10000, StringFormat.GenericTypographic).Width;
                            float lim = r.Width - 6;
                            if (w > lim && w > 0) fs = Math.Max(5f, fs * lim / w);
                        }
                        using (Font f = new Font("Segoe UI", fs, FontStyle.Bold, GraphicsUnit.Pixel))
                            g.DrawString(t, f, Brushes.White, r, sf);
                    }
                }
            }
        }

        // texto branco com contorno escuro: legível sobre qualquer cor
        private static void Outlined(Graphics g, string t, Font f, RectangleF rc, StringFormat sf, float o)
        {
            using (SolidBrush sh = new SolidBrush(Color.FromArgb(190, 0, 0, 0)))
            {
                g.DrawString(t, f, sh, new RectangleF(rc.X - o, rc.Y, rc.Width, rc.Height), sf);
                g.DrawString(t, f, sh, new RectangleF(rc.X + o, rc.Y, rc.Width, rc.Height), sf);
                g.DrawString(t, f, sh, new RectangleF(rc.X, rc.Y - o, rc.Width, rc.Height), sf);
                g.DrawString(t, f, sh, new RectangleF(rc.X, rc.Y + o, rc.Width, rc.Height), sf);
                g.DrawString(t, f, sh, new RectangleF(rc.X + o, rc.Y + o, rc.Width, rc.Height), sf);
            }
            g.DrawString(t, f, Brushes.White, rc, sf);
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            int h = Hit(e.Location);
            if (h != _hot) { _hot = h; Invalidate(); }
            base.OnMouseMove(e);
        }

        protected override void OnMouseLeave(EventArgs e) { _hot = -1; Invalidate(); base.OnMouseLeave(e); }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            if (e.Button != MouseButtons.Left) return;
            int h = Hit(e.Location);
            if (h >= 0 && CellClick != null) CellClick(h, (Control.ModifierKeys & Keys.Shift) != 0);
        }

        protected override void OnMouseDoubleClick(MouseEventArgs e)
        {
            base.OnMouseDoubleClick(e);
            int h = Hit(e.Location);
            if (h >= 0 && CellDouble != null) CellDouble(h);
        }
    }

    // Painel de controle (no notebook): escolhe o versículo e manda para a tela compartilhada.
    internal class MainForm : Form
    {
        private readonly Config _cfg;
        private Bible _bible = new Bible();
        private readonly Dictionary<string, Bible> _cache = new Dictionary<string, Bible>();
        private string _active = "";
        private ComboBox _cmbVer;
        private bool _busyVer, _liveOn, _syncBox;
        private Button _btnProjTop, _btnPrev, _btnNext, _btnProj, _btnClear, _btnCfg;
        private Label _lblHelp, _lblRef, _lblVer, _lblChap;
        private ProjectionForm _proj;
        private readonly TextBox _q = new TextBox();
        private GridView _gBooks, _gChaps, _gVerses;
        private ListBox _vlist;
        private Font _vfont = new Font("Segoe UI", 13f);
        private int _lastListW = -1;
        private readonly List<int> _bookIdx = new List<int>();
        private int _selBook = -1, _selChap = -1, _selVerseFrom = -1, _selVerseTo = -1;
        private SlideView _selView, _liveView;
        private Label _status;
        private VRef _cur, _live;
        private bool _hasCur, _hasLive, _busy;

        public MainForm()
        {
            _cfg = Config.Load();

            Text = "Novo Amanhã - Versículos v17";
            FormBorderStyle = FormBorderStyle.Sizable;
            MaximizeBox = true;
            MinimumSize = new Size(900, 560);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Theme.Bg;
            ForeColor = Theme.Text;
            AutoScaleMode = AutoScaleMode.None;
            DoubleBuffered = true;
            ClientSize = new Size(1182, 730);
            KeyPreview = true;

            BuildUi();
            DoLayout();
            SizeChanged += delegate { DoLayout(); };

            _proj = new ProjectionForm(_cfg);
            PlaceProjection();

            LoadBibleAuto();
            SystemEvents.DisplaySettingsChanged += OnDisplayChanged;
            UpdatePreview();
        }

        // ---------- montagem da tela ----------

        private Label Lbl(string text, int x, int y, int w, int h, Color col, float size, bool bold)
        {
            Label l = new Label();
            l.AutoSize = false;
            l.Text = text;
            l.Font = new Font("Segoe UI", size, bold ? FontStyle.Bold : FontStyle.Regular);
            l.ForeColor = col;
            l.BackColor = Theme.Bg;
            l.SetBounds(x, y, w, h);
            Controls.Add(l);
            return l;
        }

        private Button Btn(string text, int x, int y, int w, int h, EventHandler click)
        {
            Button b = new Button();
            b.Text = text;
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderColor = Theme.Accent;
            b.FlatAppearance.BorderSize = 1;
            b.Font = new Font("Segoe UI", 10f);
            b.ForeColor = Theme.Text;
            b.BackColor = Theme.Card;
            b.Cursor = Cursors.Hand;
            b.TabStop = false;
            b.SetBounds(x, y, w, h);
            b.Click += click;
            Controls.Add(b);
            return b;
        }

        // Cores por grupo (mesma divisão do Holyrics)
        private static Color GetBookColor(int b)
        {
            if (b <= 4)  return Color.FromArgb(140, 92, 48);    // Pentateuco
            if (b <= 16) return Color.FromArgb(226, 140, 28);   // Históricos
            if (b <= 21) return Color.FromArgb(214, 44, 48);    // Poéticos
            if (b <= 38) return Color.FromArgb(150, 62, 172);   // Profetas
            if (b <= 42) return Color.FromArgb(54, 70, 156);    // Evangelhos
            if (b == 43) return Color.FromArgb(0, 150, 190);    // Atos
            if (b <= 64) return Color.FromArgb(28, 150, 92);    // Epístolas
            return Color.FromArgb(140, 180, 36);                // Apocalipse
        }

        private static Color Dark(Color c, float f)
        {
            return Color.FromArgb((int)(c.R * f), (int)(c.G * f), (int)(c.B * f));
        }

        private static readonly string[] BookShort = new string[]
        {
            "Gn","Ex","Lv","Nm","Dt","Js","Jz","Rt",
            "1Sm","2Sm","1Rs","2Rs","1Cr","2Cr","Ed","Ne","Et",
            "Jó","Sl","Pv","Ec","Ct","Is","Jr","Lm",
            "Ez","Dn","Os","Jl","Am","Ob","Jn","Mq","Na","Hc",
            "Sf","Ag","Zc","Ml",
            "Mt","Mc","Lc","Jo","At","Rm","1Co","2Co","Gl",
            "Ef","Fp","Cl","1Ts","2Ts","1Tm",
            "2Tm","Tt","Fm","Hb","Tg","1Pe","2Pe","1Jo","2Jo",
            "3Jo","Jd","Ap"
        };

        private void BuildUi()
        {
            _lblRef = Lbl("REFERÊNCIA", 0, 0, 100, 18, Theme.Accent, 9f, true);
            _q.Font = new Font("Segoe UI", 16f);
            _q.BackColor = Theme.Card;
            _q.ForeColor = Theme.Text;
            _q.BorderStyle = BorderStyle.FixedSingle;
            _lblRef.Visible = false;   // campo de referência removido (atrapalhava o atalho rápido)
            _lblVer = Lbl("VERSÃO", 0, 0, 100, 18, Theme.Accent, 9f, true);
            _cmbVer = new ComboBox();
            _cmbVer.DropDownStyle = ComboBoxStyle.DropDownList;
            _cmbVer.Font = new Font("Segoe UI", 14f);
            _cmbVer.BackColor = Theme.Card;
            _cmbVer.ForeColor = Theme.Text;
            _cmbVer.FlatStyle = FlatStyle.Flat;
            _cmbVer.SelectedIndexChanged += delegate
            {
                if (_busyVer || _cmbVer.SelectedItem == null) return;
                SwitchVersion(_cmbVer.SelectedItem.ToString());
                _gBooks.Focus();
            };
            Controls.Add(_cmbVer);
            _btnProjTop = Btn("Projetar", 0, 0, 100, 34, delegate { ProjectCur(); });
            _btnCfg = Btn("Configurações...", 0, 0, 100, 34, delegate { OpenSettings(); });
            _status = Lbl("", 0, 0, 100, 34, Theme.Muted, 9f, false);
            _status.TextAlign = ContentAlignment.MiddleLeft;

            // texto do capítulo (esquerda)
            _lblChap = Lbl("", 0, 0, 100, 32, Theme.Warn, 15f, true);
            _lblChap.TextAlign = ContentAlignment.MiddleCenter;
            _vlist = new ListBox();
            _vlist.DrawMode = DrawMode.OwnerDrawVariable;
            _vlist.SelectionMode = SelectionMode.None;
            _vlist.BorderStyle = BorderStyle.None;
            _vlist.BackColor = Theme.Card;
            _vlist.IntegralHeight = false;
            _vlist.MeasureItem += delegate(object s, MeasureItemEventArgs e)
            {
                if (e.Index < 0 || e.Index >= _vlist.Items.Count) return;
                SizeF sz = e.Graphics.MeasureString((string)_vlist.Items[e.Index], _vfont, Math.Max(50, _vlist.ClientSize.Width - 28));
                e.ItemHeight = Math.Max(30, (int)Math.Ceiling(sz.Height) + 14);
            };
            _vlist.DrawItem += DrawVerseItem;
            _vlist.MouseDown += delegate(object s, MouseEventArgs e)
            {
                int i = _vlist.IndexFromPoint(e.Location);
                if (i < 0 || _selBook < 0) return;
                int v = i + 1;
                if ((Control.ModifierKeys & Keys.Shift) != 0 && _selVerseFrom > 0)
                    Navigate(_selBook, _selChap, Math.Min(_selVerseFrom, v), Math.Max(_selVerseFrom, v));
                else Navigate(_selBook, _selChap, v, v);
            };
            _vlist.MouseDoubleClick += delegate { ProjectCur(); };
            Controls.Add(_vlist);

            // grades (direita): livros, capítulos, versículos
            _gBooks = new GridView();
            _gBooks.CellClick += delegate(int i, bool sh) { Navigate(i, 0, 1, 1); };
            _gBooks.CellDouble += delegate(int i) { };
            _gChaps = new GridView();
            _gChaps.CellClick += delegate(int i, bool sh) { Navigate(_selBook, i, 1, 1); };
            _gVerses = new GridView();
            _gVerses.CellClick += delegate(int i, bool sh)
            {
                int v = i + 1;
                if (sh && _selVerseFrom > 0) Navigate(_selBook, _selChap, Math.Min(_selVerseFrom, v), Math.Max(_selVerseFrom, v));
                else Navigate(_selBook, _selChap, v, v);
            };
            _gVerses.CellDouble += delegate(int i) { ProjectCur(); };
            Controls.Add(_gBooks);
            Controls.Add(_gChaps);
            Controls.Add(_gVerses);

            // barra de controle ao vivo
            _btnPrev  = Btn("", 0, 0, 100, 46, delegate { StepLive(-1); });
            _btnNext  = Btn("", 0, 0, 100, 46, delegate { StepLive(1); });
            _btnProj  = Btn("", 0, 0, 100, 46, delegate { ProjectCur(); });
            _btnClear = Btn("", 0, 0, 100, 46, delegate { ClearLive(); });
            foreach (Button b in new Button[] { _btnPrev, _btnNext, _btnProj, _btnClear })
                b.Font = new Font("Segoe UI", 9.5f, FontStyle.Bold);

            _selView = new SlideView(_cfg, false);   // prévia interna (não aparece)
            _liveView = new SlideView(_cfg, true);
            Controls.Add(_liveView);
            _lblHelp = Lbl("", 0, 0, 100, 20, Theme.Muted, 8.5f, false);
            _lblHelp.AutoEllipsis = true;

            RefreshKeyLabels();
        }

        // Tudo se ajusta ao tamanho da janela; as grades nunca rolam.
        private void DoLayout()
        {
            if (_gBooks == null) return;
            int W = ClientSize.Width, H = ClientSize.Height, m = 10;
            if (W < 300 || H < 300) return;
            SuspendLayout();
            int x = m;
            int qw = Math.Max(160, W * 22 / 100);
            _lblRef.SetBounds(x, 6, qw, 18);
            _q.SetBounds(x, 26, qw, 34);
            _lblVer.SetBounds(x, 6, 100, 18);
            _cmbVer.SetBounds(x, 26, 132, 34);
            x += 140;
            _btnProjTop.SetBounds(x, 26, 210, 34);
            x += 218;
            _btnCfg.SetBounds(x, 26, 140, 34);
            x += 148;
            _status.SetBounds(x, 26, Math.Max(0, W - x - m), 34);

            int top = 70, barH = 46, helpH = 20;
            int barY = H - m - helpH - barH - 4;
            int bodyH = barY - 8 - top;
            int lw = Math.Max(240, Math.Min(W * 36 / 100, W - 420));
            _lblChap.SetBounds(m, top, lw, 32);
            _vlist.SetBounds(m, top + 34, lw, Math.Max(20, bodyH - 34));
            if (_lastListW != lw) { _lastListW = lw; FillVerseList(); }

            int rx = m + lw + m, rw = W - rx - m;
            int booksH = bodyH * 50 / 100;
            _gBooks.SetBounds(rx, top, rw, booksH);
            int lowY = top + booksH + 6, lowH = bodyH - booksH - 6;
            int cw = rw * 46 / 100;
            _gChaps.SetBounds(rx, lowY, cw, lowH);
            _gVerses.SetBounds(rx + cw + 6, lowY, rw - cw - 6, lowH);

            int liveW = barH * 16 / 9;
            int area = W - 2 * m - liveW - 8, gap = 6;
            int bw = (area - 3 * gap) / 4;
            Button[] bs = new Button[] { _btnPrev, _btnNext, _btnProj, _btnClear };
            for (int i = 0; i < 4; i++) bs[i].SetBounds(m + i * (bw + gap), barY, bw, barH);
            _liveView.SetBounds(W - m - liveW, barY, liveW, barH);
            _lblHelp.SetBounds(m, H - m - helpH, W - 2 * m, helpH);
            ResumeLayout();
        }

        private void DrawVerseItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0 || e.Index >= _vlist.Items.Count) return;
            Graphics g = e.Graphics;
            int v = e.Index + 1;
            bool sel = _selVerseFrom > 0 && v >= _selVerseFrom && v <= _selVerseTo;
            Rectangle r = e.Bounds;
            using (SolidBrush b = new SolidBrush(sel ? Color.FromArgb(24, 62, 112) : Theme.Card))
                g.FillRectangle(b, r);
            if (sel) using (SolidBrush b = new SolidBrush(Theme.Accent)) g.FillRectangle(b, r.X, r.Y, 4, r.Height);
            using (Pen p = new Pen(Color.FromArgb(34, 46, 74)))
                g.DrawLine(p, r.X, r.Bottom - 1, r.Right, r.Bottom - 1);
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            using (SolidBrush tb = new SolidBrush(sel ? Color.White : Theme.Text))
                g.DrawString((string)_vlist.Items[e.Index], _vfont, tb,
                    new RectangleF(r.X + 12, r.Y + 6, r.Width - 24, r.Height - 8));
        }

        // Textos dos botões e da ajuda mostram os atalhos atuais.
        private void RefreshKeyLabels()
        {
            string kp = Config.KeyText(_cfg.KeyFor("project"));
            _btnProjTop.Text = "Projetar (Enter)";
            _btnPrev.Text = "◀ Anterior (" + Config.KeyText(_cfg.KeyFor("prev")) + ")";
            _btnNext.Text = "Próximo (" + Config.KeyText(_cfg.KeyFor("next")) + ") ▶";
            _btnProj.Text = "PROJETAR / LIMPAR (" + kp + ")";
            _btnClear.Text = "Limpar (Esc / " + kp + ")";
            _lblHelp.Text = "Clique no livro e digite capítulo+versículo juntos (ex.: 556 = 55:6, 119105 = 119:105).   ← → versículo   ↑ ↓ capítulo   " +
                kp + " projeta / tira   Enter projeta   Esc tira   " +
                Config.KeyText(_cfg.KeyFor("verprev")) + " / " + Config.KeyText(_cfg.KeyFor("vernext")) + " trocam a versão";
        }

        // ProcessCmdKey roda ANTES de qualquer controle filho, então as setas e os atalhos valem em qualquer foco.
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (!_cmbVer.DroppedDown)
            {
                switch (keyData)
                {
                    case Keys.Right: StepVerse(1); return true;
                    case Keys.Left:  StepVerse(-1); return true;
                    case Keys.Up:    StepChapter(1); return true;
                    case Keys.Down:  StepChapter(-1); return true;
                }
            }
            if (keyData == Keys.Escape) { ClearLive(); return true; }
            if (keyData == Keys.Return && !_cmbVer.DroppedDown)
            {
                // com o foco na caixa de referência, o Enter lê o que foi digitado (e avisa se não existir)
                if (_q.Focused) ProjectFromBox(); else ProjectCur();
                return true;
            }
            if (keyData == (Keys.Control | Keys.L)) { _q.Focus(); _q.SelectAll(); return true; }
            if (!_q.Focused && !_cmbVer.DroppedDown && _selBook >= 0)
            {
                char dg = '\0';
                if (keyData >= Keys.D1 && keyData <= Keys.D9) dg = (char)('0' + (keyData - Keys.D0));
                else if (keyData >= Keys.NumPad1 && keyData <= Keys.NumPad9) dg = (char)('0' + (keyData - Keys.NumPad0));
                if (dg != '\0') { OpenQuick(dg); return true; }
            }
            string action = _cfg.ActionFor(keyData);
            if (action != null)
            {
                switch (action)
                {
                    case "project":  ToggleProject(); return true;
                    case "next":     StepLive(1); return true;
                    case "prev":     StepLive(-1); return true;
                    case "vernext":  CycleVersion(1); return true;
                    case "verprev":  CycleVersion(-1); return true;
                    case "black":    ToggleBlack(); return true;
                }
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        // ---------- Bíblia ----------

        // Versões antigas guardavam uma única Bíblia (biblia.json/txt): passa para a biblioteca de versões.
        private void MigrateLegacy()
        {
            try
            {
                string sg = BibleLib.SafeSigla(_cfg.Version);
                if (sg.Length == 0) sg = "BIBLIA";
                foreach (string name in new string[] { "biblia.json", "biblia.txt" })
                {
                    string p = Path.Combine(Config.DataDir, name);
                    if (!File.Exists(p)) continue;
                    string dest = Path.Combine(BibleLib.UserDir, sg + Path.GetExtension(name));
                    if (!File.Exists(dest)) File.Move(p, dest);
                    else File.Delete(p);
                    if (_cfg.ActiveBible.Length == 0) _cfg.ActiveBible = sg;
                }
            }
            catch { }
        }

        private void LoadBibleAuto()
        {
            MigrateLegacy();
            RefreshVersionList();
            string want = _cfg.ActiveBible ?? "";
            List<string> names = BibleLib.Names();
            if (!BibleLib.Exists(want)) want = names.Count > 0 ? names[0] : "";
            if (want.Length > 0) SwitchVersion(want);
            else SetBible(new Bible());
        }

        // Atualiza a caixa de versões do painel.
        private void RefreshVersionList()
        {
            _busyVer = true;
            _cmbVer.Items.Clear();
            foreach (string n in BibleLib.Names()) _cmbVer.Items.Add(n);
            int ix = _cmbVer.Items.IndexOf(_active);
            _cmbVer.SelectedIndex = ix >= 0 ? ix : (_cmbVer.Items.Count > 0 ? 0 : -1);
            _cmbVer.Enabled = _cmbVer.Items.Count > 0;
            _busyVer = false;
        }

        private Bible GetBible(string sigla)
        {
            Bible b;
            if (_cache.TryGetValue(sigla, out b)) return b;
            string err;
            b = BibleLib.Load(sigla, out err);
            if (b == null)
            {
                MessageBox.Show(this, "Não consegui abrir a versão " + sigla + ":\r\n" + err, "Bíblia",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return null;
            }
            if (_cache.Count >= 4)
            {
                string drop = null;
                foreach (string k in _cache.Keys)
                    if (!string.Equals(k, _active, StringComparison.OrdinalIgnoreCase)) { drop = k; break; }
                if (drop != null) _cache.Remove(drop);   // evita guardar as 18 versões ao mesmo tempo (~100 MB)
            }
            _cache[sigla] = b;
            return b;
        }

        // Troca a versão mantendo o mesmo versículo (na tela de teste e, se houver, ao vivo).
        private void SwitchVersion(string sigla)
        {
            Bible b = GetBible(sigla);
            if (b == null) { RefreshVersionList(); return; }
            bool had = _hasCur;
            VRef keep = _cur;
            _active = sigla;
            _cfg.ActiveBible = sigla;
            _cfg.Save();
            SetBible(b);
            RefreshVersionList();
            VRef n;
            if (had && _bible.Clamp(keep, out n)) GoTo(n, false);
            if (_hasLive && _liveOn)
            {
                VRef nl;
                if (_bible.Clamp(_live, out nl)) { _live = nl; ShowLive(nl); }
            }
            UpdatePreview();
        }

        private void CycleVersion(int dir)
        {
            int n = _cmbVer.Items.Count;
            if (n < 2) return;
            int i = _cmbVer.SelectedIndex;
            i = ((i + dir) % n + n) % n;
            _cmbVer.SelectedIndex = i;   // dispara SwitchVersion
        }

        private void SetBible(Bible b)
        {
            _bible = b;
            _bookIdx.Clear();
            for (int i = 0; i < 66; i++)
                if (_bible.Has(i)) _bookIdx.Add(i);
            _hasCur = false;
            _selBook = -1; _selChap = -1; _selVerseFrom = -1; _selVerseTo = -1;
            int n = _bookIdx.Count;
            string[] t = new string[n], s = new string[n];
            Color[] c = new Color[n];
            for (int i = 0; i < n; i++)
            {
                int bk = _bookIdx[i];
                t[i] = bk < BookShort.Length ? BookShort[bk] : Bible.Names[bk].Substring(0, 3);
                s[i] = Bible.Names[bk];
                c[i] = GetBookColor(bk);
            }
            _gBooks.FixedCols = n == 66 ? 11 : 0;
            _gBooks.SetData(t, s, c);
            _gChaps.SetData(null, null, null);
            _gVerses.SetData(null, null, null);
            _vlist.Items.Clear();
            _lblChap.Text = "";
            if (n > 0) Navigate(0, 0, 1, 1);
            else UpdateCurFromLists();
            UpdateStatus();
        }

        // ---------- grades e lista de versículos ----------

        private static string[] Numbers(int n)
        {
            string[] t = new string[n];
            for (int i = 0; i < n; i++) t[i] = (i + 1).ToString();
            return t;
        }

        private static Color[] Same(int n, Color c)
        {
            Color[] a = new Color[n];
            for (int i = 0; i < n; i++) a[i] = c;
            return a;
        }

        private void FillChaps()
        {
            int b = _bookIdx[_selBook];
            int n = _bible.Chapters(b);
            _gChaps.SetData(Numbers(n), null, Same(n, Dark(GetBookColor(b), 0.62f)));
        }

        private void FillVerses()
        {
            int b = _bookIdx[_selBook];
            int n = _bible.Verses(b, _selChap + 1);
            _gVerses.SetData(Numbers(n), null, Same(n, Dark(GetBookColor(b), 0.9f)));
            _lblChap.Text = Bible.Names[b] + " " + (_selChap + 1) + (_active.Length > 0 ? "   •   " + _active : "");
            FillVerseList();
            if (_vlist.Items.Count > 0) _vlist.TopIndex = 0;
        }

        private void FillVerseList()
        {
            if (_vlist == null) return;
            _vlist.BeginUpdate();
            _vlist.Items.Clear();
            if (_selBook >= 0 && _selChap >= 0)
            {
                int b = _bookIdx[_selBook];
                int n = _bible.Verses(b, _selChap + 1);
                for (int v = 1; v <= n; v++)
                    _vlist.Items.Add(v + " – " + _bible.Verse(b, _selChap + 1, v));
            }
            _vlist.EndUpdate();
            if (_selVerseFrom > 0) ScrollToVerse(_selVerseFrom);
        }

        private void ScrollToVerse(int v)
        {
            int i = v - 1;
            if (i < 0 || i >= _vlist.Items.Count) return;
            Rectangle ir = _vlist.GetItemRectangle(i);
            if (ir.Top < 0 || ir.Bottom > _vlist.ClientSize.Height) _vlist.TopIndex = i;
        }

        // Seleciona livro (posição na lista), capítulo (0-based) e versículos, sem projetar.
        private void Navigate(int li, int chapIdx, int vfrom, int vto)
        {
            if (li < 0 || li >= _bookIdx.Count) return;
            if (li != _selBook)
            {
                _selBook = li;
                _selChap = -1;
                FillChaps();
                _gBooks.Sel = li; _gBooks.SelTo = -1; _gBooks.Invalidate();
            }
            int b = _bookIdx[li];
            int nc = _bible.Chapters(b);
            if (chapIdx >= nc) chapIdx = nc - 1;
            if (chapIdx < 0) chapIdx = 0;
            if (chapIdx != _selChap)
            {
                _selChap = chapIdx;
                FillVerses();
                _gChaps.Sel = chapIdx; _gChaps.SelTo = -1; _gChaps.Invalidate();
            }
            int nv = _bible.Verses(b, chapIdx + 1);
            if (nv < 1) { vfrom = 0; vto = 0; }
            else
            {
                if (vfrom < 1) vfrom = 1;
                if (vfrom > nv) vfrom = nv;
                if (vto < vfrom) vto = vfrom;
                if (vto > nv) vto = nv;
            }
            _selVerseFrom = vfrom; _selVerseTo = vto;
            _gVerses.Sel = vfrom > 0 ? vfrom - 1 : -1;
            _gVerses.SelTo = vto > 0 ? vto - 1 : -1;
            _gVerses.Invalidate();
            _vlist.Invalidate();
            if (vfrom > 0) ScrollToVerse(vfrom);
            UpdateCurFromLists();
        }

        public string BibleInfo
        {
            get
            {
                int n = _bible.TotalVerses();
                if (n == 0) return "Nenhuma Bíblia carregada.";
                return "Versão ativa: " + _active + " (" + n + " versículos).";
            }
        }

        private void UpdateStatus()
        {
            int n = _bible.TotalVerses();
            _status.Text = n == 0 ? "Sem Bíblia: abra Configurações e importe um arquivo." : _active + "  •  " + n + " versículos";
            _status.ForeColor = n == 0 ? Theme.Warn : Theme.Muted;
        }

        // ---- usado pela janela de configurações ----

        public List<string> VersionNames() { return BibleLib.Names(); }

        public string VersionKind(string sigla)
        {
            return BibleLib.IsUser(sigla) ? "importada" : "incluída";
        }

        // Importa um ou mais arquivos; devolve a sigla da última versão importada (ou null).
        public string ImportBibles() { return ImportBibles(null); }

        public string ImportBibles(string fixedSigla)
        {
            string last = null;
            using (OpenFileDialog od = new OpenFileDialog())
            {
                od.Title = fixedSigla != null ? "Escolha o arquivo da " + fixedSigla + " (.json ou .txt)"
                    : "Escolha o(s) arquivo(s) da Bíblia (.json ou .txt) - pode marcar vários";
                od.Multiselect = fixedSigla == null;
                od.Filter = "Bíblia|*.json;*.txt|Todos os arquivos|*.*";
                if (od.ShowDialog(this) != DialogResult.OK) return null;
                foreach (string file in od.FileNames)
                {
                    string def = BibleLib.SafeSigla(Path.GetFileNameWithoutExtension(file));
                    string sg = fixedSigla ?? PromptForm.Ask(this, "Sigla da versão",
                        "Qual a sigla desta versão?  (ex.: NVT, NTLH, ACF)\r\n" + Path.GetFileName(file), def);
                    if (sg == null) continue;
                    sg = BibleLib.SafeSigla(sg);
                    if (sg.Length == 0) continue;
                    if (BibleLib.IsUser(sg) &&
                        MessageBox.Show(this, "Já existe uma versão importada chamada " + sg + ". Substituir?", "Bíblia",
                            MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) continue;
                    string err;
                    if (!BibleLib.Import(file, sg, out err))
                    {
                        MessageBox.Show(this, "Não consegui ler " + Path.GetFileName(file) + ":\r\n" + err, "Bíblia",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        continue;
                    }
                    _cache.Remove(sg);
                    last = sg;
                }
            }
            if (last != null)
            {
                _active = last;
                SwitchVersion(last);
                MessageBox.Show(this, "Pronto! Versão " + last + " carregada (" + _bible.TotalVerses() + " versículos).", "Bíblia");
            }
            return last;
        }

        public bool RemoveVersion(string sigla)
        {
            if (!BibleLib.IsUser(sigla))
            {
                MessageBox.Show(this, "A versão " + sigla + " acompanha o programa e não pode ser removida por aqui.", "Bíblia");
                return false;
            }
            if (MessageBox.Show(this, "Remover a versão " + sigla + " do programa?", "Bíblia",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return false;
            BibleLib.Remove(sigla);
            _cache.Remove(sigla);
            if (_active == sigla)
            {
                List<string> names = BibleLib.Names();
                if (names.Count > 0) SwitchVersion(names[0]);
                else { _active = ""; _cfg.ActiveBible = ""; _cfg.Save(); SetBible(new Bible()); RefreshVersionList(); }
            }
            else RefreshVersionList();
            return true;
        }

        // ---------- seleção ----------

        private void UpdateCurFromLists()
        {
            if (_selBook < 0 || _selBook >= _bookIdx.Count || _selChap < 0 || _selVerseFrom < 1)
            {
                _hasCur = false;
                UpdatePreview();
                return;
            }
            _cur = new VRef();
            _cur.Book = _bookIdx[_selBook];
            _cur.Chapter = _selChap + 1;
            _cur.From = _selVerseFrom;
            _cur.To = _selVerseTo > 0 ? _selVerseTo : _selVerseFrom;
            _hasCur = true;
            UpdatePreview();
        }

        // Vai para a referência (seleciona nas grades) e, se pedido, projeta.
        private void GoTo(VRef r, bool project)
        {
            int bi = _bookIdx.IndexOf(r.Book);
            if (bi < 0) return;
            int vfrom = Math.Max(1, r.From);
            Navigate(bi, r.Chapter - 1, vfrom, Math.Max(vfrom, r.To));
            if (project) ProjectCur();
        }

        // Atalho rápido (como no Holyrics): com o livro selecionado, digitar 1-9 abre a telinha de capítulo/versículo.
        private void OpenQuick(char first)
        {
            int bb = _selBook, bc = _selChap, bf = _selVerseFrom, bt = _selVerseTo;
            int book = _bookIdx[_selBook];
            using (QuickJumpForm f = new QuickJumpForm(_bible, book, first.ToString()))
            {
                f.AutoEnter = _cfg.QuickAutoEnter;
                f.Apply = delegate(int c, int v) { Navigate(bb, c - 1, v, v); };
                f.ShowDialog(this);
                if (f.Cancelled) Navigate(bb, bc, bf, bt);
                else { SyncBox(); if (f.Project) ProjectCur(); }
            }
        }

        private void SyncBox()
        {
            if (!_hasCur) return;
            _syncBox = true;
            _q.Text = Bible.RefText(_cur);
            _q.SelectionStart = _q.Text.Length;
            _syncBox = false;
        }

        // ← → : versículo anterior/seguinte (passa de capítulo e livro). Se está projetando, projeta o novo.
        private void StepVerse(int dir)
        {
            if (!_hasCur) return;
            VRef b = _cur;
            if (dir > 0) b.From = b.To; else b.To = b.From;
            VRef n;
            if (!_bible.Step(b, dir, out n)) return;
            GoTo(n, _liveOn);
            SyncBox();
        }

        // ↑ próximo capítulo, ↓ capítulo anterior (passa de livro). Se está projetando, projeta o versículo 1.
        private void StepChapter(int dir)
        {
            if (!_hasCur) return;
            int b = _cur.Book, c = _cur.Chapter + dir;
            if (c > _bible.Chapters(b))
            {
                int nb = b + 1;
                while (nb < 66 && !_bible.Has(nb)) nb++;
                if (nb >= 66) return;
                b = nb; c = 1;
            }
            else if (c < 1)
            {
                int pb = b - 1;
                while (pb >= 0 && !_bible.Has(pb)) pb--;
                if (pb < 0) return;
                b = pb; c = _bible.Chapters(pb);
            }
            VRef n = new VRef();
            n.Book = b; n.Chapter = c; n.From = 1; n.To = 1;
            GoTo(n, _liveOn);
            SyncBox();
        }

        // ---------- busca ----------

        private void ProjectFromBox()
        {
            VRef r;
            string problem;
            string typed = (_q.Text ?? "").Trim();
            if (_bible.ParseEx(typed, out r, out problem)) GoTo(r, true);
            else if (typed.Length == 0) ProjectCur();
            else if (problem.Length > 0) Warn(problem);
            else Warn("Não entendi \"" + typed + "\". Exemplo: Jo 3:16");
            _q.Focus();
            _q.SelectAll();
        }

        // Aviso rápido no lugar do texto de status (volta ao normal sozinho depois de alguns segundos).
        private System.Windows.Forms.Timer _msgTimer;

        private void Warn(string text)
        {
            _status.Text = text;
            _status.ForeColor = Theme.Warn;
            if (_msgTimer == null)
            {
                _msgTimer = new System.Windows.Forms.Timer();
                _msgTimer.Interval = 4000;
                _msgTimer.Tick += delegate { _msgTimer.Stop(); UpdateStatus(); };
            }
            _msgTimer.Stop();
            _msgTimer.Start();
        }

        // Tela preta (F6): cobre a projeção de preto sem perder o versículo; aperte de novo para voltar.
        private void ToggleBlack()
        {
            bool on = !_proj.View.Black;
            if (on) ShowProj();
            _proj.View.Black = on;
            _liveView.Black = on;
            if (!on && !_liveOn) _proj.Hide();
        }

        // ---------- projeção ----------

        private string RefLabel(VRef r)
        {
            string s = Bible.RefText(r);
            if (_active.Length > 0) s += " (" + _active + ")";
            return s;
        }

        private void UpdatePreview()
        {
            if (_selView == null) return;
            if (_hasCur) _selView.ShowVerse(_bible.TextOf(_cur), RefLabel(_cur));
            else _selView.ShowVerse("", "");
        }

        private void ProjectCur()
        {
            if (!_hasCur) return;
            _live = _cur;
            _hasLive = true;
            ShowLive(_cur);
        }

        private void ShowLive(VRef r)
        {
            string t = _bible.TextOf(r), rf = RefLabel(r);
            _liveOn = true;
            _proj.View.Black = false;
            _liveView.Black = false;
            ShowProj();
            _proj.View.ShowVerse(t, rf);
            _liveView.ShowVerse(t, rf);
        }

        private void StepLive(int dir)
        {
            VRef b;
            if (_hasLive) b = _live;
            else if (_hasCur) b = _cur;
            else return;
            VRef n;
            if (!_bible.Step(b, dir, out n)) return;
            GoTo(n, true);
            SyncBox();
        }

        // Projetar e limpar são o mesmo atalho: se há versículo na tela, tira; senão, projeta.
        private void ToggleProject()
        {
            if (_liveOn) ClearLive(); else ProjectCur();
        }

        private void ShowProj()
        {
            if (!_proj.Visible)
            {
                _proj.Show();
                // a janela de projeção não pode roubar o foco: sem foco no painel o 2º Ctrl+Space não chegaria
                if (Form.ActiveForm != this) { Activate(); _gBooks.Focus(); }
            }
        }

        private void ClearLive()
        {
            bool wasActive = Form.ActiveForm == this;
            _liveOn = false;
            _proj.View.Black = false;
            _liveView.Black = false;
            _proj.View.ClearText();
            _liveView.ClearText();
            _proj.Hide();
            if (wasActive && Form.ActiveForm != this) Activate();   // some a projeção por inteiro: aparece o que está por baixo
        }

        // ---------- tela de projeção ----------

        private void PlaceProjection()
        {
            Screen[] all = Screen.AllScreens;
            Screen target = null;
            if (all.Length > 1)
            {
                if ((_cfg.ScreenName ?? "").Length > 0)
                    foreach (Screen s in all) if (s.DeviceName == _cfg.ScreenName) target = s;
                if (target == null)
                    foreach (Screen s in all) if (!s.Primary) { target = s; break; }
            }
            if (target == null) target = Screen.PrimaryScreen;
            _proj.Place(target, target.Primary);
        }

        private void OnDisplayChanged(object sender, EventArgs e)
        {
            try { BeginInvoke(new MethodInvoker(PlaceProjection)); }
            catch { }
        }

        private void OpenSettings()
        {
            using (SettingsForm f = new SettingsForm(this, _cfg))
                f.ShowDialog(this);
        }

        // Chamado pela janela de configurações quando algo muda.
        public void SettingsChanged()
        {
            _cfg.Save();
            RefreshKeyLabels();
            _selView.Reload();
            _liveView.Reload();
            _proj.View.Reload();
            PlaceProjection();
            UpdatePreview();
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            _q.TextChanged += delegate
            {
                VRef r;
                if (!_syncBox && _bible.Parse(_q.Text, out r)) GoTo(r, false);
            };
            _q.KeyDown += delegate(object s, KeyEventArgs ke)
            {
                if (ke.KeyCode == Keys.Enter)
                {
                    ProjectFromBox();
                    ke.Handled = true; ke.SuppressKeyPress = true;
                }
            };
            _gBooks.Focus();
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            SystemEvents.DisplaySettingsChanged -= OnDisplayChanged;
            try { _proj.Close(); _proj.Dispose(); }
            catch { }
            base.OnFormClosed(e);
        }
    }

    // Configurações da projeção: tela, letra, cores, fundo e Bíblia.
    internal class SettingsForm : Form
    {
        private readonly MainForm _owner;
        private readonly Config _c;
        private readonly List<string> _screenNames = new List<string>();
        private Button _btnText, _btnBg;
        private Label _lblPath, _lblFont, _lblBible;
        private ListBox _lstVer;
        private bool _loading = true;

        public SettingsForm(MainForm owner, Config c)
        {
            _owner = owner;
            _c = c;
            Text = "Configurações da projeção";
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.CenterParent;
            BackColor = Theme.Bg;
            ForeColor = Theme.Text;
            AutoScaleMode = AutoScaleMode.None;
            ClientSize = new Size(620, 752);

            int y = 14;

            AddLabel("Tela da projeção:", 16, y + 4, 150);
            ComboBox cmbScr = new ComboBox();
            cmbScr.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbScr.Font = new Font("Segoe UI", 10f);
            cmbScr.SetBounds(170, y, 430, 28);
            _screenNames.Add("");
            cmbScr.Items.Add("Automática (primeira tela extra)");
            int sel = 0;
            Screen[] all = Screen.AllScreens;
            for (int i = 0; i < all.Length; i++)
            {
                _screenNames.Add(all[i].DeviceName);
                cmbScr.Items.Add("Tela " + (i + 1) + (all[i].Primary ? " (principal)" : "") + "  " +
                                 all[i].Bounds.Width + "x" + all[i].Bounds.Height);
                if (all[i].DeviceName == _c.ScreenName) sel = i + 1;
            }
            cmbScr.SelectedIndex = sel;
            cmbScr.SelectedIndexChanged += delegate
            {
                if (_loading) return;
                _c.ScreenName = _screenNames[cmbScr.SelectedIndex];
                Changed();
            };
            Controls.Add(cmbScr);
            y += 34;
            AddLabel("Com uma tela só, a projeção vira uma janelinha de teste (para não cobrir o painel).", 170, y, 430, 20, Theme.Muted, 8.5f);
            y += 34;

            AddLabel("Letra:", 16, y + 4, 150);
            ComboBox cmbFont = new ComboBox();
            cmbFont.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbFont.Font = new Font("Segoe UI", 10f);
            cmbFont.SetBounds(170, y, 300, 28);
            int fsel = -1;
            foreach (FontFamily ff in FontFamily.Families)
            {
                int ix = cmbFont.Items.Add(ff.Name);
                if (string.Equals(ff.Name, _c.FontName, StringComparison.OrdinalIgnoreCase)) fsel = ix;
            }
            if (fsel >= 0) cmbFont.SelectedIndex = fsel;
            cmbFont.SelectedIndexChanged += delegate
            {
                if (_loading || cmbFont.SelectedItem == null) return;
                _c.FontName = cmbFont.SelectedItem.ToString();
                Changed();
            };
            Controls.Add(cmbFont);
            y += 38;

            AddLabel("Tamanho máximo:", 16, y + 6, 150);
            TrackBar tb = new TrackBar();
            tb.Minimum = 40;
            tb.Maximum = 260;
            tb.TickFrequency = 20;
            tb.Value = Math.Max(40, Math.Min(260, _c.MaxFont));
            tb.SetBounds(170, y, 340, 40);
            tb.BackColor = Theme.Bg;
            _lblFont = AddLabel(tb.Value.ToString(), 520, y + 6, 80, 24, Theme.Text, 10.5f);
            tb.ValueChanged += delegate
            {
                _lblFont.Text = tb.Value.ToString();
                if (_loading) return;
                _c.MaxFont = tb.Value;
                Changed();
            };
            Controls.Add(tb);
            y += 46;
            AddLabel("A letra diminui sozinha quando o texto é grande; este é o limite para versículos curtos.", 170, y, 430, 20, Theme.Muted, 8.5f);
            y += 32;

            AddLabel("Cor da letra:", 16, y + 4, 150);
            _btnText = Swatch(170, y, 90, 30, _c.TextColor, delegate
            {
                int v = _c.TextColor;
                if (Pick(ref v)) { _c.TextColor = v; _btnText.BackColor = Color.FromArgb(255, Color.FromArgb(v)); Changed(); }
            });
            AddLabel("Cor do fundo:", 300, y + 4, 120);
            _btnBg = Swatch(430, y, 90, 30, _c.BgColor, delegate
            {
                int v = _c.BgColor;
                if (Pick(ref v)) { _c.BgColor = v; _btnBg.BackColor = Color.FromArgb(255, Color.FromArgb(v)); Changed(); }
            });
            y += 44;

            AddLabel("Papel de parede:", 16, y + 6, 150);
            AddButton("Escolher imagem...", 170, y, 170, 32, delegate { ChooseImage(); });
            AddButton("Tirar imagem", 350, y, 130, 32, delegate { _c.BgPath = ""; ShowPath(); Changed(); });
            y += 38;
            _lblPath = AddLabel("", 16, y, 590, 22, Theme.Text, 8.5f);
            ShowPath();
            y += 32;

            CheckBox chShadow = new CheckBox();
            chShadow.Text = "Sombra na letra (ajuda a ler sobre imagens)";
            chShadow.Font = new Font("Segoe UI", 10f);
            chShadow.Checked = _c.Shadow;
            chShadow.SetBounds(16, y, 400, 26);
            chShadow.CheckedChanged += delegate { if (_loading) return; _c.Shadow = chShadow.Checked; Changed(); };
            Controls.Add(chShadow);
            y += 30;

            CheckBox chRef = new CheckBox();
            chRef.Text = "Mostrar a referência (ex.: João 3:16) embaixo";
            chRef.Font = new Font("Segoe UI", 10f);
            chRef.Checked = _c.ShowRef;
            chRef.SetBounds(16, y, 400, 26);
            chRef.CheckedChanged += delegate { if (_loading) return; _c.ShowRef = chRef.Checked; Changed(); };
            Controls.Add(chRef);
            y += 30;

            CheckBox chAuto = new CheckBox();
            chAuto.Text = "Atalho rápido: dar Enter sozinho ao completar o versículo";
            chAuto.Font = new Font("Segoe UI", 10f);
            chAuto.Checked = _c.QuickAutoEnter;
            chAuto.SetBounds(16, y, 580, 26);
            chAuto.CheckedChanged += delegate { if (_loading) return; _c.QuickAutoEnter = chAuto.Checked; Changed(); };
            Controls.Add(chAuto);
            y += 34;

            // ---- separador Bíblias ----
            Label sep = new Label();
            sep.AutoSize = false;
            sep.BackColor = Theme.Edge;
            sep.SetBounds(16, y, 588, 1);
            Controls.Add(sep);
            y += 8;
            AddLabel("VERSÕES DA BÍBLIA", 16, y, 400, 18, Theme.Accent, 8.5f);
            y += 22;

            // lista de versões instaladas
            _lstVer = new ListBox();
            _lstVer.BackColor = Theme.Card;
            _lstVer.ForeColor = Theme.Text;
            _lstVer.BorderStyle = BorderStyle.None;
            _lstVer.Font = new Font("Segoe UI", 10.5f);
            _lstVer.IntegralHeight = false;
            _lstVer.SetBounds(16, y, 240, 90);
            Controls.Add(_lstVer);
            FillVersions();

            // botões de importação
            AddButton("+ Importar NVT...",  266, y,      170, 28, delegate { DoImport("NVT");  });
            AddButton("+ Importar NTLH...", 266, y + 32, 170, 28, delegate { DoImport("NTLH"); });
            AddButton("+ Outra versão...",  266, y + 64, 170, 28, delegate { DoImport(null);   });
            AddButton("✕ Remover",          446, y,      150, 28, delegate
            {
                string sg = SelectedVersion();
                if (sg == null) return;
                _owner.RemoveVersion(sg);
                FillVersions();
                _lblBible.Text = _owner.BibleInfo;
            });
            y += 98;

            _lblBible = AddLabel(_owner.BibleInfo, 16, y, 590, 20, Theme.Good, 9f);
            y += 24;

            // instrução + link clicável
            AddLabel("Onde baixar o arquivo JSON da versão desejada:", 16, y, 590, 18, Theme.Muted, 8.5f);
            y += 20;

            LinkLabel lnk = new LinkLabel();
            lnk.Text = "github.com/damarals/biblias  →  clique aqui para abrir no navegador";
            lnk.Font = new Font("Segoe UI", 9f);
            lnk.AutoSize = false;
            lnk.SetBounds(16, y, 500, 18);
            lnk.BackColor = Theme.Bg;
            lnk.LinkColor = Theme.Accent;
            lnk.ActiveLinkColor = Theme.Good;
            lnk.LinkBehavior = LinkBehavior.NeverUnderline;
            lnk.LinkClicked += delegate
            {
                try { System.Diagnostics.Process.Start("https://github.com/damarals/biblias/releases/latest"); }
                catch { MessageBox.Show(this, "Acesse manualmente:\nhttps://github.com/damarals/biblias/releases/latest", "Site"); }
            };
            Controls.Add(lnk);
            y += 20;

            AddLabel("Baixe o .json da versão, depois clique em '+ Importar' acima e selecione o arquivo.",
                     16, y, 590, 18, Theme.Muted, 8.5f);
            y += 18;
            AddLabel("Formato suportado: JSON (mesmo padrão do ACF incluído). A sigla fica junto da referência (ex.: João 3:16 (NVT)).",
                     16, y, 590, 18, Theme.Muted, 8.5f);
            y += 2;

            AddButton("Atalhos do teclado...", 16, 710, 200, 32, delegate
            {
                using (ShortcutsForm f = new ShortcutsForm(_c)) f.ShowDialog(this);
                Changed();
            });
            AddButton("Fechar", 500, 710, 100, 32, delegate { Close(); });
            _loading = false;
        }

        private void DoImport(string sigla)
        {
            string last = _owner.ImportBibles(sigla);
            FillVersions();
            _lblBible.Text = _owner.BibleInfo;
            if (last != null) Changed();
        }

        private void FillVersions()
        {
            _lstVer.Items.Clear();
            foreach (string n in _owner.VersionNames())
                _lstVer.Items.Add(n + "   (" + _owner.VersionKind(n) + ")");
        }

        private string SelectedVersion()
        {
            if (_lstVer.SelectedIndex < 0) return null;
            string t = _lstVer.SelectedItem.ToString();
            int i = t.IndexOf(' ');
            return i > 0 ? t.Substring(0, i) : t;
        }

        private Label AddLabel(string text, int x, int y, int w)
        {
            return AddLabel(text, x, y, w, 24, Theme.Muted, 10f);
        }

        private Label AddLabel(string text, int x, int y, int w, int h, Color col, float size)
        {
            Label l = new Label();
            l.AutoSize = false;
            l.Text = text;
            l.Font = new Font("Segoe UI", size);
            l.ForeColor = col;
            l.BackColor = Theme.Bg;
            l.SetBounds(x, y, w, h);
            Controls.Add(l);
            return l;
        }

        private Button AddButton(string text, int x, int y, int w, int h, EventHandler click)
        {
            Button b = new Button();
            b.Text = text;
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderColor = Theme.Accent;
            b.Font = new Font("Segoe UI", 9.5f);
            b.ForeColor = Theme.Text;
            b.BackColor = Theme.Card;
            b.Cursor = Cursors.Hand;
            b.SetBounds(x, y, w, h);
            b.Click += click;
            Controls.Add(b);
            return b;
        }

        private Button Swatch(int x, int y, int w, int h, int argb, EventHandler click)
        {
            Button b = new Button();
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderColor = Theme.Edge;
            b.FlatAppearance.BorderSize = 2;
            b.Cursor = Cursors.Hand;
            b.BackColor = Color.FromArgb(255, Color.FromArgb(argb));
            b.SetBounds(x, y, w, h);
            b.Click += click;
            Controls.Add(b);
            return b;
        }

        private bool Pick(ref int argb)
        {
            using (ColorDialog cd = new ColorDialog())
            {
                cd.FullOpen = true;
                cd.AnyColor = true;
                cd.Color = Color.FromArgb(255, Color.FromArgb(argb));
                if (cd.ShowDialog(this) != DialogResult.OK) return false;
                argb = Color.FromArgb(255, cd.Color).ToArgb();
                return true;
            }
        }

        private void ShowPath()
        {
            _lblPath.Text = (_c.BgPath ?? "").Length == 0 ? "(nenhuma imagem: só a cor de fundo)" : _c.BgPath;
        }

        private void ChooseImage()
        {
            using (OpenFileDialog od = new OpenFileDialog())
            {
                od.Title = "Escolha o papel de parede";
                od.Filter = "Imagens|*.png;*.jpg;*.jpeg;*.bmp;*.gif|Todos os arquivos|*.*";
                if (od.ShowDialog(this) != DialogResult.OK) return;
                if (!File.Exists(od.FileName)) return;
                _c.BgPath = od.FileName;
                ShowPath();
                Changed();
            }
        }

        private void Changed()
        {
            if (_loading) return;
            _owner.SettingsChanged();
        }
    }
    // Caixinha para perguntar um texto (ex.: a sigla da versão).
    internal class PromptForm : Form
    {
        private readonly TextBox _tb = new TextBox();

        public static string Ask(IWin32Window owner, string title, string message, string def)
        {
            using (PromptForm f = new PromptForm(title, message, def))
                return f.ShowDialog(owner) == DialogResult.OK ? f._tb.Text : null;
        }

        private PromptForm(string title, string message, string def)
        {
            Text = title;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.CenterParent;
            BackColor = Theme.Bg;
            ForeColor = Theme.Text;
            AutoScaleMode = AutoScaleMode.None;
            ClientSize = new Size(440, 170);

            Label l = new Label();
            l.AutoSize = false;
            l.Text = message;
            l.Font = new Font("Segoe UI", 10f);
            l.ForeColor = Theme.Text;
            l.BackColor = Theme.Bg;
            l.SetBounds(16, 14, 408, 56);
            Controls.Add(l);

            _tb.Font = new Font("Segoe UI", 13f);
            _tb.Text = def ?? "";
            _tb.MaxLength = 12;
            _tb.BackColor = Theme.Card;
            _tb.ForeColor = Theme.Text;
            _tb.BorderStyle = BorderStyle.FixedSingle;
            _tb.SetBounds(16, 78, 200, 30);
            Controls.Add(_tb);

            Button ok = new Button();
            ok.Text = "OK";
            ok.FlatStyle = FlatStyle.Flat;
            ok.FlatAppearance.BorderColor = Theme.Accent;
            ok.ForeColor = Theme.Text;
            ok.BackColor = Theme.Card;
            ok.DialogResult = DialogResult.OK;
            ok.SetBounds(244, 124, 90, 32);
            Controls.Add(ok);

            Button cancel = new Button();
            cancel.Text = "Pular";
            cancel.FlatStyle = FlatStyle.Flat;
            cancel.FlatAppearance.BorderColor = Theme.Edge;
            cancel.ForeColor = Theme.Text;
            cancel.BackColor = Theme.Card;
            cancel.DialogResult = DialogResult.Cancel;
            cancel.SetBounds(342, 124, 90, 32);
            Controls.Add(cancel);

            AcceptButton = ok;
            CancelButton = cancel;
        }
    }
    // Tela para mudar os atalhos do teclado.
    internal class ShortcutsForm : Form
    {
        private readonly Config _c;
        private readonly ListBox _list = new ListBox();

        public ShortcutsForm(Config c)
        {
            _c = c;
            Text = "Atalhos do teclado";
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.CenterParent;
            BackColor = Theme.Bg;
            ForeColor = Theme.Text;
            AutoScaleMode = AutoScaleMode.None;
            ClientSize = new Size(520, 380);

            Label l = new Label();
            l.AutoSize = false;
            l.Text = "Escolha a ação e clique em Alterar (ou dê dois cliques). Depois aperte a nova tecla.";
            l.Font = new Font("Segoe UI", 9.5f);
            l.ForeColor = Theme.Muted;
            l.BackColor = Theme.Bg;
            l.SetBounds(16, 12, 488, 36);
            Controls.Add(l);

            _list.BackColor = Theme.Card;
            _list.ForeColor = Theme.Text;
            _list.BorderStyle = BorderStyle.None;
            _list.Font = new Font("Segoe UI", 11f);
            _list.IntegralHeight = false;
            _list.SetBounds(16, 52, 488, 230);
            _list.DoubleClick += delegate { Change(); };
            Controls.Add(_list);
            Fill(0);

            AddBtn("Alterar...", 16, 296, 150, 32, delegate { Change(); });
            AddBtn("Restaurar padrão", 176, 296, 160, 32, delegate { _c.ResetKeys(); Fill(_list.SelectedIndex); });
            AddBtn("Fechar", 404, 336, 100, 32, delegate { Close(); });
            Label tip = new Label();
            tip.AutoSize = false;
            tip.Text = "Enter no campo de referência sempre projeta. Teclas soltas só valem para F1-F12, Esc, PgUp, PgDn, Home, End; " +
                       "para letras use Ctrl, Alt ou Shift junto.";
            tip.Font = new Font("Segoe UI", 8.5f);
            tip.ForeColor = Theme.Muted;
            tip.BackColor = Theme.Bg;
            tip.SetBounds(16, 336, 380, 36);
            Controls.Add(tip);
        }

        private void AddBtn(string text, int x, int y, int w, int h, EventHandler click)
        {
            Button b = new Button();
            b.Text = text;
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderColor = Theme.Accent;
            b.Font = new Font("Segoe UI", 9.5f);
            b.ForeColor = Theme.Text;
            b.BackColor = Theme.Card;
            b.Cursor = Cursors.Hand;
            b.SetBounds(x, y, w, h);
            b.Click += click;
            Controls.Add(b);
        }

        private void Fill(int sel)
        {
            _list.Items.Clear();
            for (int i = 0; i < Config.ActionIds.Length; i++)
                _list.Items.Add(Config.ActionNames[i] + "   —   " + Config.KeyText(_c.KeyFor(Config.ActionIds[i])));
            if (sel < 0) sel = 0;
            if (sel < _list.Items.Count) _list.SelectedIndex = sel;
        }

        private void Change()
        {
            int i = _list.SelectedIndex;
            if (i < 0) return;
            Keys k;
            if (!KeyCaptureForm.Ask(this, Config.ActionNames[i], out k)) return;
            if (!Config.KeyAllowed(k))
            {
                MessageBox.Show(this, "Essa tecla atrapalharia a digitação. Use uma tecla F1-F12, Esc, PgUp, PgDn " +
                    "ou combine com Ctrl/Alt (ex.: Ctrl+J).", "Atalhos");
                return;
            }
            string id = Config.ActionIds[i];
            string other = _c.ActionFor(k);
            if (other != null && other != id)
            {
                _c.KeyMap[other] = _c.KeyFor(id);   // troca as duas
            }
            _c.KeyMap[id] = k;
            Fill(i);
        }
    }

    // Janelinha que espera o aperto de uma tecla.
    internal class KeyCaptureForm : Form
    {
        public Keys Result = Keys.None;

        public static bool Ask(IWin32Window owner, string action, out Keys key)
        {
            using (KeyCaptureForm f = new KeyCaptureForm(action))
            {
                bool ok = f.ShowDialog(owner) == DialogResult.OK;
                key = f.Result;
                return ok;
            }
        }

        private KeyCaptureForm(string action)
        {
            Text = "Nova tecla";
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.CenterParent;
            BackColor = Theme.Bg;
            ForeColor = Theme.Text;
            AutoScaleMode = AutoScaleMode.None;
            ClientSize = new Size(400, 140);

            Label l = new Label();
            l.AutoSize = false;
            l.Text = "Aperte a tecla (ou combinação) para:\r\n" + action;
            l.Font = new Font("Segoe UI", 11f);
            l.ForeColor = Theme.Text;
            l.BackColor = Theme.Bg;
            l.TextAlign = ContentAlignment.MiddleCenter;
            l.SetBounds(12, 12, 376, 70);
            Controls.Add(l);

            Button cancel = new Button();
            cancel.Text = "Cancelar";
            cancel.FlatStyle = FlatStyle.Flat;
            cancel.FlatAppearance.BorderColor = Theme.Edge;
            cancel.ForeColor = Theme.Text;
            cancel.BackColor = Theme.Card;
            cancel.TabStop = false;
            cancel.DialogResult = DialogResult.Cancel;
            cancel.SetBounds(150, 94, 100, 32);
            Controls.Add(cancel);
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            Keys code = keyData & Keys.KeyCode;
            if (code == Keys.ControlKey || code == Keys.ShiftKey || code == Keys.Menu) return true;   // espera a tecla de verdade
            Result = keyData;
            DialogResult = DialogResult.OK;
            return true;
        }
    }
}


namespace Versiculos
{
    // Telinha do atalho rápido (igual ao Holyrics): livro já escolhido; digite capítulo+versículo juntos
    // (556 = 55:6, 119105 = 119:105).
    internal class QuickJumpForm : Form
    {
        private readonly Bible _b;
        private readonly int _book;
        private string _first, _chap = "", _ver = "";
        private int _stage;   // 0 = digitando capítulo, 1 = digitando versículo
        private Label _lbBook, _lbBookV, _lbChap, _lbChapV, _lbVer, _lbVerV, _lbFoot, _lbEsc, _lbHint;
        public Action<int, int> Apply;
        public bool Cancelled, Project, AutoEnter;
        private bool _closing;

        protected override void OnFormClosing(FormClosingEventArgs e) { _closing = true; base.OnFormClosing(e); }

        public QuickJumpForm(Bible b, int book, string first)
        {
            _b = b; _book = book; _first = first;
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterParent;
            ShowInTaskbar = false;
            BackColor = Theme.Card;
            AutoScaleMode = AutoScaleMode.None;
            DoubleBuffered = true;
            ClientSize = new Size(560, 350);
            _lbEsc = T("Esc para cancelar", 380, 6, 174, 18, 8.5f, false, Theme.Muted, ContentAlignment.MiddleRight);
            _lbBook = T("Livro", 0, 28, 560, 34, 20f, true, Color.FromArgb(235, 240, 255), ContentAlignment.MiddleCenter);
            _lbBookV = T("", 0, 62, 560, 40, 22f, true, Theme.Warn, ContentAlignment.MiddleCenter);
            _lbChap = T("Capítulo", 0, 116, 560, 34, 20f, true, Color.FromArgb(235, 240, 255), ContentAlignment.MiddleCenter);
            _lbChapV = T("", 0, 150, 560, 44, 26f, true, Theme.Text, ContentAlignment.MiddleCenter);
            _lbVer = T("Versículo", 0, 206, 560, 34, 20f, true, Color.FromArgb(235, 240, 255), ContentAlignment.MiddleCenter);
            _lbVerV = T("", 0, 240, 560, 44, 26f, true, Theme.Text, ContentAlignment.MiddleCenter);
            _lbFoot = T("", 0, 296, 560, 22, 10f, false, Color.FromArgb(200, 210, 235), ContentAlignment.MiddleCenter);
            _lbHint = T("Enter = deixar pronto    Ctrl+Espaço = projetar    Espaço passa ao versículo", 0, 322, 560, 20, 8.5f, false, Theme.Muted, ContentAlignment.MiddleCenter);
            Deactivate += delegate { if (Visible && !_closing) Close(); };
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            using (LinearGradientBrush lb = new LinearGradientBrush(ClientRectangle, Color.FromArgb(12, 14, 26), Color.FromArgb(64, 88, 140), 80f))
                e.Graphics.FillRectangle(lb, ClientRectangle);
            using (Pen p = new Pen(Color.FromArgb(150, 0, 226, 255), 2f))
                e.Graphics.DrawRectangle(p, 1, 1, Width - 3, Height - 3);
        }

        private Label T(string text, int x, int y, int w, int h, float size, bool bold, Color c, ContentAlignment al)
        {
            Label l = new Label();
            l.AutoSize = false;
            l.SetBounds(x, y, w, h);
            l.Text = text;
            l.ForeColor = c;
            l.BackColor = Color.Transparent;
            l.TextAlign = al;
            l.Font = new Font("Segoe UI", size, bold ? FontStyle.Bold : FontStyle.Regular);
            Controls.Add(l);
            return l;
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            if (_b.Chapters(_book) == 1) { _chap = "1"; _stage = 1; }   // livro de 1 capítulo só: já vai direto ao versículo
            foreach (char ch in _first) AddDigit(ch);
            Recompute();
            CheckAuto();
        }

        private int NChap { get { return _b.Chapters(_book); } }
        private int NVer { get { int c; return int.TryParse(_chap, out c) ? _b.Verses(_book, c) : 0; } }

        // Capítulo: só aceita número que existe; se não dá mais para crescer (ex.: 23 em 50 capítulos), passa sozinho ao versículo.
        // Versículo: só aceita até o máximo do capítulo.
        private void AddDigit(char ch)
        {
            if (_stage == 0)
            {
                if (_chap.Length == 0 && ch == '0') return;
                int n = int.Parse(_chap + ch);
                if (n <= NChap)
                {
                    _chap = _chap + ch;
                    if (n * 10 > NChap) _stage = 1;
                }
                else if (_chap.Length > 0) { _stage = 1; AddDigit(ch); }
                return;
            }
            if (_ver.Length == 0 && ch == '0') return;
            int v = int.Parse(_ver + ch);
            if (v <= NVer) _ver = _ver + ch;
        }

        // Versículo completo (não dá para crescer mais dentro do máximo do capítulo): fecha sozinho, como o Enter.
        private void CheckAuto()
        {
            if (!AutoEnter || _stage != 1 || _ver.Length == 0) return;
            int v = int.Parse(_ver);
            if (v * 10 > NVer) Close();
        }

        private void Recompute()
        {
            _lbBookV.Text = Bible.Names[_book];
            bool cok = _chap.Length > 0;
            bool vok = cok && _ver.Length > 0;
            _lbChapV.Text = _chap + (_stage == 0 ? "▌" : "");
            _lbVerV.Text = _ver + (_stage == 1 ? "▌" : "");
            _lbChapV.ForeColor = Theme.Text;
            _lbVerV.ForeColor = vok ? Theme.Good : Theme.Text;
            _lbFoot.Text = _stage == 0 ? "Capítulos: " + NChap : "Versículos: " + NVer;
            if (cok && Apply != null)
                Apply(int.Parse(_chap), vok ? int.Parse(_ver) : 1);
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            char dg = '\0';
            if (keyData >= Keys.D0 && keyData <= Keys.D9) dg = (char)('0' + (keyData - Keys.D0));
            else if (keyData >= Keys.NumPad0 && keyData <= Keys.NumPad9) dg = (char)('0' + (keyData - Keys.NumPad0));
            if (dg != '\0') { AddDigit(dg); Recompute(); CheckAuto(); return true; }
            switch (keyData)
            {
                case Keys.Back:
                    if (_ver.Length > 0) _ver = _ver.Substring(0, _ver.Length - 1);
                    else
                    {
                        if (_chap.Length > 0) _chap = _chap.Substring(0, _chap.Length - 1);
                        _stage = 0;
                    }
                    Recompute();
                    return true;
                case Keys.Space: case Keys.Oemcomma: case Keys.OemPeriod: case Keys.Decimal: case Keys.Tab: case Keys.Right:
                    if (_stage == 0 && _chap.Length > 0) { _stage = 1; Recompute(); }
                    return true;
                case Keys.Return:
                    Close(); return true;
                case Keys.Escape:
                    Cancelled = true; Close(); return true;
                case Keys.Control | Keys.Space:
                    Project = true; Close(); return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }
    }
}
