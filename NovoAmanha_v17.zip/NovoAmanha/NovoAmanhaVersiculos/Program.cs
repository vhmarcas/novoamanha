using System;
using System.IO;
using System.Threading;
using System.Windows.Forms;

namespace Versiculos
{
    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            bool created;
            using (Mutex m = new Mutex(true, "NovoAmanhaVersiculos_UmaVezSo", out created))
            {
                if (!created)
                {
                    MessageBox.Show("O programa já está aberto.", "Novo Amanhã - Versículos");
                    return;
                }
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.ThreadException += delegate(object s, ThreadExceptionEventArgs e) { Log(e.Exception); };
                AppDomain.CurrentDomain.UnhandledException += delegate(object s, UnhandledExceptionEventArgs e)
                {
                    Exception x = e.ExceptionObject as Exception;
                    if (x != null) Log(x);
                };
                try { Application.Run(new MainForm()); }
                catch (Exception ex)
                {
                    Log(ex);
                    MessageBox.Show("Erro: " + ex.Message + "\r\n\r\nDetalhes em erros.log (pasta NovoAmanhaVersiculos, dentro de AppData\\Roaming).",
                        "Novo Amanhã - Versículos", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private static void Log(Exception ex)
        {
            try
            {
                string path = Path.Combine(Config.DataDir, "erros.log");
                FileInfo fi = new FileInfo(path);
                if (fi.Exists && fi.Length > 200000)
                {
                    string old = Path.Combine(Config.DataDir, "erros_antigo.log");
                    if (File.Exists(old)) File.Delete(old);
                    File.Move(path, old);
                }
                File.AppendAllText(path, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "  " + ex + "\r\n");
            }
            catch { }
        }
    }
}
