using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Windows.Forms;

namespace Versiculos
{
    // Desenha o "slide": fundo (cor/imagem) + versículo com a letra no maior tamanho que cabe + referência.
    // Serve tanto para a tela de projeção quanto para as pré-visualizações do painel.
    internal class SlideView : Control
    {
        private readonly Config _c;
        private readonly bool _fade;
        private readonly Timer _t = new Timer();
        private string _text = "", _ref = "";
        private bool _black;
        private float _alpha = 1f;
        private int _fadeDir;
        private DateTime _fadeStart;
        private Bitmap _bg;
        private string _bgPath = "";
        private string _fitKey = "";
        private float _fitPx;

        public SlideView(Config c, bool fade)
        {
            _c = c;
            _fade = fade;
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
            BackColor = Color.Black;
            _t.Interval = 16;
            _t.Tick += delegate { FadeTick(); };
        }

        public bool Black
        {
            get { return _black; }
            set { _black = value; Invalidate(); }
        }

        public string CurrentText { get { return _text; } }

        public void ShowVerse(string text, string reference)
        {
            text = text ?? "";
            reference = reference ?? "";
            bool changed = text != _text || reference != _ref;
            _text = text;
            _ref = reference;
            _fadeDir = 0;
            if (_fade && changed && text.Length > 0)
            {
                _alpha = 0f;
                _fadeDir = 1;
                _fadeStart = DateTime.UtcNow;
                _t.Start();
            }
            else
            {
                _alpha = 1f;
                _t.Stop();
            }
            Invalidate();
        }

        public void ClearText()
        {
            if (_fade && _text.Length > 0)
            {
                _fadeDir = -1;
                _fadeStart = DateTime.UtcNow;
                _t.Start();
            }
            else
            {
                _text = "";
                _ref = "";
                _t.Stop();
                Invalidate();
            }
        }

        // Estilo mudou (cor, fonte, imagem...): redesenha.
        public void Reload()
        {
            _fitKey = "";
            Invalidate();
        }

        private void FadeTick()
        {
            float p = (float)(DateTime.UtcNow - _fadeStart).TotalMilliseconds / 260f;
            if (p >= 1f)
            {
                p = 1f;
                _t.Stop();
                if (_fadeDir < 0)
                {
                    _text = "";
                    _ref = "";
                }
            }
            _alpha = _fadeDir >= 0 ? p : 1f - p;
            Invalidate();
        }

        private void LoadBackground()
        {
            string p = _c.BgPath ?? "";
            if (p == _bgPath) return;
            _bgPath = p;
            if (_bg != null) { _bg.Dispose(); _bg = null; }
            if (p.Length == 0) return;
            try
            {
                byte[] data = File.ReadAllBytes(p);
                using (MemoryStream ms = new MemoryStream(data))
                using (Image im = Image.FromStream(ms))
                    _bg = new Bitmap(im);
            }
            catch { _bg = null; }
        }

        private static StringFormat Fmt()
        {
            StringFormat sf = new StringFormat(StringFormat.GenericTypographic);
            sf.Alignment = StringAlignment.Center;
            sf.LineAlignment = StringAlignment.Center;
            return sf;
        }

        private float Fit(Graphics g, Size box, float maxPx)
        {
            string key = _text + "|" + box.Width + "x" + box.Height + "|" + maxPx + "|" + _c.FontName;
            if (key == _fitKey) return _fitPx;
            float lo = 10f, hi = Math.Max(12f, maxPx);
            using (StringFormat sf = Fmt())
            {
                while (hi - lo > 1f)
                {
                    float mid = (lo + hi) / 2f;
                    using (Font f = new Font(_c.FontName, mid, FontStyle.Regular, GraphicsUnit.Pixel))
                    {
                        SizeF m = g.MeasureString(_text, f, new SizeF(box.Width, 100000f), sf);
                        if (m.Height <= box.Height) lo = mid; else hi = mid;
                    }
                }
            }
            _fitKey = key;
            _fitPx = lo;
            return lo;
        }

        private Color Fade(Color c, float mul)
        {
            int a = (int)Math.Round(255f * _alpha * mul);
            return Color.FromArgb(Math.Max(0, Math.Min(255, a)), c);
        }

        // Fundo padrão (sem papel de parede): azul da noite com o sol dourado nascendo. Nunca fica preto.
        private static void DrawIdle(Graphics g, Rectangle r)
        {
            using (LinearGradientBrush lb = new LinearGradientBrush(r, Color.FromArgb(6, 12, 34), Color.FromArgb(24, 52, 112), 65f))
                g.FillRectangle(lb, r);
            int d = (int)(Math.Min(r.Width, r.Height) * 1.2);
            using (GraphicsPath gp = new GraphicsPath())
            {
                gp.AddEllipse(r.X + r.Width / 2 - d / 2, r.Bottom - d / 2, d, d);
                using (PathGradientBrush pb = new PathGradientBrush(gp))
                {
                    pb.CenterColor = Color.FromArgb(150, 255, 190, 60);
                    pb.SurroundColors = new Color[] { Color.FromArgb(0, 255, 190, 60) };
                    g.FillPath(pb, gp);
                }
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Rectangle r = ClientRectangle;
            if (_black)
            {
                g.Clear(Color.Black);
                return;
            }
            LoadBackground();
            Color bc = Color.FromArgb(255, Color.FromArgb(_c.BgColor));
            if (_bg == null && bc.ToArgb() == Color.Black.ToArgb() && r.Width > 1 && r.Height > 1) DrawIdle(g, r);
            else g.Clear(bc);
            if (_bg != null && r.Width > 1 && r.Height > 1)
            {
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                float sx = r.Width / (float)_bg.Width;
                float sy = r.Height / (float)_bg.Height;
                float sc = Math.Max(sx, sy);
                float cw = r.Width / sc, ch = r.Height / sc;
                g.DrawImage(_bg, r, (_bg.Width - cw) / 2f, (_bg.Height - ch) / 2f, cw, ch, GraphicsUnit.Pixel);
            }
            if (_text.Length == 0 || _alpha <= 0.001f || r.Width < 40 || r.Height < 40) return;

            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;

            int mx = (int)(r.Width * 0.07f);
            int my = (int)(r.Height * 0.07f);
            bool showRef = _c.ShowRef && _ref.Length > 0;
            int refH = showRef ? (int)(r.Height * 0.13f) : 0;
            Rectangle area = new Rectangle(r.X + mx, r.Y + my, r.Width - 2 * mx, r.Height - 2 * my - refH);
            if (area.Width < 10 || area.Height < 10) return;

            float maxPx = Math.Max(12f, _c.MaxFont * r.Height / 1080f);
            float px = Fit(g, area.Size, maxPx);
            Color tc = Color.FromArgb(255, Color.FromArgb(_c.TextColor));

            using (StringFormat sf = Fmt())
            {
                using (Font f = new Font(_c.FontName, px, FontStyle.Regular, GraphicsUnit.Pixel))
                {
                    if (_c.Shadow)
                    {
                        float off = Math.Max(1f, px * 0.04f);
                        RectangleF sr = new RectangleF(area.X + off, area.Y + off, area.Width, area.Height);
                        using (SolidBrush sb = new SolidBrush(Fade(Color.Black, 0.65f)))
                            g.DrawString(_text, f, sb, sr, sf);
                    }
                    using (SolidBrush b = new SolidBrush(Fade(tc, 1f)))
                        g.DrawString(_text, f, b, area, sf);
                }
                if (showRef)
                {
                    float rpx = Math.Max(10f, Math.Min(px * 0.6f, refH * 0.62f));
                    Rectangle rr = new Rectangle(r.X + mx, r.Bottom - my - refH, r.Width - 2 * mx, refH);
                    using (Font rf = new Font(_c.FontName, rpx, FontStyle.Italic, GraphicsUnit.Pixel))
                    {
                        if (_c.Shadow)
                        {
                            float off = Math.Max(1f, rpx * 0.05f);
                            using (SolidBrush sb = new SolidBrush(Fade(Color.Black, 0.65f)))
                                g.DrawString(_ref, rf, sb, new RectangleF(rr.X + off, rr.Y + off, rr.Width, rr.Height), sf);
                        }
                        using (SolidBrush b = new SolidBrush(Fade(tc, 0.85f)))
                            g.DrawString(_ref, rf, b, rr, sf);
                    }
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _t.Stop();
                _t.Dispose();
                if (_bg != null) { _bg.Dispose(); _bg = null; }
            }
            base.Dispose(disposing);
        }
    }

    // Janela da tela compartilhada: sem borda, cobre a tela escolhida e nunca rouba o foco do painel.
    internal class ProjectionForm : Form
    {
        public readonly SlideView View;

        public ProjectionForm(Config c)
        {
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.Manual;
            ShowInTaskbar = false;
            BackColor = Color.Black;
            Text = "Projeção";
            View = new SlideView(c, true);
            View.Dock = DockStyle.Fill;
            Controls.Add(View);
        }

        protected override bool ShowWithoutActivation { get { return true; } }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x08000000 | 0x00000080;   // WS_EX_NOACTIVATE | WS_EX_TOOLWINDOW
                return cp;
            }
        }

        // windowed = true quando só há uma tela: vira uma janelinha de teste em vez de cobrir o painel.
        public void Place(Screen s, bool windowed)
        {
            if (windowed)
            {
                if (FormBorderStyle != FormBorderStyle.SizableToolWindow)
                {
                    FormBorderStyle = FormBorderStyle.SizableToolWindow;
                    TopMost = false;
                    Text = "Projeção (teste - só há uma tela)";
                    Size = new Size(960, 540);
                    Location = new Point(s.WorkingArea.Left + 60, s.WorkingArea.Top + 60);
                }
            }
            else
            {
                if (FormBorderStyle != FormBorderStyle.None) FormBorderStyle = FormBorderStyle.None;
                TopMost = true;
                if (Bounds != s.Bounds) Bounds = s.Bounds;
            }
        }
    }
}
