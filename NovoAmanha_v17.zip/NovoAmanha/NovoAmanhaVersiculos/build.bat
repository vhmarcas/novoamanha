@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%CSC%" (
  echo Nao encontrei o compilador do .NET Framework 4 neste Windows.
  pause
  exit /b 1
)

echo Compilando Novo Amanha - Versiculos...
"%CSC%" /nologo /target:winexe /platform:anycpu /optimize+ /codepage:65001 /out:NovoAmanhaVersiculos.exe ^
  /r:System.dll /r:System.Core.dll /r:System.Drawing.dll /r:System.Windows.Forms.dll ^
  Config.cs Bible.cs SlideView.cs MainForm.cs Program.cs > "%~dp0log_compilacao.txt" 2>&1
set "RESULT=%errorlevel%"
type "%~dp0log_compilacao.txt"

if not "%RESULT%"=="0" (
  echo.
  echo ERRO na compilacao. Me envie o arquivo log_compilacao.txt desta pasta.
  if /i not "%~1"=="/semabrir" pause
  exit /b 1
)

echo.
echo Pronto! Gerado: %~dp0NovoAmanhaVersiculos.exe
if /i "%~1"=="/semabrir" goto fim
echo Abrindo...
start "" "%~dp0NovoAmanhaVersiculos.exe"
:fim
endlocal
exit /b 0
