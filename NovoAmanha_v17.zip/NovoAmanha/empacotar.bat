@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

echo ===== 1/4  Gerando os programas =====
call "NovoAmanhaHelper\build.bat" /semabrir
if errorlevel 1 goto erro
call "NovoAmanhaVersiculos\build.bat" /semabrir
if errorlevel 1 goto erro

echo.
echo ===== 2/4  Montando a pasta dist =====
if exist dist rmdir /s /q dist
mkdir dist\Helper
mkdir dist\Versiculos\biblias
copy /y NovoAmanhaHelper\NovoAmanhaHelper.exe dist\Helper\ >nul
copy /y NovoAmanhaHelper\LEIA-ME.txt dist\Helper\ >nul
copy /y NovoAmanhaVersiculos\NovoAmanhaVersiculos.exe dist\Versiculos\ >nul
copy /y NovoAmanhaVersiculos\LEIA-ME.txt dist\Versiculos\ >nul
copy /y NovoAmanhaVersiculos\biblias\*.json dist\Versiculos\biblias\ >nul
copy /y LEIA-ME-EXE.txt dist\LEIA-ME.txt >nul

echo.
echo ===== 3/4  Criando NovoAmanha_v17_exe.zip =====
if exist NovoAmanha_v17_exe.zip del /q NovoAmanha_v17_exe.zip
powershell -NoProfile -Command "Compress-Archive -Path 'dist\*' -DestinationPath 'NovoAmanha_v17_exe.zip' -Force"
if errorlevel 1 goto erro
certutil -hashfile NovoAmanha_v17_exe.zip SHA256 > NovoAmanha_v17_exe.zip.sha256.txt

echo.
echo ===== 4/4  Instalador (opcional) =====
set "ISCC="
if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if exist "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe" set "ISCC=%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe"
if not defined ISCC goto semiscc
"%ISCC%" /Q instalador.iss
if errorlevel 1 goto erro
certutil -hashfile NovoAmanha-Setup.exe SHA256 > NovoAmanha-Setup.exe.sha256.txt
echo Instalador criado: NovoAmanha-Setup.exe
goto fim

:semiscc
echo Inno Setup nao encontrado: o instalador NAO foi criado (o .zip com os .exe ja esta pronto).
echo Para criar o instalador, instale o Inno Setup 6 (gratuito, jrsoftware.org) e rode este arquivo de novo.

:fim
echo.
echo ===== PRONTO =====
echo  NovoAmanha_v17_exe.zip  (programas ja compilados, para postar)
echo  NovoAmanha-Setup.exe    (instalador, se o Inno Setup estiver instalado)
echo  *.sha256.txt            (impressao digital dos arquivos: publique junto)
pause
exit /b 0

:erro
echo.
echo ERRO. Veja o log_compilacao.txt da pasta que falhou.
pause
exit /b 1
