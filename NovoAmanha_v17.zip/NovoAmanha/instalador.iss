﻿; Instalador do Novo Amanhã (Inno Setup 6.3 ou mais novo). Use o empacotar.bat: ele compila tudo e chama este script.
[Setup]
AppId={{B1B9993C-F030-446C-AFF2-95FDC69F8AAA}
AppName=Novo Amanhã
AppVersion=17
AppPublisher=Novo Amanhã
DefaultDirName={autopf}\NovoAmanha
DefaultGroupName=Novo Amanhã
DisableProgramGroupPage=yes
OutputDir=.
OutputBaseFilename=NovoAmanha-Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
PrivilegesRequired=admin
UninstallDisplayName=Novo Amanhã (Helper e Versículos)

[Languages]
Name: "ptbr"; MessagesFile: "compiler:Languages\BrazilianPortuguese.isl"

[Tasks]
Name: "desktopicon"; Description: "Criar atalhos na Área de Trabalho"; Flags: unchecked

[Files]
Source: "dist\Helper\NovoAmanhaHelper.exe"; DestDir: "{app}\Helper"; Flags: ignoreversion
Source: "dist\Helper\LEIA-ME.txt"; DestDir: "{app}\Helper"; Flags: ignoreversion
Source: "dist\Versiculos\NovoAmanhaVersiculos.exe"; DestDir: "{app}\Versiculos"; Flags: ignoreversion
Source: "dist\Versiculos\LEIA-ME.txt"; DestDir: "{app}\Versiculos"; Flags: ignoreversion
Source: "dist\Versiculos\biblias\*"; DestDir: "{app}\Versiculos\biblias"; Flags: ignoreversion recursesubdirs

[Icons]
Name: "{group}\Novo Amanhã Helper"; Filename: "{app}\Helper\NovoAmanhaHelper.exe"
Name: "{group}\Novo Amanhã Versículos"; Filename: "{app}\Versiculos\NovoAmanhaVersiculos.exe"
Name: "{group}\Desinstalar"; Filename: "{uninstallexe}"
Name: "{autodesktop}\Novo Amanhã Helper"; Filename: "{app}\Helper\NovoAmanhaHelper.exe"; Tasks: desktopicon
Name: "{autodesktop}\Novo Amanhã Versículos"; Filename: "{app}\Versiculos\NovoAmanhaVersiculos.exe"; Tasks: desktopicon

[Run]
Filename: "{app}\Versiculos\NovoAmanhaVersiculos.exe"; Description: "Abrir o Novo Amanhã Versículos"; Flags: nowait postinstall skipifsilent unchecked

[UninstallRun]
; remove a tarefa "perguntar ao ligar o notebook" criada pelo Helper
Filename: "{sys}\schtasks.exe"; Parameters: "/Delete /TN ""NovoAmanhaHelper-Pergunta"" /F"; Flags: runhidden; RunOnceId: "RemoverTarefaHelper"
